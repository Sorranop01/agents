# MCP Hierarchical Agents - Final Design
## เอกสารออกแบบระบบ Agents แบบลำดับชั้นสำหรับงานเขียนโค้ด (ฉบับสมบูรณ์)

---

**Version:** 3.0 (Production Ready)  
**Last Updated:** 2026-04-09  
**Status:** ✅ Ready for Development

---

## 📋 สารบัญ

1. [เอกสารหลัก](#เอกสารหลัก)
2. [ไฟล์ Configuration](#ไฟล์-configuration)
3. [โครงสร้างโปรเจค](#โครงสร้างโปรเจค)
4. [การติดตั้ง](#การติดตั้ง)
5. [การใช้งาน](#การใช้งาน)

---

## เอกสารหลัก

| ไฟล์ | รายละเอียด |
|------|-----------|
| [MCP_HIERARCHICAL_AGENTS_MASTER.md](MCP_HIERARCHICAL_AGENTS_MASTER.md) | **เอกสารหลัก** - รวมทุกอย่างไว้ในที่เดียว |

### สถิติระบบ

| Component | Count |
|-----------|-------|
| **Total Agents** | 26 |
| **Hierarchy Levels** | 3 |
| **Departments** | 5 |
| **CTO** | 1 |
| **Department Heads** | 5 |
| **Workers** | 20 |
| **MCP Tools** | 50+ |
| **Task States** | 14 |
| **Quality Gates** | 4 |

---

## ไฟล์ Configuration

### ไฟล์หลัก

| ไฟล์ | รายละเอียด |
|------|-----------|
| [`.env.example`](config/.env.example) | Environment variables template |
| [`docker-compose.yml`](config/docker-compose.yml) | Docker orchestration |
| [`cline_mcp_settings.json`](config/cline_mcp_settings.json) | Kimi CLI configuration |
| [`Dockerfile`](config/Dockerfile) | Docker image definition |
| [`package.json`](config/package.json) | Node.js dependencies |
| [`tsconfig.json`](config/tsconfig.json) | TypeScript configuration |

### Kubernetes Manifests

| ไฟล์ | รายละเอียด |
|------|-----------|
| [`namespace.yaml`](config/kubernetes/namespace.yaml) | Kubernetes namespace |
| [`deployment.yaml`](config/kubernetes/deployment.yaml) | Deployment configuration |
| [`service.yaml`](config/kubernetes/service.yaml) | Service configuration |
| [`ingress.yaml`](config/kubernetes/ingress.yaml) | Ingress configuration |
| [`secrets.yaml`](config/kubernetes/secrets.yaml) | Secrets configuration |
| [`hpa.yaml`](config/kubernetes/hpa.yaml) | Horizontal Pod Autoscaler |

---

## โครงสร้างโปรเจค

```
final-design/
├── MCP_HIERARCHICAL_AGENTS_MASTER.md    # เอกสารหลัก
├── README.md                            # ไฟล์นี้
├── config/
│   ├── .env.example                     # Environment variables
│   ├── docker-compose.yml               # Docker orchestration
│   ├── cline_mcp_settings.json          # Kimi CLI config
│   ├── Dockerfile                       # Docker image
│   ├── package.json                     # Dependencies
│   ├── tsconfig.json                    # TypeScript config
│   └── kubernetes/                      # K8s manifests
│       ├── namespace.yaml
│       ├── deployment.yaml
│       ├── service.yaml
│       ├── ingress.yaml
│       ├── secrets.yaml
│       └── hpa.yaml
├── docs/                                # Documentation
├── examples/                            # Code examples
└── src/                                 # Source code
```

---

## การติดตั้ง

### 1. Clone Repository

```bash
git clone <repository-url>
cd mcp-hierarchical-agents
```

### 2. ติดตั้ง Dependencies

```bash
npm install
```

### 3. ตั้งค่า Environment

```bash
cp config/.env.example .env
# แก้ไข .env ตามต้องการ
```

### 4. รัน Database (Docker)

```bash
cd config
docker-compose up -d postgres redis neo4j rabbitmq
```

### 5. รัน Migration

```bash
npm run migrate
```

### 6. รัน Development Server

```bash
npm run dev
```

---

## การใช้งาน

### การใช้งานกับ Kimi CLI

1. คัดลอก `cline_mcp_settings.json` ไปยังโฟลเดอร์ `.kimi/` ของคุณ
2. รัน Kimi CLI
3. ใช้คำสั่ง MCP Tools ที่กำหนดไว้

### ตัวอย่างคำสั่ง

```bash
# สร้างโครงการใหม่
kimi mcp cto-agent create_project --name "my-app" --description "My new app"

# มอบหมายงานให้แผนก
kimi mcp cto-agent assign_to_department --department "frontend" --task "Create UI"

# ตรวจสอบสถานะ
kimi mcp cto-agent get_project_status --project-id "my-app"
```

---

## การ Deploy

### Deploy ด้วย Docker Compose

```bash
cd config
docker-compose up -d
```

### Deploy บน Kubernetes

```bash
cd config/kubernetes
kubectl apply -f namespace.yaml
kubectl apply -f secrets.yaml
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl apply -f ingress.yaml
kubectl apply -f hpa.yaml
```

---

## การ Monitor

### Prometheus
- URL: http://localhost:9090

### Grafana
- URL: http://localhost:3001
- Default credentials: admin/admin

### Jaeger
- URL: http://localhost:16686

---

## การทดสอบ

```bash
# Unit tests
npm run test

# Coverage
npm run test:coverage

# E2E tests
npm run test:e2e
```

---

## การมีส่วนร่วม

1. Fork repository
2. สร้าง branch ใหม่ (`git checkout -b feature/my-feature`)
3. Commit การเปลี่ยนแปลง (`git commit -am 'Add new feature'`)
4. Push ไปยัง branch (`git push origin feature/my-feature`)
5. สร้าง Pull Request

---

## License

MIT License

---

*สร้างเมื่อ: 2026-04-09*
*Version: 3.0 - Production Ready*
