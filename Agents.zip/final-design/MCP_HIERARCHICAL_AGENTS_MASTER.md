# MCP Hierarchical Agents - Master Design Document
## เอกสารออกแบบระบบ Agents แบบลำดับชั้นสำหรับงานเขียนโค้ด (ฉบับสมบูรณ์)

---

**Version:** 3.0 (Production Ready)  
**Last Updated:** 2026-04-09  
**Status:** Ready for Development

---

## 📋 Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [System Architecture](#2-system-architecture)
3. [Agent Hierarchy](#3-agent-hierarchy)
4. [Database Schema](#4-database-schema)
5. [Security Architecture](#5-security-architecture)
6. [Error Handling](#6-error-handling)
7. [Workflow System](#7-workflow-system)
8. [Memory & Learning](#8-memory--learning)
9. [Communication](#9-communication)
10. [Testing Strategy](#10-testing-strategy)
11. [Deployment](#11-deployment)
12. [Monitoring](#12-monitoring)
13. [Configuration](#13-configuration)
14. [Implementation Roadmap](#14-implementation-roadmap)

---

## 1. Executive Summary

### 1.1 วัตถุประสงค์

สร้างระบบ MCP (Model Context Protocol) Agents ที่มีโครงสร้างแบบลำดับชั้น (Hierarchical) สำหรับงานเขียนโค้ด โดยจำลองโครงสร้างบริษัทเทคโนโลยีที่มี CTO, หัวหน้าแผนก และผู้ปฏิบัติงาน

### 1.2 สถิติระบบ

| Component | Count |
|-----------|-------|
| **Total Agents** | 26 |
| **Hierarchy Levels** | 3 |
| **Departments** | 5 |
| **CTO** | 1 |
| **Department Heads** | 5 |
| **Workers** | 20 |
| **MCP Tools** | 50+ |
| **Task States** | 14 |
| **Quality Gates** | 4 |

### 1.3 Key Features

- ✅ **Hierarchical Organization** - โครงสร้างลำดับชั้นชัดเจน
- ✅ **Memory & Knowledge** - ระบบความจำและความรู้
- ✅ **AI Parliament** - ระบบถกเถียงและตัดสินใจร่วมกัน
- ✅ **Swarm Intelligence** - การทำงานแบบฝูง
- ✅ **Self-Learning** - การเรียนรู้และพัฒนาตนเอง
- ✅ **Agent Sandbox** - Working Memory กับ Checkpoint Reread
- ✅ **Advanced Communication** - 6 รูปแบบการสื่อสาร

---

## 2. System Architecture

### 2.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         MCP HIERARCHICAL AGENTS                              │
│                         ระบบ Agents แบบลำดับชั้น                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  LAYER 1: STRATEGIC (CTO Agent - 1)                                  │   │
│  │  • กำหนดทิศทางเทคโนโลยี                                              │   │
│  │  • จ่ายงานให้ Department Heads                                      │   │
│  │  • ตัดสินใจเรื่องสำคัญผ่าน AI Parliament                            │   │
│  │  • รับรายงานผลและอนุมัติ                                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│           ┌────────────────────────┼────────────────────────┐               │
│           │                        │                        │               │
│           ▼                        ▼                        ▼               │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐         │
│  │  MEMORY &       │    │  AI PARLIAMENT  │    │  SWARM          │         │
│  │  KNOWLEDGE      │    │  & DEBATE       │    │  COORDINATION   │         │
│  │  SYSTEM         │    │  SYSTEM         │    │  SYSTEM         │         │
│  └─────────────────┘    └─────────────────┘    └─────────────────┘         │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  LAYER 2: TACTICAL (Department Head Swarms - 5)                    │   │
│  │                                                                      │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐             │   │
│  │  │ Frontend │  │ Backend  │  │  DevOps  │  │    QA    │             │   │
│  │  │  Head    │  │  Head    │  │  Head    │  │  Head    │             │   │
│  │  │ (4 W)    │  │ (4 W)    │  │ (4 W)    │  │ (4 W)    │             │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘             │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  LAYER 3: EXECUTION (Worker Agents - 20)                             │   │
│  │  • Frontend Workers: React, Vue, CSS, UI/UX                         │   │
│  │  • Backend Workers: API, Database, Auth, Integration                │   │
│  │  • DevOps Workers: CI/CD, Infrastructure, Monitoring, Security      │   │
│  │  • QA Workers: Test, Automation, Performance, Security Test         │   │
│  │  • PM Workers: Requirements, Task, Documentation, Communication     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  SHARED INFRASTRUCTURE                                               │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   PostgreSQL │  │   Redis      │  │   Neo4j      │              │   │
│  │  │   (Primary)  │  │   (Cache)    │  │   (Graph)    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   RabbitMQ   │  │   Pinecone   │  │   Git        │              │   │
│  │  │   (Message)  │  │   (Vector)   │  │   (Code)     │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Technology Stack

| Layer | Technology |
|-------|------------|
| **Backend** | Node.js 20+, TypeScript 5+ |
| **Database** | PostgreSQL 15+, Redis 7+, Neo4j 5+ |
| **Message Queue** | RabbitMQ 3.12+ |
| **Vector DB** | Pinecone / pgvector |
| **Container** | Docker 24+, Kubernetes 1.28+ |
| **Monitoring** | Prometheus, Grafana, Jaeger |
| **Security** | JWT, OAuth 2.0, mTLS |

---

## 3. Agent Hierarchy

### 3.1 Organization Chart (26 Agents)

```
                              ┌─────────┐
                              │   CTO   │ (1)
                              │  Agent  │
                              └────┬────┘
                                   │
          ┌────────────────────────┼────────────────────────┐
          │                        │                        │
          ▼                        ▼                        ▼
    ┌──────────┐            ┌──────────┐            ┌──────────┐
    │ Frontend │            │ Backend  │            │  DevOps  │
    │  Head    │            │  Head    │            │  Head    │
    │ (1)      │            │ (1)      │            │ (1)      │
    └────┬─────┘            └────┬─────┘            └────┬─────┘
         │                       │                       │
    ┌────┴────┐             ┌────┴────┐             ┌────┴────┐
    │         │             │         │             │         │
    ▼         ▼             ▼         ▼             ▼         ▼
 ┌──────┐ ┌──────┐      ┌──────┐ ┌──────┐      ┌──────┐ ┌──────┐
 │React │ │Vue   │      │API   │ │DB    │      │CI/CD │ │Infra │
 │Agent │ │Agent │      │Agent │ │Agent │      │Agent │ │Agent │
 │(1)   │ │(1)   │      │(1)   │ │(1)   │      │(1)   │ │(1)   │
 └──────┘ └──────┘      └──────┘ └──────┘      └──────┘ └──────┘
    │         │             │         │             │         │
    ▼         ▼             ▼         ▼             ▼         ▼
 ┌──────┐ ┌──────┐      ┌──────┐ ┌──────┐      ┌──────┐ ┌──────┐
 │CSS   │ │UI/UX │      │Auth  │ │Integ │      │Monit │ │Sec   │
 │Agent │ │Agent │      │Agent │ │Agent │      │Agent │ │Agent │
 │(1)   │ │(1)   │      │(1)   │ │(1)   │      │(1)   │ │(1)   │
 └──────┘ └──────┘      └──────┘ └──────┘      └──────┘ └──────┘

    ┌──────────┐            ┌──────────┐
    │    QA    │            │    PM    │
    │  Head    │            │  Head    │
    │ (1)      │            │ (1)      │
    └────┬─────┘            └────┬─────┘
         │                       │
    ┌────┴────┐             ┌────┴────┐
    │         │             │         │
    ▼         ▼             ▼         ▼
 ┌──────┐ ┌──────┐      ┌──────┐ ┌──────┐
 │Test  │ │Auto  │      │Req   │ │Task  │
 │Agent │ │Test  │      │Agent │ │Agent │
 │(1)   │ │(1)   │      │(1)   │ │(1)   │
 └──────┘ └──────┘      └──────┘ └──────┘
    │         │             │         │
    ▼         ▼             ▼         ▼
 ┌──────┐ ┌──────┐      ┌──────┐ ┌──────┐
 │Perf  │ │Sec   │      │Doc   │ │Comm  │
 │Agent │ │Test  │      │Agent │ │Agent │
 │(1)   │ │(1)   │      │(1)   │ │(1)   │
 └──────┘ └──────┘      └──────┘ └──────┘

Total: 1 + 5 + 20 = 26 Agents
```

### 3.2 Agent Definitions

| Level | Role | Count | Responsibilities |
|-------|------|-------|------------------|
| 1 | CTO | 1 | Strategic decisions, resource allocation, final approval |
| 2 | Frontend Head | 1 | Frontend architecture, code review, team coordination |
| 2 | Backend Head | 1 | Backend architecture, API design, database decisions |
| 2 | DevOps Head | 1 | Infrastructure, CI/CD, security, monitoring |
| 2 | QA Head | 1 | Test strategy, quality gates, automation |
| 2 | PM Head | 1 | Requirements, timeline, documentation |
| 3 | Workers | 20 | Task execution, implementation, testing |

---

## 4. Database Schema

### 4.1 Entity Relationship Diagram

```
┌──────────┐       ┌──────────┐       ┌──────────┐
│  Agent   │───────│  Task    │───────│  Project │
│          │  1:N  │          │  N:1  │          │
└──────────┘       └──────────┘       └──────────┘
      │                  │
      │             ┌────┴────┐
      │             │ Subtask │
      │             └─────────┘
      │
      │             ┌──────────┐       ┌──────────┐
      └─────────────│  Memory  │───────│ Knowledge│
             1:N    │          │  N:M  │          │
                    └──────────┘       └──────────┘

┌──────────┐       ┌──────────┐       ┌──────────┐
│  Message │───────│ Session  │───────│  Vote    │
│          │  N:1  │          │  1:N  │          │
└──────────┘       └──────────┘       └──────────┘
```

### 4.2 PostgreSQL Schema

```sql
-- ==================== CORE TABLES ====================

-- Agents Table
CREATE TABLE agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL CHECK (type IN ('cto', 'department_head', 'worker')),
    department VARCHAR(50) CHECK (department IN ('frontend', 'backend', 'devops', 'qa', 'pm')),
    level INTEGER NOT NULL CHECK (level IN (1, 2, 3)),
    capabilities JSONB DEFAULT '[]',
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Projects Table
CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    status VARCHAR(20) DEFAULT 'planning' CHECK (status IN ('planning', 'in_progress', 'completed', 'cancelled')),
    tech_stack JSONB DEFAULT '[]',
    created_by UUID REFERENCES agents(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tasks Table
CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id VARCHAR(50) UNIQUE NOT NULL,
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    parent_task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL CHECK (type IN ('feature', 'bug', 'refactor', 'test')),
    priority VARCHAR(20) DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'critical')),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('draft', 'pending', 'assigned', 'in_progress', 'blocked', 'reviewing', 'completed', 'approved', 'rejected', 'closed')),
    assigned_to UUID REFERENCES agents(id),
    created_by UUID REFERENCES agents(id),
    requirements JSONB DEFAULT '{}',
    acceptance_criteria JSONB DEFAULT '[]',
    estimated_hours INTEGER,
    actual_hours INTEGER,
    due_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Task Dependencies
CREATE TABLE task_dependencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
    depends_on_task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
    dependency_type VARCHAR(20) DEFAULT 'blocks',
    UNIQUE(task_id, depends_on_task_id)
);

-- ==================== MEMORY TABLES ====================

-- Working Memory
CREATE TABLE working_memory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
    session_id VARCHAR(100) NOT NULL,
    memory_type VARCHAR(50) NOT NULL CHECK (memory_type IN ('working', 'short_term', 'long_term')),
    key VARCHAR(200) NOT NULL,
    value JSONB NOT NULL,
    importance DECIMAL(3,2) DEFAULT 0.5,
    ttl_seconds INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    UNIQUE(agent_id, session_id, key)
);

-- Episodic Memory
CREATE TABLE episodic_memory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
    event_id VARCHAR(100) UNIQUE NOT NULL,
    task_id UUID REFERENCES tasks(id),
    event_type VARCHAR(50) NOT NULL,
    content JSONB NOT NULL,
    importance DECIMAL(3,2) DEFAULT 0.5,
    embedding VECTOR(1536),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_episodic_memory_embedding ON episodic_memory USING ivfflat (embedding vector_cosine_ops);

-- ==================== COMMUNICATION TABLES ====================

-- Messages
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id VARCHAR(100) UNIQUE NOT NULL,
    from_agent_id UUID REFERENCES agents(id),
    to_type VARCHAR(20) NOT NULL,
    to_target JSONB NOT NULL,
    message_type VARCHAR(50) NOT NULL,
    payload JSONB NOT NULL,
    priority VARCHAR(20) DEFAULT 'normal',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==================== KNOWLEDGE TABLES ====================

-- Skills
CREATE TABLE skills (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    skill_id VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    domain JSONB DEFAULT '[]',
    difficulty VARCHAR(20),
    context JSONB DEFAULT '{}',
    stats JSONB DEFAULT '{"usage_count": 0, "success_count": 0, "average_reward": 0}',
    version INTEGER DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==================== WORKFLOW TABLES ====================

-- Workflow Definitions
CREATE TABLE workflow_definitions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    type VARCHAR(50) NOT NULL,
    definition JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Workflow Instances
CREATE TABLE workflow_instances (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    instance_id VARCHAR(100) UNIQUE NOT NULL,
    workflow_id UUID REFERENCES workflow_definitions(id),
    status VARCHAR(20) DEFAULT 'running',
    context JSONB DEFAULT '{}',
    current_step VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==================== AUDIT ====================

-- Audit Log
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type VARCHAR(50) NOT NULL,
    entity_id VARCHAR(100) NOT NULL,
    action VARCHAR(100) NOT NULL,
    actor_id UUID REFERENCES agents(id),
    details JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_created_at ON audit_logs(created_at);

-- Update trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON agents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

### 4.3 Neo4j Schema (Knowledge Graph)

```cypher
-- Nodes
CREATE CONSTRAINT agent_id IF NOT EXISTS FOR (a:Agent) REQUIRE a.agent_id IS UNIQUE;
CREATE CONSTRAINT knowledge_id IF NOT EXISTS FOR (k:Knowledge) REQUIRE k.knowledge_id IS UNIQUE;
CREATE CONSTRAINT task_id IF NOT EXISTS FOR (t:Task) REQUIRE t.task_id IS UNIQUE;

-- Relationships
// (Agent)-[:REPORTS_TO]->(Agent)
// (Agent)-[:KNOWS]->(Knowledge)
// (Knowledge)-[:DEPENDS_ON]->(Knowledge)
// (Task)-[:DEPENDS_ON]->(Task)
```

### 4.4 Redis Key Structure

```
# Working Memory
agent:{agent_id}:working:{key} -> JSON (TTL: 1h)
agent:{agent_id}:session:{session_id} -> Hash (TTL: 24h)

# Cache
task:{task_id} -> JSON (TTL: 5m)
agent:{agent_id}:status -> String (TTL: 30s)

# Pub/Sub
agent:{agent_id}:inbox
session:{session_id}:updates

# Rate Limiting
ratelimit:agent:{agent_id}:{action} -> Counter (TTL: 1m)

# Locks
lock:task:{task_id} -> {agent_id} (TTL: 5m)
```

---

## 5. Security Architecture

### 5.1 Authentication Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    AUTHENTICATION & AUTHORIZATION                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  1. AGENT REGISTRATION                                                       │
│  New Agent → Generate Key Pair → Submit CSR → CTO Signs → Certificate        │
│                                                                              │
│  2. AUTHENTICATION                                                           │
│  Agent → Present Certificate → Verify Signature → Issue JWT Token            │
│                                                                              │
│  3. AUTHORIZATION (RBAC)                                                     │
│  Agent → Present JWT → Verify Claims → Check Permissions → Allow/Deny        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Authorization Matrix

```typescript
const RBAC_MATRIX = {
  cto: {
    can_create_project: true,
    can_assign_to_department: true,
    can_review_deliverable: true,
    can_make_decision: true,
    can_escalate_issue: true,
    can_approve_changes: true,
    can_set_priority: true,
    can_generate_report: true,
    can_manage_agents: true,
    can_view_all_tasks: true
  },
  department_head: {
    can_create_project: false,
    can_assign_to_department: false,
    can_assign_to_worker: true,
    can_review_code: true,
    can_request_changes: true,
    can_report_progress: true,
    can_validate_deliverable: true,
    can_set_deadline: true,
    can_escalate_to_cto: true,
    can_view_department_tasks: true
  },
  worker: {
    can_create_project: false,
    can_assign_to_department: false,
    can_assign_to_worker: false,
    can_implement_code: true,
    can_run_tests: true,
    can_submit_task: true,
    can_request_clarification: true,
    can_update_status: true,
    can_self_validate: true,
    can_view_own_tasks: true
  }
};
```

### 5.3 Security Measures

| Layer | Measure |
|-------|---------|
| Transport | TLS 1.3 |
| Authentication | mTLS + JWT |
| Authorization | RBAC |
| Data at Rest | AES-256 |
| Secrets | HashiCorp Vault |
| Audit | Full logging |

---

## 6. Error Handling

### 6.1 Error Classification

```typescript
enum ErrorType {
  // Recoverable
  TRANSIENT_NETWORK_ERROR = 'TRANSIENT_NETWORK_ERROR',
  RATE_LIMIT_EXCEEDED = 'RATE_LIMIT_EXCEEDED',
  SERVICE_UNAVAILABLE = 'SERVICE_UNAVAILABLE',
  TIMEOUT = 'TIMEOUT',
  
  // Non-recoverable
  INVALID_INPUT = 'INVALID_INPUT',
  PERMISSION_DENIED = 'PERMISSION_DENIED',
  RESOURCE_NOT_FOUND = 'RESOURCE_NOT_FOUND',
  VALIDATION_FAILED = 'VALIDATION_FAILED',
  
  // Agent-specific
  AGENT_CRASHED = 'AGENT_CRASHED',
  AGENT_TIMEOUT = 'AGENT_TIMEOUT',
  AGENT_MEMORY_EXCEEDED = 'AGENT_MEMORY_EXCEEDED'
}
```

### 6.2 Retry Policies

```typescript
const RETRY_POLICIES = {
  TRANSIENT_NETWORK_ERROR: { max_attempts: 5, backoff: 'exponential', delay: 1000 },
  RATE_LIMIT_EXCEEDED: { max_attempts: 3, backoff: 'linear', delay: 5000 },
  SERVICE_UNAVAILABLE: { max_attempts: 10, backoff: 'exponential', delay: 2000 },
  TIMEOUT: { max_attempts: 3, backoff: 'linear', delay: 1000 },
  INVALID_INPUT: { max_attempts: 1 },
  PERMISSION_DENIED: { max_attempts: 1 }
};
```

### 6.3 Circuit Breaker

```typescript
class CircuitBreaker {
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';
  private failureCount = 0;
  
  constructor(private config: {
    failureThreshold: number;
    successThreshold: number;
    timeoutMs: number;
  }) {}
  
  async execute<T>(fn: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (this.shouldAttemptReset()) {
        this.state = 'HALF_OPEN';
      } else {
        throw new Error('Circuit breaker is OPEN');
      }
    }
    
    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }
}
```

---

## 7. Workflow System

### 7.1 Workflow Types

| Type | Description | Use Case |
|------|-------------|----------|
| Sequential | Step-by-step execution | Feature development |
| Parallel | Concurrent execution | Multi-team projects |
| Iterative | Cyclic improvement | Agile sprints |
| Event-Driven | Trigger-based | CI/CD pipelines |

### 7.2 Task State Machine

```
DRAFT → PENDING → ASSIGNED → IN_PROGRESS → COMPLETED → CLOSED
              ↓           ↓
          BLOCKED    REJECTED → (retry)
```

### 7.3 Quality Gates

| Gate | Threshold | Responsible |
|------|-----------|-------------|
| Requirements | 100% complete | Department Head |
| Self-Validation | 0.80 | Worker |
| Code Review | 0.90 | Department Head |
| Final Approval | 0.85 | CTO |

---

## 8. Memory & Learning

### 8.1 Memory Hierarchy

| Layer | Capacity | Duration | Access |
|-------|----------|----------|--------|
| Working | 4-7 items | Task duration | < 10ms |
| Short-term | 20-30 items | Session (hours) | < 100ms |
| Long-term | Unlimited | Permanent | < 500ms |

### 8.2 Self-Learning Loop

```
EXECUTE → OBSERVE → REFLECT → IMPROVE → (loop)
```

### 8.3 Feedback Sources

- Automated Metrics
- Peer Review
- Human Feedback
- Self-Assessment

---

## 9. Communication

### 9.1 Communication Patterns

| Pattern | Use Case |
|---------|----------|
| Point-to-Point | Direct instructions |
| Broadcast | Announcements |
| Multicast | Department-specific |
| Pub-Sub | Event-driven |
| Request-Reply | Synchronous queries |
| Pipeline | Multi-stage processing |

### 9.2 Message Priority

| Priority | SLA |
|----------|-----|
| CRITICAL (P0) | < 100ms |
| HIGH (P1) | < 1s |
| NORMAL (P2) | < 5s |
| LOW (P3) | < 1min |

---

## 10. Testing Strategy

### 10.1 Testing Pyramid

```
         ┌─────────┐
         │   E2E   │  10%
        ┌┴─────────┴┐
        │ Integration│  30%
       ┌┴────────────┴┐
       │     Unit      │  60%
       └───────────────┘
```

### 10.2 Test Types

| Type | Coverage | Tools |
|------|----------|-------|
| Unit | 80%+ | Jest |
| Integration | 70%+ | Supertest |
| E2E | 50%+ | Playwright |
| Load | - | k6 |
| Chaos | - | Chaos Monkey |

---

## 11. Deployment

### 11.1 Infrastructure

```
┌─────────────────────────────────────────────────────────┐
│  Kubernetes Cluster                                     │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐    │
│  │  MCP Server │  │   Agents    │  │  Workflow   │    │
│  │   (3 pods)  │  │   (5 pods)  │  │   Engine    │    │
│  └─────────────┘  └─────────────┘  └─────────────┘    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐    │
│  │   Memory    │  │  Knowledge  │  │ Communication│   │
│  │   Service   │  │   Service   │  │   Service   │    │
│  └─────────────┘  └─────────────┘  └─────────────┘    │
└─────────────────────────────────────────────────────────┘
```

### 11.2 CI/CD Pipeline

```
Code Commit → Build → Test → Security Scan → Deploy Staging → E2E Test → Deploy Prod
```

---

## 12. Monitoring

### 12.1 Metrics

| Category | Metrics |
|----------|---------|
| Performance | Latency, Throughput, Error Rate |
| Resources | CPU, Memory, Disk, Network |
| Business | Task Completion, Success Rate |

### 12.2 Tools

| Purpose | Tool |
|---------|------|
| Metrics | Prometheus |
| Visualization | Grafana |
| Tracing | Jaeger |
| Logging | ELK Stack |
| Alerting | PagerDuty |

---

## 13. Configuration

### 13.1 Environment Variables

```bash
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/mcp_agents
REDIS_URL=redis://localhost:6379
NEO4J_URL=bolt://localhost:7687

# Security
JWT_SECRET=your-secret-key
ENCRYPTION_KEY=your-encryption-key

# LLM
OPENAI_API_KEY=your-openai-key
ANTHROPIC_API_KEY=your-anthropic-key

# Monitoring
PROMETHEUS_PORT=9090
GRAFANA_PORT=3000
```

### 13.2 MCP Settings

```json
{
  "mcpServers": {
    "hierarchical-agents": {
      "command": "node",
      "args": ["/app/dist/server.js"],
      "env": {
        "AGENT_MAX_DEPTH": "3",
        "AGENT_TIMEOUT_MS": "30000"
      }
    }
  }
}
```

---

## 14. Implementation Roadmap

### Phase 1: Foundation (Weeks 1-2)
- Setup infrastructure
- Implement basic MCP server
- Create agent templates

### Phase 2: Core Features (Weeks 3-4)
- Memory system
- Workflow engine
- Communication protocol

### Phase 3: Advanced Features (Weeks 5-6)
- AI Parliament
- Swarm coordination
- Self-learning

### Phase 4: Polish (Weeks 7-8)
- Testing
- Documentation
- Performance optimization

---

## Appendix

### A. File Structure

```
final-design/
├── MCP_HIERARCHICAL_AGENTS_MASTER.md
├── docs/
│   ├── 01_ARCHITECTURE.md
│   ├── 02_DATABASE.md
│   ├── 03_SECURITY.md
│   ├── 04_ERROR_HANDLING.md
│   ├── 05_TESTING.md
│   ├── 06_DEPLOYMENT.md
│   └── 07_MONITORING.md
├── config/
│   ├── cline_mcp_settings.json
│   ├── docker-compose.yml
│   └── .env.example
├── examples/
│   └── workflow-examples/
└── src/
    └── (implementation)
```

### B. References

1. MCP Specification: https://modelcontextprotocol.io
2. GitHub: coordinated-agent-team
3. GitHub: claude-code-ultimate-guide
4. GitHub: agno-agi/dash

---

*สร้างเมื่อ: 2026-04-09*
*Version: 3.0 - Production Ready*
