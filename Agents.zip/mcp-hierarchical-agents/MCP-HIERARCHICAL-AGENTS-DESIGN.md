# MCP Server Design: Hierarchical Agents for Code Development

## 1. Architecture Overview

### 1.1 System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           MCP Hierarchical Agents                           │
│                              (Organization Structure)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         CTO Agent (Level 0)                          │   │
│  │  ┌─────────────────────────────────────────────────────────────┐   │   │
│  │  │  Responsibilities:                                           │   │   │
│  │  │  • Strategic planning & architecture decisions               │   │   │
│  │  │  • Department coordination                                   │   │   │
│  │  │  • High-level project assignment                             │   │   │
│  │  │  • Final code review & approval                              │   │   │
│  │  └─────────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                              │
│           ┌──────────────────┼──────────────────┐                          │
│           ▼                  ▼                  ▼                          │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐              │
│  │  Frontend Head  │ │   Backend Head  │ │   DevOps Head   │              │
│  │   (Level 1)     │ │   (Level 1)     │ │   (Level 1)     │              │
│  └────────┬────────┘ └────────┬────────┘ └────────┬────────┘              │
│           │                   │                   │                        │
│     ┌─────┴─────┐       ┌─────┴─────┐       ┌─────┴─────┐                 │
│     ▼           ▼       ▼           ▼       ▼           ▼                 │
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐              │
│  │Worker│  │Worker│  │Worker│  │Worker│  │Worker│  │Worker│              │
│  │(L2)  │  │(L2)  │  │(L2)  │  │(L2)  │  │(L2)  │  │(L2)  │              │
│  └──┬───┘  └──┬───┘  └──┬───┘  └──┬───┘  └──┬───┘  └──┬───┘              │
│     │         │         │         │         │         │                    │
│     └─────────┴─────────┴─────────┴─────────┴─────────┘                    │
│                              │                                              │
│                              ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     Shared Resources & Services                      │   │
│  │  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐        │   │
│  │  │  Task     │  │  Agent    │  │  Code     │  │  Report   │        │   │
│  │  │  Queue    │  │  Registry │  │  Repository│  │  Store    │        │   │
│  │  └───────────┘  └───────────┘  └───────────┘  └───────────┘        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 Agent Hierarchy Levels

| Level | Role | Scope | Decision Authority |
|-------|------|-------|-------------------|
| 0 | CTO | Organization-wide | Strategic decisions, architecture approval |
| 1 | Department Head | Department-wide | Technical decisions, task delegation |
| 2 | Worker | Task-specific | Implementation decisions, code execution |

### 1.3 Communication Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    Communication Patterns                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. TOP-DOWN (Assignment):                                       │
│     CTO ──► Dept Head ──► Worker                                 │
│     [create_project] [delegate_task] [execute_task]              │
│                                                                  │
│  2. BOTTOM-UP (Reporting):                                       │
│     Worker ──► Dept Head ──► CTO                                 │
│     [report_progress] [submit_code] [request_review]             │
│                                                                  │
│  3. HORIZONTAL (Collaboration):                                  │
│     Worker A ◄──► Worker B (same department)                     │
│     [share_knowledge] [code_review]                              │
│                                                                  │
│  4. CROSS-DEPARTMENT:                                            │
│     Frontend ◄──► Backend (via Department Heads)                 │
│     [api_contract] [integration_plan]                            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. Data Models & Schemas

### 2.1 Agent Registry Schema

```typescript
// schemas/agent-registry.ts

/**
 * Agent Role Definition
 */
export enum AgentRole {
  CTO = 'cto',
  FRONTEND_HEAD = 'frontend_head',
  BACKEND_HEAD = 'backend_head',
  DEVOPS_HEAD = 'devops_head',
  QA_HEAD = 'qa_head',
  FRONTEND_WORKER = 'frontend_worker',
  BACKEND_WORKER = 'backend_worker',
  DEVOPS_WORKER = 'devops_worker',
  QA_WORKER = 'qa_worker',
}

/**
 * Agent Level in Hierarchy
 */
export enum AgentLevel {
  EXECUTIVE = 0,    // CTO
  MANAGEMENT = 1,   // Department Heads
  WORKER = 2,       // Individual contributors
}

/**
 * Agent Status
 */
export enum AgentStatus {
  IDLE = 'idle',
  BUSY = 'busy',
  OFFLINE = 'offline',
  ERROR = 'error',
}

/**
 * Agent Metadata
 */
export interface AgentMetadata {
  skills: string[];
  specialties: string[];
  experience_level: 'junior' | 'mid' | 'senior';
  max_concurrent_tasks: number;
  preferred_languages: string[];
  frameworks: string[];
}

/**
 * Agent Definition
 */
export interface Agent {
  id: string;
  name: string;
  role: AgentRole;
  level: AgentLevel;
  department: string;
  parent_id: string | null;      // Parent agent ID (null for CTO)
  child_ids: string[];           // Child agent IDs
  status: AgentStatus;
  metadata: AgentMetadata;
  created_at: string;
  updated_at: string;
  last_heartbeat: string;
}

/**
 * Agent Registration Request
 */
export interface RegisterAgentRequest {
  name: string;
  role: AgentRole;
  department: string;
  parent_id: string;
  metadata: AgentMetadata;
}

/**
 * Agent Registration Response
 */
export interface RegisterAgentResponse {
  agent: Agent;
  assigned_tools: string[];
  accessible_resources: string[];
}
```

### 2.2 Task/Project Structure Schema

```typescript
// schemas/task-structure.ts

/**
 * Task Priority Levels
 */
export enum TaskPriority {
  CRITICAL = 'critical',
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low',
}

/**
 * Task Status
 */
export enum TaskStatus {
  PENDING = 'pending',
  ASSIGNED = 'assigned',
  IN_PROGRESS = 'in_progress',
  IN_REVIEW = 'in_review',
  COMPLETED = 'completed',
  BLOCKED = 'blocked',
  CANCELLED = 'cancelled',
}

/**
 * Task Type
 */
export enum TaskType {
  FEATURE = 'feature',
  BUGFIX = 'bugfix',
  REFACTOR = 'refactor',
  DOCUMENTATION = 'documentation',
  TESTING = 'testing',
  DEPLOYMENT = 'deployment',
  RESEARCH = 'research',
}

/**
 * Code Change
 */
export interface CodeChange {
  file_path: string;
  change_type: 'create' | 'modify' | 'delete';
  content?: string;
  diff?: string;
  language: string;
}

/**
 * Task Requirements
 */
export interface TaskRequirements {
  description: string;
  acceptance_criteria: string[];
  technical_requirements?: string[];
  dependencies?: string[];
  estimated_effort_hours?: number;
}

/**
 * Task Definition
 */
export interface Task {
  id: string;
  project_id: string;
  parent_task_id?: string;
  subtask_ids: string[];
  
  // Assignment
  created_by: string;
  assigned_to?: string;
  delegated_by?: string;
  
  // Task Details
  title: string;
  type: TaskType;
  priority: TaskPriority;
  status: TaskStatus;
  requirements: TaskRequirements;
  
  // Code-related
  branch_name?: string;
  code_changes: CodeChange[];
  
  // Timestamps
  created_at: string;
  updated_at: string;
  started_at?: string;
  completed_at?: string;
  deadline?: string;
  
  // Progress
  progress_percentage: number;
  notes: string[];
  blockers?: string[];
}

/**
 * Project Definition
 */
export interface Project {
  id: string;
  name: string;
  description: string;
  created_by: string;  // CTO ID
  
  // Structure
  departments_involved: string[];
  root_task_ids: string[];
  
  // Status
  status: 'planning' | 'active' | 'completed' | 'archived';
  
  // Configuration
  repository_url?: string;
  default_branch: string;
  
  // Timestamps
  created_at: string;
  updated_at: string;
  target_completion?: string;
}

/**
 * Create Task Request
 */
export interface CreateTaskRequest {
  project_id: string;
  parent_task_id?: string;
  title: string;
  type: TaskType;
  priority: TaskPriority;
  requirements: TaskRequirements;
  assigned_to?: string;
  deadline?: string;
}

/**
 * Delegate Task Request
 */
export interface DelegateTaskRequest {
  task_id: string;
  delegate_to: string;
  instructions?: string;
}
```

### 2.3 Status/State Management Schema

```typescript
// schemas/state-management.ts

/**
 * Agent State
 */
export interface AgentState {
  agent_id: string;
  current_task_ids: string[];
  completed_task_ids: string[];
  queue_position: number;
  load_percentage: number;
  context: Record<string, any>;
}

/**
 * Task State Update
 */
export interface TaskStateUpdate {
  task_id: string;
  agent_id: string;
  status: TaskStatus;
  progress_percentage: number;
  message: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

/**
 * System State
 */
export interface SystemState {
  timestamp: string;
  total_agents: number;
  active_agents: number;
  total_tasks: number;
  pending_tasks: number;
  in_progress_tasks: number;
  completed_tasks: number;
  blocked_tasks: number;
  department_status: Record<string, {
    agent_count: number;
    task_count: number;
    avg_load: number;
  }>;
}

/**
 * Heartbeat Message
 */
export interface HeartbeatMessage {
  agent_id: string;
  timestamp: string;
  status: AgentStatus;
  current_task_id?: string;
  load_percentage: number;
  memory_usage?: number;
}
```

### 2.4 Report Schema

```typescript
// schemas/reports.ts

/**
 * Report Type
 */
export enum ReportType {
  PROGRESS = 'progress',
  COMPLETION = 'completion',
  ERROR = 'error',
  CODE_REVIEW = 'code_review',
  ARCHITECTURE = 'architecture',
  PERFORMANCE = 'performance',
}

/**
 * Code Review Report
 */
export interface CodeReviewReport {
  task_id: string;
  reviewer_id: string;
  files_reviewed: string[];
  findings: {
    severity: 'critical' | 'major' | 'minor' | 'info';
    file_path: string;
    line_number?: number;
    message: string;
    suggestion?: string;
  }[];
  approval_status: 'approved' | 'changes_requested' | 'rejected';
  overall_feedback: string;
}

/**
 * Progress Report
 */
export interface ProgressReport {
  task_id: string;
  agent_id: string;
  report_type: ReportType;
  period_start: string;
  period_end: string;
  
  // Summary
  summary: string;
  accomplishments: string[];
  challenges: string[];
  
  // Metrics
  tasks_completed: number;
  tasks_in_progress: number;
  tasks_blocked: number;
  code_lines_added: number;
  code_lines_removed: number;
  files_modified: number;
  
  // Next Steps
  next_steps: string[];
  estimated_completion?: string;
  
  // Blockers
  blockers?: {
    description: string;
    blocking_since: string;
    resolution_needed_from?: string;
  }[];
}

/**
 * Department Report
 */
export interface DepartmentReport {
  department: string;
  head_id: string;
  period_start: string;
  period_end: string;
  
  // Summary
  summary: string;
  
  // Worker Reports
  worker_reports: ProgressReport[];
  
  // Aggregated Metrics
  total_tasks: number;
  completed_tasks: number;
  avg_completion_time_hours: number;
  
  // Issues
  issues: string[];
  recommendations: string[];
}

/**
 * Executive Report (for CTO)
 */
export interface ExecutiveReport {
  period_start: string;
  period_end: string;
  
  // Organization Overview
  organization_summary: string;
  
  // Department Summaries
  department_reports: DepartmentReport[];
  
  // Key Metrics
  key_metrics: {
    total_projects: number;
    active_projects: number;
    completed_projects: number;
    total_agents: number;
    active_agents: number;
    avg_department_load: number;
    code_quality_score: number;
    on_time_delivery_rate: number;
  };
  
  // Strategic Items
  strategic_recommendations: string[];
  risks: string[];
  opportunities: string[];
}
```

---

## 3. Tool Specifications

### 3.1 CTO Level Tools

```typescript
// tools/cto-tools.ts

/**
 * CTO Tools - Strategic planning and organization management
 */

export const CTO_TOOLS = [
  {
    name: 'create_project',
    description: 'Create a new project with initial structure and department assignments',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Project name' },
        description: { type: 'string', description: 'Project description' },
        departments_involved: { 
          type: 'array', 
          items: { type: 'string' },
          description: 'Departments to involve (frontend, backend, devops, qa)'
        },
        technical_requirements: { type: 'string' },
        target_completion: { type: 'string', format: 'date-time' },
      },
      required: ['name', 'description', 'departments_involved']
    }
  },
  {
    name: 'assign_department_task',
    description: 'Assign a high-level task to a department head',
    inputSchema: {
      type: 'object',
      properties: {
        project_id: { type: 'string' },
        department: { type: 'string' },
        title: { type: 'string' },
        description: { type: 'string' },
        priority: { 
          type: 'string', 
          enum: ['critical', 'high', 'medium', 'low'],
          default: 'medium'
        },
        deadline: { type: 'string', format: 'date-time' },
      },
      required: ['project_id', 'department', 'title', 'description']
    }
  },
  {
    name: 'review_architecture',
    description: 'Review and approve architecture decisions from departments',
    inputSchema: {
      type: 'object',
      properties: {
        project_id: { type: 'string' },
        architecture_proposal: { type: 'string' },
        decision: { 
          type: 'string', 
          enum: ['approve', 'request_changes', 'reject']
        },
        feedback: { type: 'string' },
      },
      required: ['project_id', 'architecture_proposal', 'decision']
    }
  },
  {
    name: 'get_organization_status',
    description: 'Get comprehensive status of all departments and projects',
    inputSchema: {
      type: 'object',
      properties: {
        include_metrics: { type: 'boolean', default: true },
        include_active_tasks: { type: 'boolean', default: true },
      }
    }
  },
  {
    name: 'generate_executive_report',
    description: 'Generate executive report for the organization',
    inputSchema: {
      type: 'object',
      properties: {
        period_start: { type: 'string', format: 'date-time' },
        period_end: { type: 'string', format: 'date-time' },
        include_details: { type: 'boolean', default: false },
      },
      required: ['period_start', 'period_end']
    }
  },
  {
    name: 'coordinate_departments',
    description: 'Coordinate between departments for cross-functional tasks',
    inputSchema: {
      type: 'object',
      properties: {
        project_id: { type: 'string' },
        coordinating_departments: { 
          type: 'array', 
          items: { type: 'string' } 
        },
        coordination_type: { 
          type: 'string',
          enum: ['api_contract', 'integration', 'shared_component', 'deployment']
        },
        requirements: { type: 'string' },
      },
      required: ['project_id', 'coordinating_departments', 'coordination_type']
    }
  },
  {
    name: 'register_department_head',
    description: 'Register a new department head agent',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string' },
        department: { type: 'string' },
        role: { 
          type: 'string',
          enum: ['frontend_head', 'backend_head', 'devops_head', 'qa_head']
        },
        metadata: {
          type: 'object',
          properties: {
            skills: { type: 'array', items: { type: 'string' } },
            specialties: { type: 'array', items: { type: 'string' } },
            experience_level: { 
              type: 'string', 
              enum: ['junior', 'mid', 'senior'] 
            },
          }
        }
      },
      required: ['name', 'department', 'role']
    }
  }
];
```

### 3.2 Department Head (Manager) Tools

```typescript
// tools/manager-tools.ts

/**
 * Manager Tools - Department management and task delegation
 */

export const MANAGER_TOOLS = [
  {
    name: 'delegate_task',
    description: 'Delegate a task to a worker agent',
    inputSchema: {
      type: 'object',
      properties: {
        parent_task_id: { type: 'string' },
        worker_id: { type: 'string' },
        title: { type: 'string' },
        description: { type: 'string' },
        task_type: { 
          type: 'string',
          enum: ['feature', 'bugfix', 'refactor', 'documentation', 'testing']
        },
        priority: { 
          type: 'string',
          enum: ['critical', 'high', 'medium', 'low']
        },
        estimated_hours: { type: 'number' },
        technical_specs: { type: 'string' },
      },
      required: ['parent_task_id', 'worker_id', 'title', 'description']
    }
  },
  {
    name: 'create_subtask',
    description: 'Break down a task into subtasks',
    inputSchema: {
      type: 'object',
      properties: {
        parent_task_id: { type: 'string' },
        subtasks: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              title: { type: 'string' },
              description: { type: 'string' },
              assigned_to: { type: 'string' },
              estimated_hours: { type: 'number' },
            },
            required: ['title', 'description']
          }
        }
      },
      required: ['parent_task_id', 'subtasks']
    }
  },
  {
    name: 'review_worker_code',
    description: 'Review code submitted by a worker',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        worker_id: { type: 'string' },
        files: { 
          type: 'array', 
          items: { type: 'string' } 
        },
        review_criteria: {
          type: 'array',
          items: { 
            type: 'string',
            enum: ['code_quality', 'performance', 'security', 'testing', 'documentation']
          }
        }
      },
      required: ['task_id', 'worker_id', 'files']
    }
  },
  {
    name: 'get_department_status',
    description: 'Get status of all workers and tasks in the department',
    inputSchema: {
      type: 'object',
      properties: {
        include_worker_details: { type: 'boolean', default: true },
        include_task_details: { type: 'boolean', default: true },
        status_filter: {
          type: 'array',
          items: { 
            type: 'string',
            enum: ['pending', 'assigned', 'in_progress', 'in_review', 'completed', 'blocked']
          }
        }
      }
    }
  },
  {
    name: 'register_worker',
    description: 'Register a new worker agent in the department',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string' },
        role: { 
          type: 'string',
          enum: ['frontend_worker', 'backend_worker', 'devops_worker', 'qa_worker']
        },
        skills: { type: 'array', items: { type: 'string' } },
        specialties: { type: 'array', items: { type: 'string' } },
        experience_level: { 
          type: 'string',
          enum: ['junior', 'mid', 'senior']
        },
        max_concurrent_tasks: { type: 'number', default: 3 },
      },
      required: ['name', 'role']
    }
  },
  {
    name: 'submit_department_report',
    description: 'Submit progress report to CTO',
    inputSchema: {
      type: 'object',
      properties: {
        period_start: { type: 'string', format: 'date-time' },
        period_end: { type: 'string', format: 'date-time' },
        summary: { type: 'string' },
        accomplishments: { type: 'array', items: { type: 'string' } },
        challenges: { type: 'array', items: { type: 'string' } },
        issues: { type: 'array', items: { type: 'string' } },
        recommendations: { type: 'array', items: { type: 'string' } },
      },
      required: ['period_start', 'period_end', 'summary']
    }
  },
  {
    name: 'request_architecture_review',
    description: 'Request CTO review for architecture decisions',
    inputSchema: {
      type: 'object',
      properties: {
        project_id: { type: 'string' },
        proposal_title: { type: 'string' },
        proposal_description: { type: 'string' },
        technical_details: { type: 'string' },
        alternatives_considered: { type: 'array', items: { type: 'string' } },
        recommendation: { type: 'string' },
      },
      required: ['project_id', 'proposal_title', 'proposal_description']
    }
  },
  {
    name: 'escalate_issue',
    description: 'Escalate an issue to CTO',
    inputSchema: {
      type: 'object',
      properties: {
        issue_type: { 
          type: 'string',
          enum: ['resource', 'technical', 'conflict', 'deadline', 'other']
        },
        description: { type: 'string' },
        impact: { type: 'string' },
        suggested_resolution: { type: 'string' },
        task_id: { type: 'string' },
      },
      required: ['issue_type', 'description', 'impact']
    }
  }
];
```

### 3.3 Worker Level Tools

```typescript
// tools/worker-tools.ts

/**
 * Worker Tools - Task execution and code development
 */

export const WORKER_TOOLS = [
  {
    name: 'accept_task',
    description: 'Accept an assigned task and begin work',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        estimated_completion: { type: 'string', format: 'date-time' },
        initial_plan: { type: 'string' },
      },
      required: ['task_id']
    }
  },
  {
    name: 'write_code',
    description: 'Write or modify code files',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        files: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              path: { type: 'string' },
              content: { type: 'string' },
              action: { 
                type: 'string',
                enum: ['create', 'modify', 'delete']
              },
              language: { type: 'string' },
            },
            required: ['path', 'action']
          }
        },
        commit_message: { type: 'string' },
      },
      required: ['task_id', 'files']
    }
  },
  {
    name: 'run_tests',
    description: 'Run tests for the current task',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        test_type: { 
          type: 'string',
          enum: ['unit', 'integration', 'e2e', 'all'],
          default: 'all'
        },
        files_to_test: { type: 'array', items: { type: 'string' } },
      },
      required: ['task_id']
    }
  },
  {
    name: 'update_task_progress',
    description: 'Update progress on the current task',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        progress_percentage: { 
          type: 'number', 
          minimum: 0, 
          maximum: 100 
        },
        status: { 
          type: 'string',
          enum: ['in_progress', 'in_review', 'blocked']
        },
        message: { type: 'string' },
        blockers: { type: 'array', items: { type: 'string' } },
      },
      required: ['task_id', 'progress_percentage']
    }
  },
  {
    name: 'submit_for_review',
    description: 'Submit completed work for manager review',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        summary: { type: 'string' },
        files_changed: { type: 'array', items: { type: 'string' } },
        testing_done: { type: 'string' },
        notes_for_reviewer: { type: 'string' },
      },
      required: ['task_id', 'summary', 'files_changed']
    }
  },
  {
    name: 'request_help',
    description: 'Request help from manager or other workers',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        help_type: { 
          type: 'string',
          enum: ['technical', 'clarification', 'review', 'resource']
        },
        description: { type: 'string' },
        urgency: { 
          type: 'string',
          enum: ['low', 'medium', 'high', 'critical'],
          default: 'medium'
        },
      },
      required: ['task_id', 'help_type', 'description']
    }
  },
  {
    name: 'research_solution',
    description: 'Research solutions or best practices',
    inputSchema: {
      type: 'object',
      properties: {
        topic: { type: 'string' },
        context: { type: 'string' },
        constraints: { type: 'array', items: { type: 'string' } },
      },
      required: ['topic']
    }
  },
  {
    name: 'document_code',
    description: 'Add documentation to code',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        files: { type: 'array', items: { type: 'string' } },
        documentation_type: { 
          type: 'string',
          enum: ['inline', 'readme', 'api_docs', 'all']
        },
      },
      required: ['task_id', 'files']
    }
  },
  {
    name: 'get_task_details',
    description: 'Get detailed information about a task',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        include_history: { type: 'boolean', default: true },
      },
      required: ['task_id']
    }
  }
];
```

---

## 4. Communication Protocol

### 4.1 Message Types

```typescript
// protocol/messages.ts

/**
 * Base Message Interface
 */
export interface BaseMessage {
  id: string;
  type: MessageType;
  sender_id: string;
  recipient_id: string;
  timestamp: string;
  correlation_id?: string;  // For request-response pairing
}

/**
 * Message Types
 */
export enum MessageType {
  // Task Management
  TASK_CREATED = 'task_created',
  TASK_ASSIGNED = 'task_assigned',
  TASK_ACCEPTED = 'task_accepted',
  TASK_UPDATED = 'task_updated',
  TASK_COMPLETED = 'task_completed',
  TASK_BLOCKED = 'task_blocked',
  
  // Delegation
  DELEGATE_REQUEST = 'delegate_request',
  DELEGATE_ACCEPTED = 'delegate_accepted',
  DELEGATE_REJECTED = 'delegate_rejected',
  
  // Review
  CODE_SUBMITTED = 'code_submitted',
  CODE_REVIEWED = 'code_reviewed',
  REVIEW_FEEDBACK = 'review_feedback',
  
  // Reporting
  PROGRESS_REPORT = 'progress_report',
  DEPARTMENT_REPORT = 'department_report',
  EXECUTIVE_REPORT = 'executive_report',
  
  // System
  HEARTBEAT = 'heartbeat',
  AGENT_REGISTERED = 'agent_registered',
  AGENT_STATUS_CHANGED = 'agent_status_changed',
  ERROR = 'error',
}

/**
 * Task Assignment Message
 */
export interface TaskAssignedMessage extends BaseMessage {
  type: MessageType.TASK_ASSIGNED;
  task_id: string;
  task_details: {
    title: string;
    description: string;
    priority: string;
    deadline?: string;
  };
  instructions?: string;
}

/**
 * Task Update Message
 */
export interface TaskUpdatedMessage extends BaseMessage {
  type: MessageType.TASK_UPDATED;
  task_id: string;
  update_type: 'progress' | 'status' | 'blocker' | 'completion';
  data: {
    progress_percentage?: number;
    status?: string;
    message?: string;
    blockers?: string[];
  };
}

/**
 * Code Submitted Message
 */
export interface CodeSubmittedMessage extends BaseMessage {
  type: MessageType.CODE_SUBMITTED;
  task_id: string;
  files: string[];
  summary: string;
  testing_status: string;
}

/**
 * Code Reviewed Message
 */
export interface CodeReviewedMessage extends BaseMessage {
  type: MessageType.CODE_REVIEWED;
  task_id: string;
  reviewer_id: string;
  decision: 'approved' | 'changes_requested' | 'rejected';
  findings: {
    severity: string;
    file_path: string;
    message: string;
  }[];
  feedback: string;
}
```

### 4.2 Communication Patterns

```typescript
// protocol/patterns.ts

/**
 * Request-Response Pattern
 */
export interface RequestResponsePattern {
  // 1. Send request with unique correlation_id
  request: {
    id: string;
    correlation_id: string;
    sender_id: string;
    recipient_id: string;
    payload: any;
  };
  
  // 2. Receive response with same correlation_id
  response: {
    id: string;
    correlation_id: string;  // Matches request
    sender_id: string;
    recipient_id: string;
    success: boolean;
    data?: any;
    error?: string;
  };
}

/**
 * Publish-Subscribe Pattern (for broadcasts)
 */
export interface PubSubPattern {
  // Topics for different communication channels
  topics: {
    'organization.all': 'Broadcast to all agents';
    'organization.cto': 'Messages for CTO';
    'department.{dept}.all': 'All agents in department';
    'department.{dept}.managers': 'Managers in department';
    'project.{id}.all': 'All agents on project';
    'task.{id}.all': 'All agents assigned to task';
  };
}

/**
 * Priority Queue Pattern
 */
export interface PriorityQueuePattern {
  // Message priorities
  priorities: {
    0: 'CRITICAL - System failures, blockers';
    1: 'HIGH - Urgent tasks, escalations';
    2: 'NORMAL - Regular task updates';
    3: 'LOW - Reports, non-urgent info';
  };
}
```

---

## 5. Resource Definitions

### 5.1 Resource Types

```typescript
// resources/resource-definitions.ts

/**
 * Resource Access Levels
 */
export enum ResourceAccessLevel {
  READ = 'read',
  WRITE = 'write',
  ADMIN = 'admin',
}

/**
 * Resource Definition
 */
export interface Resource {
  uri: string;
  name: string;
  description: string;
  mimeType: string;
  access_level: ResourceAccessLevel;
  allowed_roles: string[];
}

/**
 * Code Repository Resource
 */
export const CODE_REPOSITORY_RESOURCE: Resource = {
  uri: 'repo://{project_id}/{branch}',
  name: 'Code Repository',
  description: 'Access to project code repository',
  mimeType: 'application/git',
  access_level: ResourceAccessLevel.WRITE,
  allowed_roles: [
    'cto',
    'frontend_head', 'backend_head', 'devops_head', 'qa_head',
    'frontend_worker', 'backend_worker', 'devops_worker', 'qa_worker'
  ]
};

/**
 * Task Board Resource
 */
export const TASK_BOARD_RESOURCE: Resource = {
  uri: 'tasks://{project_id}/board',
  name: 'Task Board',
  description: 'Project task board with all tasks and status',
  mimeType: 'application/json',
  access_level: ResourceAccessLevel.READ,
  allowed_roles: [
    'cto',
    'frontend_head', 'backend_head', 'devops_head', 'qa_head',
    'frontend_worker', 'backend_worker', 'devops_worker', 'qa_worker'
  ]
};

/**
 * Agent Registry Resource
 */
export const AGENT_REGISTRY_RESOURCE: Resource = {
  uri: 'agents://registry',
  name: 'Agent Registry',
  description: 'Registry of all agents in the organization',
  mimeType: 'application/json',
  access_level: ResourceAccessLevel.READ,
  allowed_roles: ['cto', 'frontend_head', 'backend_head', 'devops_head', 'qa_head']
};

/**
 * Documentation Resource
 */
export const DOCUMENTATION_RESOURCE: Resource = {
  uri: 'docs://{project_id}/{path}',
  name: 'Project Documentation',
  description: 'Project documentation and specifications',
  mimeType: 'text/markdown',
  access_level: ResourceAccessLevel.WRITE,
  allowed_roles: [
    'cto',
    'frontend_head', 'backend_head', 'devops_head', 'qa_head',
    'frontend_worker', 'backend_worker', 'devops_worker', 'qa_worker'
  ]
};

/**
 * Reports Resource
 */
export const REPORTS_RESOURCE: Resource = {
  uri: 'reports://{type}/{id}',
  name: 'Reports Storage',
  description: 'Storage for all reports (progress, code review, etc.)',
  mimeType: 'application/json',
  access_level: ResourceAccessLevel.READ,
  allowed_roles: [
    'cto',
    'frontend_head', 'backend_head', 'devops_head', 'qa_head'
  ]
};

/**
 * System Logs Resource
 */
export const SYSTEM_LOGS_RESOURCE: Resource = {
  uri: 'logs://system/{date}',
  name: 'System Logs',
  description: 'System-wide logs and events',
  mimeType: 'text/plain',
  access_level: ResourceAccessLevel.READ,
  allowed_roles: ['cto', 'devops_head', 'devops_worker']
};
```

### 5.2 Resource Access Matrix

| Resource | CTO | Dept Head | Worker |
|----------|-----|-----------|--------|
| Code Repository (all projects) | R/W | R/W (dept only) | R/W (assigned) |
| Task Board | R/W | R/W (dept only) | R (assigned) |
| Agent Registry | R/W | R (dept only) | - |
| Documentation | R/W | R/W | R/W (assigned) |
| Reports | R/W | R/W (dept only) | R (own only) |
| System Logs | R/W | R (dept only) | - |

---

## 6. Kimi CLI Integration

### 6.1 MCP Server Configuration for Kimi

```json
// kimi-mcp-config.json
{
  "mcpServers": {
    "hierarchical-agents": {
      "command": "node",
      "args": ["/path/to/mcp-hierarchical-agents/dist/server.js"],
      "env": {
        "MCP_PORT": "3000",
        "MCP_LOG_LEVEL": "info",
        "AGENT_ROLE": "${AGENT_ROLE}",
        "AGENT_ID": "${AGENT_ID}",
        "PARENT_AGENT_ID": "${PARENT_AGENT_ID}"
      },
      "disabled": false,
      "autoApprove": []
    }
  }
}
```

### 6.2 Agent Role Environment Setup

```bash
#!/bin/bash
# setup-agent.sh - Setup script for different agent roles

# CTO Agent
export AGENT_ROLE=cto
export AGENT_ID=cto-001
export AGENT_NAME="Chief Technology Officer"
export MCP_PORT=3000

# Frontend Head
export AGENT_ROLE=frontend_head
export AGENT_ID=fe-head-001
export AGENT_NAME="Frontend Department Head"
export PARENT_AGENT_ID=cto-001
export MCP_PORT=3001

# Frontend Worker
export AGENT_ROLE=frontend_worker
export AGENT_ID=fe-worker-001
export AGENT_NAME="Frontend Developer"
export PARENT_AGENT_ID=fe-head-001
export MCP_PORT=3002
```

---

## 7. Implementation Summary

### 7.1 File Structure

```
mcp-hierarchical-agents/
├── src/
│   ├── server.ts                 # Main MCP Server
│   ├── handlers/
│   │   ├── cto-handlers.ts       # CTO tool handlers
│   │   ├── manager-handlers.ts   # Manager tool handlers
│   │   └── worker-handlers.ts    # Worker tool handlers
│   ├── services/
│   │   ├── agent-registry.ts     # Agent management
│   │   ├── task-manager.ts       # Task management
│   │   ├── message-broker.ts     # Communication
│   │   └── state-manager.ts      # State persistence
│   ├── schemas/
│   │   ├── agent-registry.ts     # Agent schemas
│   │   ├── task-structure.ts     # Task schemas
│   │   ├── state-management.ts   # State schemas
│   │   └── reports.ts            # Report schemas
│   ├── tools/
│   │   ├── cto-tools.ts          # CTO tool definitions
│   │   ├── manager-tools.ts      # Manager tool definitions
│   │   └── worker-tools.ts       # Worker tool definitions
│   ├── resources/
│   │   └── resource-definitions.ts
│   └── utils/
│       ├── logger.ts
│       └── validators.ts
├── dist/                         # Compiled output
├── tests/
│   ├── unit/
│   └── integration/
├── package.json
├── tsconfig.json
└── README.md
```

### 7.2 Key Design Principles

1. **Hierarchical Authority**: Clear chain of command from CTO to Workers
2. **Role-Based Access**: Tools and resources restricted by agent role
3. **Async Communication**: Non-blocking message-based communication
4. **State Persistence**: All state stored for recovery and auditing
5. **Scalability**: Easy to add new agents and departments
6. **Observability**: Comprehensive logging and reporting

---

*Document Version: 1.0*
*Last Updated: 2025*
