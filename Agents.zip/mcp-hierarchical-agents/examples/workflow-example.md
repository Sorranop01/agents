# Workflow Example: Building an E-Commerce Platform

ตัวอย่างการทำงานแบบ Hierarchical Agents สำหรับการสร้าง E-Commerce Platform

## สถานการณ์

CTO ต้องการสร้าง E-Commerce Platform ที่มี:
- Frontend: React + TypeScript
- Backend: Node.js + Express
- Database: PostgreSQL
- DevOps: Docker + Kubernetes
- QA: Automated Testing

## Step-by-Step Workflow

### Phase 1: Project Initiation (CTO)

#### 1.1 CTO สร้างโปรเจค

```json
{
  "tool": "create_project",
  "arguments": {
    "name": "E-Commerce Platform v2",
    "description": "Modern e-commerce platform with microservices architecture",
    "departments_involved": ["frontend", "backend", "devops", "qa"],
    "technical_requirements": "React 18, Node.js 20, PostgreSQL 15, Docker, Kubernetes",
    "target_completion": "2025-06-30T00:00:00Z"
  }
}
```

**Response:**
```json
{
  "success": true,
  "project": {
    "id": "proj-ec-001",
    "name": "E-Commerce Platform v2",
    "status": "planning",
    "created_at": "2025-01-15T09:00:00Z"
  }
}
```

#### 1.2 CTO ลงทะเบียน Department Heads

```json
{
  "tool": "register_department_head",
  "arguments": {
    "name": "Alice Frontend",
    "department": "frontend",
    "role": "frontend_head",
    "skills": ["React", "TypeScript", "UI/UX"],
    "specialties": ["Component Design", "State Management"]
  }
}
```

```json
{
  "tool": "register_department_head",
  "arguments": {
    "name": "Bob Backend",
    "department": "backend",
    "role": "backend_head",
    "skills": ["Node.js", "PostgreSQL", "API Design"],
    "specialties": ["Microservices", "Database Optimization"]
  }
}
```

### Phase 2: Task Assignment (CTO → Department Heads)

#### 2.1 CTO มอบหมายงานให้ Frontend Head

```json
{
  "tool": "assign_department_task",
  "arguments": {
    "project_id": "proj-ec-001",
    "department": "frontend",
    "title": "Design and Implement UI Component Library",
    "description": "Create a comprehensive UI component library including: Button, Input, Card, Modal, Table, Form components. Follow design system guidelines.",
    "priority": "high",
    "deadline": "2025-02-15T00:00:00Z"
  }
}
```

#### 2.2 CTO มอบหมายงานให้ Backend Head

```json
{
  "tool": "assign_department_task",
  "arguments": {
    "project_id": "proj-ec-001",
    "department": "backend",
    "title": "Design and Implement Core API Services",
    "description": "Create RESTful APIs for: User Authentication, Product Catalog, Shopping Cart, Order Management, Payment Processing",
    "priority": "high",
    "deadline": "2025-02-28T00:00:00Z"
  }
}
```

### Phase 3: Department Head Setup

#### 3.1 Frontend Head ลงทะเบียน Workers

```json
{
  "tool": "register_worker",
  "arguments": {
    "name": "Charlie Developer",
    "role": "frontend_worker",
    "skills": ["React", "CSS", "HTML"],
    "experience_level": "mid",
    "max_concurrent_tasks": 3
  }
}
```

```json
{
  "tool": "register_worker",
  "arguments": {
    "name": "Diana Designer",
    "role": "frontend_worker",
    "skills": ["Figma", "CSS", "Animation"],
    "experience_level": "senior",
    "max_concurrent_tasks": 2
  }
}
```

### Phase 4: Task Delegation (Department Head → Workers)

#### 4.1 Frontend Head สร้าง Subtasks

```json
{
  "tool": "create_subtask",
  "arguments": {
    "parent_task_id": "task-fe-001",
    "subtasks": [
      {
        "title": "Design Button Component",
        "description": "Create reusable button with variants: primary, secondary, danger, ghost",
        "assigned_to": "fe-worker-charlie",
        "estimated_hours": 8
      },
      {
        "title": "Design Input Component",
        "description": "Create input component with validation states",
        "assigned_to": "fe-worker-charlie",
        "estimated_hours": 12
      },
      {
        "title": "Create Design Tokens",
        "description": "Define color palette, typography, spacing system",
        "assigned_to": "fe-worker-diana",
        "estimated_hours": 16
      }
    ]
  }
}
```

### Phase 5: Worker Execution

#### 5.1 Worker รับงาน

```json
{
  "tool": "accept_task",
  "arguments": {
    "task_id": "task-btn-001",
    "estimated_completion": "2025-01-20T17:00:00Z",
    "initial_plan": "Will implement Button component with 4 variants and comprehensive tests"
  }
}
```

#### 5.2 Worker เขียนโค้ด

```json
{
  "tool": "write_code",
  "arguments": {
    "task_id": "task-btn-001",
    "files": [
      {
        "path": "src/components/Button/Button.tsx",
        "action": "create",
        "content": "import React from 'react';
import './Button.css';

export interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  onClick?: () => void;
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  onClick,
  children,
}) => {
  const className = `btn btn--${variant} btn--${size} ${loading ? 'btn--loading' : ''}`;
  
  return (
    <button
      className={className}
      disabled={disabled || loading}
      onClick={onClick}
    >
      {loading ? <span className="btn__spinner" /> : children}
    </button>
  );
};",
        "language": "typescript"
      },
      {
        "path": "src/components/Button/Button.test.tsx",
        "action": "create",
        "content": "import { render, screen, fireEvent } from '@testing-library/react';
import { Button } from './Button';

describe('Button', () => {
  it('renders with default variant', () => {
    render(<Button>Click me</Button>);
    expect(screen.getByText('Click me')).toBeInTheDocument();
  });

  it('handles click events', () => {
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>Click me</Button>);
    fireEvent.click(screen.getByText('Click me'));
    expect(handleClick).toHaveBeenCalled();
  });

  it('is disabled when loading', () => {
    render(<Button loading>Loading</Button>);
    expect(screen.getByRole('button')).toBeDisabled();
  });
});",
        "language": "typescript"
      }
    ],
    "commit_message": "feat: Add Button component with variants and tests"
  }
}
```

#### 5.3 Worker รันเทสต์

```json
{
  "tool": "run_tests",
  "arguments": {
    "task_id": "task-btn-001",
    "test_type": "unit",
    "files_to_test": ["src/components/Button/Button.test.tsx"]
  }
}
```

**Response:**
```json
{
  "success": true,
  "results": {
    "total_tests": 15,
    "passed": 15,
    "failed": 0,
    "coverage": 92
  }
}
```

#### 5.4 Worker อัปเดตความคืบหน้า

```json
{
  "tool": "update_task_progress",
  "arguments": {
    "task_id": "task-btn-001",
    "progress_percentage": 75,
    "message": "Component implemented, tests passing. Working on documentation."
  }
}
```

#### 5.5 Worker เขียนเอกสาร

```json
{
  "tool": "document_code",
  "arguments": {
    "task_id": "task-btn-001",
    "files": ["src/components/Button/Button.tsx"],
    "documentation_type": "all"
  }
}
```

#### 5.6 Worker ส่งงานเพื่อตรวจสอบ

```json
{
  "tool": "submit_for_review",
  "arguments": {
    "task_id": "task-btn-001",
    "summary": "Implemented Button component with 4 variants (primary, secondary, danger, ghost), 3 sizes, loading state, and comprehensive test coverage (92%)",
    "files_changed": [
      "src/components/Button/Button.tsx",
      "src/components/Button/Button.test.tsx",
      "src/components/Button/Button.css",
      "src/components/Button/index.ts",
      "src/components/Button/README.md"
    ],
    "testing_done": "All 15 unit tests passing. Tested variants, sizes, disabled state, loading state, and click handlers.",
    "notes_for_reviewer": "Please review the CSS approach for variants. Considered using CSS-in-JS but went with CSS modules for better performance."
  }
}
```

### Phase 6: Code Review (Manager)

#### 6.1 Frontend Head ตรวจสอบโค้ด

```json
{
  "tool": "review_worker_code",
  "arguments": {
    "task_id": "task-btn-001",
    "worker_id": "fe-worker-charlie",
    "files": [
      "src/components/Button/Button.tsx",
      "src/components/Button/Button.test.tsx",
      "src/components/Button/Button.css"
    ],
    "review_criteria": ["code_quality", "testing", "documentation"]
  }
}
```

**Response:**
```json
{
  "success": true,
  "review": {
    "id": "review-001",
    "approval_status": "approved",
    "findings": [
      {
        "severity": "info",
        "file_path": "src/components/Button/Button.tsx",
        "message": "Consider adding JSDoc comments for better IDE support",
        "suggestion": "Add @param and @returns documentation"
      }
    ],
    "overall_feedback": "Excellent work! Code is clean, well-tested, and follows our conventions. Minor suggestion to add JSDoc, but not blocking. Approved for merge."
  }
}
```

### Phase 7: Cross-Department Coordination

#### 7.1 CTO ประสานงานระหว่าง Frontend และ Backend

```json
{
  "tool": "coordinate_departments",
  "arguments": {
    "project_id": "proj-ec-001",
    "coordinating_departments": ["frontend", "backend"],
    "coordination_type": "api_contract",
    "requirements": "Define API contracts for: User Authentication, Product Catalog, Shopping Cart. Use OpenAPI 3.0 specification."
  }
}
```

### Phase 8: Reporting

#### 8.1 Frontend Head ส่งรายงานแผนก

```json
{
  "tool": "submit_department_report",
  "arguments": {
    "period_start": "2025-01-01T00:00:00Z",
    "period_end": "2025-01-31T23:59:59Z",
    "summary": "Frontend team completed UI component library foundation. 5 core components implemented with 90%+ test coverage.",
    "accomplishments": [
      "Completed Button component with 4 variants",
      "Completed Input component with validation",
      "Established design tokens system",
      "Achieved 92% average test coverage"
    ],
    "challenges": [
      "CSS module configuration took longer than expected",
      "Needed to align on naming conventions"
    ],
    "issues": [
      "One task blocked waiting for design approval"
    ],
    "recommendations": [
      "Consider adopting Storybook for component documentation",
      "Set up visual regression testing"
    ]
  }
}
```

#### 8.2 CTO สร้างรายงาน Executive

```json
{
  "tool": "generate_executive_report",
  "arguments": {
    "period_start": "2025-01-01T00:00:00Z",
    "period_end": "2025-01-31T23:59:59Z",
    "include_details": true
  }
}
```

**Response:**
```json
{
  "id": "exec-report-001",
  "key_metrics": {
    "total_projects": 1,
    "active_projects": 1,
    "completed_projects": 0,
    "total_agents": 6,
    "active_agents": 4,
    "avg_department_load": 67,
    "code_quality_score": 88,
    "on_time_delivery_rate": 85
  },
  "department_summaries": [
    {
      "department": "frontend",
      "agent_count": 3,
      "total_tasks": 8,
      "completed_tasks": 5
    },
    {
      "department": "backend",
      "agent_count": 2,
      "total_tasks": 6,
      "completed_tasks": 3
    }
  ],
  "strategic_recommendations": [
    "Backend team needs additional resources to meet deadline",
    "Consider hiring dedicated DevOps engineer"
  ]
}
```

### Phase 9: Monitoring and Status

#### 9.1 CTO ดูสถานะองค์กร

```json
{
  "tool": "get_organization_status",
  "arguments": {
    "include_metrics": true,
    "include_active_tasks": true
  }
}
```

#### 9.2 Frontend Head ดูสถานะแผนก

```json
{
  "tool": "get_department_status",
  "arguments": {
    "include_worker_details": true,
    "include_task_details": true
  }
}
```

#### 9.3 Frontend Head ดูภาระงาน Workers

```json
{
  "tool": "get_worker_workload",
  "arguments": {}
}
```

### Phase 10: Issue Escalation

#### 10.1 Frontend Head ยกระดับปัญหา

```json
{
  "tool": "escalate_issue",
  "arguments": {
    "issue_type": "resource",
    "description": "Frontend team is understaffed for the current workload. Need 2 more developers to meet the Q2 deadline.",
    "impact": "Project deadline at risk. Current velocity suggests 3-week delay.",
    "suggested_resolution": "Hire 2 mid-level React developers or extend deadline by 3 weeks.",
    "task_id": "task-fe-001"
  }
}
```

## Summary

Workflow นี้แสดงให้เห็นถึง:

1. **Hierarchical Communication**: CTO → Manager → Worker
2. **Task Delegation**: การมอบหมายงานที่ชัดเจน
3. **Code Review Process**: การตรวจสอบโค้ดก่อน merge
4. **Progress Tracking**: การติดตามความคืบหน้า
5. **Reporting**: รายงานระดับต่างๆ
6. **Issue Escalation**: การยกระดับปัญหาเมื่อจำเป็น

## Communication Patterns

```
┌─────────────────────────────────────────────────────────────┐
│                    Communication Flow                        │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  TOP-DOWN (Assignment):                                      │
│  CTO ──assign──► Dept Head ──delegate──► Worker              │
│                                                              │
│  BOTTOM-UP (Reporting):                                      │
│  Worker ──submit──► Dept Head ──report──► CTO                │
│                                                              │
│  HORIZONTAL (Collaboration):                                 │
│  Worker A ◄──code review──► Worker B                         │
│                                                              │
│  CROSS-DEPARTMENT:                                           │
│  Frontend Head ◄──coordinate──► Backend Head                 │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```
