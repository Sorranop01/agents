/**
 * Client Usage Examples
 * ตัวอย่างการใช้งาน MCP Hierarchical Agents จากฝั่ง Client
 */

import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

// ============================================
// CTO Client Example
// ============================================

export class CTOClient {
  private client: Client;

  constructor() {
    this.client = new Client(
      { name: 'cto-client', version: '1.0.0' },
      { capabilities: { tools: {}, resources: {} } }
    );
  }

  async connect() {
    const transport = new StdioClientTransport({
      command: 'node',
      args: ['../dist/server.js'],
      env: {
        AGENT_ROLE: 'cto',
        AGENT_ID: 'cto-001',
        AGENT_NAME: 'Chief Technology Officer',
      },
    });
    await this.client.connect(transport);
  }

  /**
   * Create a new project
   */
  async createProject(
    name: string,
    description: string,
    departments: string[],
    targetCompletion?: string
  ) {
    return this.client.callTool({
      name: 'create_project',
      arguments: {
        name,
        description,
        departments_involved: departments,
        target_completion: targetCompletion,
      },
    });
  }

  /**
   * Assign task to department head
   */
  async assignDepartmentTask(
    projectId: string,
    department: string,
    title: string,
    description: string,
    priority: string = 'medium',
    deadline?: string
  ) {
    return this.client.callTool({
      name: 'assign_department_task',
      arguments: {
        project_id: projectId,
        department,
        title,
        description,
        priority,
        deadline,
      },
    });
  }

  /**
   * Get organization status
   */
  async getOrganizationStatus() {
    return this.client.callTool({
      name: 'get_organization_status',
      arguments: {
        include_metrics: true,
        include_active_tasks: true,
      },
    });
  }

  /**
   * Generate executive report
   */
  async generateExecutiveReport(periodStart: string, periodEnd: string) {
    return this.client.callTool({
      name: 'generate_executive_report',
      arguments: {
        period_start: periodStart,
        period_end: periodEnd,
        include_details: true,
      },
    });
  }

  /**
   * Register department head
   */
  async registerDepartmentHead(
    name: string,
    department: string,
    role: string,
    skills: string[] = [],
    specialties: string[] = []
  ) {
    return this.client.callTool({
      name: 'register_department_head',
      arguments: {
        name,
        department,
        role,
        skills,
        specialties,
      },
    });
  }

  /**
   * Get agent hierarchy
   */
  async getAgentHierarchy() {
    return this.client.callTool({
      name: 'get_agent_hierarchy',
      arguments: {
        include_inactive: false,
      },
    });
  }

  async disconnect() {
    await this.client.close();
  }
}

// ============================================
// Manager Client Example
// ============================================

export class ManagerClient {
  private client: Client;
  private department: string;

  constructor(department: string, agentId: string, agentName: string) {
    this.department = department;
    this.client = new Client(
      { name: `${department}-manager-client`, version: '1.0.0' },
      { capabilities: { tools: {}, resources: {} } }
    );
    this.agentId = agentId;
    this.agentName = agentName;
  }

  private agentId: string;
  private agentName: string;

  async connect() {
    const transport = new StdioClientTransport({
      command: 'node',
      args: ['../dist/server.js'],
      env: {
        AGENT_ROLE: `${this.department}_head`,
        AGENT_ID: this.agentId,
        AGENT_NAME: this.agentName,
        PARENT_AGENT_ID: 'cto-001',
      },
    });
    await this.client.connect(transport);
  }

  /**
   * Delegate task to worker
   */
  async delegateTask(
    parentTaskId: string,
    workerId: string,
    title: string,
    description: string,
    taskType: string = 'feature',
    priority: string = 'medium',
    estimatedHours?: number
  ) {
    return this.client.callTool({
      name: 'delegate_task',
      arguments: {
        parent_task_id: parentTaskId,
        worker_id: workerId,
        title,
        description,
        task_type: taskType,
        priority,
        estimated_hours: estimatedHours,
      },
    });
  }

  /**
   * Create subtasks
   */
  async createSubtasks(
    parentTaskId: string,
    subtasks: Array<{
      title: string;
      description: string;
      assigned_to?: string;
      estimated_hours?: number;
    }>
  ) {
    return this.client.callTool({
      name: 'create_subtask',
      arguments: {
        parent_task_id: parentTaskId,
        subtasks,
      },
    });
  }

  /**
   * Review worker code
   */
  async reviewWorkerCode(
    taskId: string,
    workerId: string,
    files: string[],
    reviewCriteria: string[] = ['code_quality', 'testing']
  ) {
    return this.client.callTool({
      name: 'review_worker_code',
      arguments: {
        task_id: taskId,
        worker_id: workerId,
        files,
        review_criteria: reviewCriteria,
      },
    });
  }

  /**
   * Get department status
   */
  async getDepartmentStatus() {
    return this.client.callTool({
      name: 'get_department_status',
      arguments: {
        include_worker_details: true,
        include_task_details: true,
      },
    });
  }

  /**
   * Register worker
   */
  async registerWorker(
    name: string,
    role: string,
    skills: string[] = [],
    experienceLevel: string = 'mid'
  ) {
    return this.client.callTool({
      name: 'register_worker',
      arguments: {
        name,
        role,
        skills,
        experience_level: experienceLevel,
      },
    });
  }

  /**
   * Submit department report
   */
  async submitDepartmentReport(
    periodStart: string,
    periodEnd: string,
    summary: string,
    accomplishments: string[] = [],
    challenges: string[] = [],
    issues: string[] = [],
    recommendations: string[] = []
  ) {
    return this.client.callTool({
      name: 'submit_department_report',
      arguments: {
        period_start: periodStart,
        period_end: periodEnd,
        summary,
        accomplishments,
        challenges,
        issues,
        recommendations,
      },
    });
  }

  /**
   * Escalate issue
   */
  async escalateIssue(
    issueType: string,
    description: string,
    impact: string,
    suggestedResolution?: string,
    taskId?: string
  ) {
    return this.client.callTool({
      name: 'escalate_issue',
      arguments: {
        issue_type: issueType,
        description,
        impact,
        suggested_resolution: suggestedResolution,
        task_id: taskId,
      },
    });
  }

  async disconnect() {
    await this.client.close();
  }
}

// ============================================
// Worker Client Example
// ============================================

export class WorkerClient {
  private client: Client;
  private department: string;

  constructor(department: string, agentId: string, agentName: string) {
    this.department = department;
    this.client = new Client(
      { name: `${department}-worker-client`, version: '1.0.0' },
      { capabilities: { tools: {}, resources: {} } }
    );
    this.agentId = agentId;
    this.agentName = agentName;
  }

  private agentId: string;
  private agentName: string;

  async connect() {
    const transport = new StdioClientTransport({
      command: 'node',
      args: ['../dist/server.js'],
      env: {
        AGENT_ROLE: `${this.department}_worker`,
        AGENT_ID: this.agentId,
        AGENT_NAME: this.agentName,
        PARENT_AGENT_ID: `${this.department}_head-001`,
      },
    });
    await this.client.connect(transport);
  }

  /**
   * Accept task
   */
  async acceptTask(taskId: string, estimatedCompletion?: string, initialPlan?: string) {
    return this.client.callTool({
      name: 'accept_task',
      arguments: {
        task_id: taskId,
        estimated_completion: estimatedCompletion,
        initial_plan: initialPlan,
      },
    });
  }

  /**
   * Write code
   */
  async writeCode(
    taskId: string,
    files: Array<{
      path: string;
      content?: string;
      action: 'create' | 'modify' | 'delete';
      language?: string;
    }>,
    commitMessage?: string
  ) {
    return this.client.callTool({
      name: 'write_code',
      arguments: {
        task_id: taskId,
        files,
        commit_message: commitMessage,
      },
    });
  }

  /**
   * Run tests
   */
  async runTests(taskId: string, testType: string = 'all', filesToTest?: string[]) {
    return this.client.callTool({
      name: 'run_tests',
      arguments: {
        task_id: taskId,
        test_type: testType,
        files_to_test: filesToTest,
      },
    });
  }

  /**
   * Update task progress
   */
  async updateTaskProgress(
    taskId: string,
    progressPercentage: number,
    status?: string,
    message?: string,
    blockers?: string[]
  ) {
    return this.client.callTool({
      name: 'update_task_progress',
      arguments: {
        task_id: taskId,
        progress_percentage: progressPercentage,
        status,
        message,
        blockers,
      },
    });
  }

  /**
   * Submit for review
   */
  async submitForReview(
    taskId: string,
    summary: string,
    filesChanged: string[],
    testingDone?: string,
    notesForReviewer?: string
  ) {
    return this.client.callTool({
      name: 'submit_for_review',
      arguments: {
        task_id: taskId,
        summary,
        files_changed: filesChanged,
        testing_done: testingDone,
        notes_for_reviewer: notesForReviewer,
      },
    });
  }

  /**
   * Request help
   */
  async requestHelp(
    taskId: string,
    helpType: string,
    description: string,
    urgency: string = 'medium'
  ) {
    return this.client.callTool({
      name: 'request_help',
      arguments: {
        task_id: taskId,
        help_type: helpType,
        description,
        urgency,
      },
    });
  }

  /**
   * Research solution
   */
  async researchSolution(topic: string, context?: string, constraints?: string[]) {
    return this.client.callTool({
      name: 'research_solution',
      arguments: {
        topic,
        context,
        constraints,
      },
    });
  }

  /**
   * Get task details
   */
  async getTaskDetails(taskId: string, includeHistory: boolean = true) {
    return this.client.callTool({
      name: 'get_task_details',
      arguments: {
        task_id: taskId,
        include_history: includeHistory,
      },
    });
  }

  /**
   * List available tasks
   */
  async listAvailableTasks(priorityFilter?: string[], taskTypeFilter?: string[]) {
    return this.client.callTool({
      name: 'list_available_tasks',
      arguments: {
        priority_filter: priorityFilter,
        task_type_filter: taskTypeFilter,
      },
    });
  }

  async disconnect() {
    await this.client.close();
  }
}

// ============================================
// Usage Example
// ============================================

async function main() {
  // CTO creates project
  const cto = new CTOClient();
  await cto.connect();

  console.log('CTO: Creating project...');
  const projectResult = await cto.createProject(
    'E-Commerce Platform',
    'Full-stack e-commerce platform',
    ['frontend', 'backend', 'devops', 'qa'],
    '2025-06-30T00:00:00Z'
  );
  console.log('Project created:', projectResult);

  // Register department heads
  console.log('CTO: Registering department heads...');
  await cto.registerDepartmentHead(
    'Alice Frontend',
    'frontend',
    'frontend_head',
    ['React', 'TypeScript'],
    ['UI Design']
  );

  // Get organization status
  console.log('CTO: Getting organization status...');
  const status = await cto.getOrganizationStatus();
  console.log('Organization status:', status);

  await cto.disconnect();

  // Frontend Manager delegates task
  const frontendManager = new ManagerClient('frontend', 'fe-head-001', 'Alice Frontend');
  await frontendManager.connect();

  console.log('Manager: Registering workers...');
  await frontendManager.registerWorker(
    'Charlie Developer',
    'frontend_worker',
    ['React', 'CSS'],
    'mid'
  );

  console.log('Manager: Getting department status...');
  const deptStatus = await frontendManager.getDepartmentStatus();
  console.log('Department status:', deptStatus);

  await frontendManager.disconnect();

  // Worker accepts and completes task
  const worker = new WorkerClient('frontend', 'fe-worker-001', 'Charlie Developer');
  await worker.connect();

  console.log('Worker: Listing available tasks...');
  const availableTasks = await worker.listAvailableTasks();
  console.log('Available tasks:', availableTasks);

  // If there are tasks, accept one
  // await worker.acceptTask('task-001', '2025-02-01T17:00:00Z', 'Will implement Button component');

  await worker.disconnect();
}

// Run if executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}
