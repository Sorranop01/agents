# MCP Hierarchical Agents Server

MCP Server สำหรับระบบ Hierarchical Agents ที่มีโครงสร้างเป็นลำดับชั้นเหมือนบริษัทเทคโนโลยี รองรับ CTO, Department Heads และ Workers

## โครงสร้างระบบ

```
┌─────────────────────────────────────────────────────────────────┐
│                         CTO Agent                                │
│                    (Strategic Planning)                          │
└───────────────────────────┬─────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│ Frontend Head│   │ Backend Head │   │  DevOps Head │
│  (Manager)   │   │  (Manager)   │   │  (Manager)   │
└──────┬───────┘   └──────┬───────┘   └──────┬───────┘
       │                  │                  │
   ┌───┴───┐          ┌───┴───┐          ┌───┴───┐
   ▼       ▼          ▼       ▼          ▼       ▼
┌────┐  ┌────┐    ┌────┐  ┌────┐    ┌────┐  ┌────┐
│ W1 │  │ W2 │    │ W3 │  │ W4 │    │ W5 │  │ W6 │
└────┘  └────┘    └────┘  └────┘    └────┘  └────┘
(Workers)
```

## การติดตั้ง

```bash
# Clone repository
cd mcp-hierarchical-agents

# Install dependencies
npm install

# Build
npm run build
```

## การใช้งานกับ Kimi CLI

### 1. ตั้งค่า MCP Server ใน Kimi

เพิ่มการตั้งค่าต่อไปนี้ในไฟล์ `~/.kimi/mcp-config.json`:

```json
{
  "mcpServers": {
    "hierarchical-agents-cto": {
      "command": "node",
      "args": ["/path/to/mcp-hierarchical-agents/dist/server.js"],
      "env": {
        "AGENT_ROLE": "cto",
        "AGENT_ID": "cto-001",
        "AGENT_NAME": "Chief Technology Officer"
      }
    },
    "hierarchical-agents-frontend": {
      "command": "node",
      "args": ["/path/to/mcp-hierarchical-agents/dist/server.js"],
      "env": {
        "AGENT_ROLE": "frontend_head",
        "AGENT_ID": "fe-head-001",
        "AGENT_NAME": "Frontend Department Head",
        "PARENT_AGENT_ID": "cto-001"
      }
    },
    "hierarchical-agents-frontend-worker": {
      "command": "node",
      "args": ["/path/to/mcp-hierarchical-agents/dist/server.js"],
      "env": {
        "AGENT_ROLE": "frontend_worker",
        "AGENT_ID": "fe-worker-001",
        "AGENT_NAME": "Frontend Developer",
        "PARENT_AGENT_ID": "fe-head-001"
      }
    }
  }
}
```

### 2. เริ่มต้นใช้งาน

```bash
# Run in development mode
npm run dev

# Or run the built version
npm start
```

## Tools ที่มีให้ใช้งาน

### CTO Tools

| Tool | Description |
|------|-------------|
| `create_project` | สร้างโปรเจคใหม่ |
| `assign_department_task` | มอบหมายงานให้ Department Head |
| `review_architecture` | ตรวจสอบและอนุมัติ Architecture |
| `get_organization_status` | ดูสถานะองค์กรทั้งหมด |
| `generate_executive_report` | สร้างรายงาน Executive |
| `coordinate_departments` | ประสานงานระหว่างแผนก |
| `register_department_head` | ลงทะเบียน Department Head |
| `get_agent_hierarchy` | ดูโครงสร้างลำดับชั้น |
| `broadcast_message` | ส่งข้อความ broadcast |

### Manager Tools

| Tool | Description |
|------|-------------|
| `delegate_task` | มอบหมายงานให้ Worker |
| `create_subtask` | สร้าง Subtask |
| `review_worker_code` | ตรวจสอบโค้ด Worker |
| `get_department_status` | ดูสถานะแผนก |
| `register_worker` | ลงทะเบียน Worker |
| `submit_department_report` | ส่งรายงานแผนก |
| `request_architecture_review` | ขอตรวจสอบ Architecture |
| `escalate_issue` | ยกระดับปัญหา |
| `reassign_task` | มอบหมายงานใหม่ |
| `get_worker_workload` | ดูภาระงาน Worker |

### Worker Tools

| Tool | Description |
|------|-------------|
| `accept_task` | รับงาน |
| `write_code` | เขียนโค้ด |
| `run_tests` | รันเทสต์ |
| `update_task_progress` | อัปเดตความคืบหน้า |
| `submit_for_review` | ส่งงานเพื่อตรวจสอบ |
| `request_help` | ขอความช่วยเหลือ |
| `research_solution` | ค้นคว้าวิธีแก้ปัญหา |
| `document_code` | เขียนเอกสารโค้ด |
| `get_task_details` | ดูรายละเอียดงาน |
| `list_available_tasks` | ดูงานที่พร้อมรับ |

## ตัวอย่างการใช้งาน

### CTO สร้างโปรเจค

```json
{
  "name": "create_project",
  "arguments": {
    "name": "E-Commerce Platform",
    "description": "Full-stack e-commerce platform with React and Node.js",
    "departments_involved": ["frontend", "backend", "devops", "qa"],
    "target_completion": "2025-06-30T00:00:00Z"
  }
}
```

### CTO มอบหมายงานให้ Department Head

```json
{
  "name": "assign_department_task",
  "arguments": {
    "project_id": "proj-123",
    "department": "frontend",
    "title": "Design UI Component Library",
    "description": "Create reusable UI components for the e-commerce platform",
    "priority": "high",
    "deadline": "2025-03-15T00:00:00Z"
  }
}
```

### Manager มอบหมายงานให้ Worker

```json
{
  "name": "delegate_task",
  "arguments": {
    "parent_task_id": "task-456",
    "worker_id": "fe-worker-001",
    "title": "Implement Button Component",
    "description": "Create reusable button component with variants",
    "task_type": "feature",
    "priority": "medium",
    "estimated_hours": 8
  }
}
```

### Worker รับงาน

```json
{
  "name": "accept_task",
  "arguments": {
    "task_id": "task-789",
    "estimated_completion": "2025-03-10T17:00:00Z",
    "initial_plan": "Will start with basic button, then add variants"
  }
}
```

### Worker เขียนโค้ด

```json
{
  "name": "write_code",
  "arguments": {
    "task_id": "task-789",
    "files": [
      {
        "path": "src/components/Button.tsx",
        "action": "create",
        "content": "import React from 'react';\n\ninterface ButtonProps {\n  variant?: 'primary' | 'secondary';\n  children: React.ReactNode;\n}\n\nexport const Button: React.FC<ButtonProps> = ({ variant = 'primary', children }) => {\n  return <button className={`btn btn-${variant}`}>{children}</button>;\n};",
        "language": "typescript"
      }
    ],
    "commit_message": "Add Button component with variants"
  }
}
```

### Worker ส่งงานเพื่อตรวจสอบ

```json
{
  "name": "submit_for_review",
  "arguments": {
    "task_id": "task-789",
    "summary": "Implemented Button component with primary and secondary variants",
    "files_changed": ["src/components/Button.tsx", "src/components/Button.test.tsx"],
    "testing_done": "All unit tests passing (15/15)",
    "notes_for_reviewer": "Please check the variant styling approach"
  }
}
```

## Data Models

### Agent

```typescript
interface Agent {
  id: string;
  name: string;
  role: 'cto' | 'frontend_head' | 'backend_head' | 'devops_head' | 'qa_head' | 
         'frontend_worker' | 'backend_worker' | 'devops_worker' | 'qa_worker';
  level: 0 | 1 | 2;  // 0=CTO, 1=Manager, 2=Worker
  department: string;
  parent_id: string | null;
  child_ids: string[];
  status: 'idle' | 'busy' | 'offline' | 'error';
  metadata: {
    skills: string[];
    specialties: string[];
    experience_level: 'junior' | 'mid' | 'senior';
    max_concurrent_tasks: number;
  };
}
```

### Task

```typescript
interface Task {
  id: string;
  project_id: string;
  parent_task_id?: string;
  title: string;
  type: 'feature' | 'bugfix' | 'refactor' | 'documentation' | 'testing';
  priority: 'critical' | 'high' | 'medium' | 'low';
  status: 'pending' | 'assigned' | 'in_progress' | 'in_review' | 'completed' | 'blocked';
  assigned_to?: string;
  progress_percentage: number;
  code_changes: CodeChange[];
  deadline?: string;
}
```

### Project

```typescript
interface Project {
  id: string;
  name: string;
  description: string;
  departments_involved: string[];
  status: 'planning' | 'active' | 'completed' | 'archived';
  root_task_ids: string[];
}
```

## Communication Flow

```
1. CTO creates project
   └── CTO assigns task to Department Head
       └── Department Head delegates to Worker
           └── Worker accepts and starts work
               └── Worker submits for review
                   └── Department Head reviews
                       └── Approved → Task completed
                       └── Changes requested → Worker fixes
```

## License

MIT
