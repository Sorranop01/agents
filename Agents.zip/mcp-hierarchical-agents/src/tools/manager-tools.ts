/**
 * Manager Tools Definition
 * Department management and task delegation tools
 */

import { Tool } from '@modelcontextprotocol/sdk/types.js';

export const MANAGER_TOOLS: Tool[] = [
  {
    name: 'delegate_task',
    description: 'Delegate a task to a worker agent',
    inputSchema: {
      type: 'object',
      properties: {
        parent_task_id: { type: 'string' },
        worker_id: { type: 'string' },
        title: { type: 'string' },
        description: { type: 'string' },
        task_type: { 
          type: 'string',
          enum: ['feature', 'bugfix', 'refactor', 'documentation', 'testing']
        },
        priority: { 
          type: 'string',
          enum: ['critical', 'high', 'medium', 'low']
        },
        estimated_hours: { type: 'number' },
        technical_specs: { type: 'string' },
      },
      required: ['parent_task_id', 'worker_id', 'title', 'description']
    }
  },
  {
    name: 'create_subtask',
    description: 'Break down a task into subtasks',
    inputSchema: {
      type: 'object',
      properties: {
        parent_task_id: { type: 'string' },
        subtasks: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              title: { type: 'string' },
              description: { type: 'string' },
              assigned_to: { type: 'string' },
              estimated_hours: { type: 'number' },
            },
            required: ['title', 'description']
          }
        }
      },
      required: ['parent_task_id', 'subtasks']
    }
  },
  {
    name: 'review_worker_code',
    description: 'Review code submitted by a worker',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        worker_id: { type: 'string' },
        files: { 
          type: 'array', 
          items: { type: 'string' } 
        },
        review_criteria: {
          type: 'array',
          items: { 
            type: 'string',
            enum: ['code_quality', 'performance', 'security', 'testing', 'documentation']
          }
        }
      },
      required: ['task_id', 'worker_id', 'files']
    }
  },
  {
    name: 'get_department_status',
    description: 'Get status of all workers and tasks in the department',
    inputSchema: {
      type: 'object',
      properties: {
        include_worker_details: { type: 'boolean', default: true },
        include_task_details: { type: 'boolean', default: true },
        status_filter: {
          type: 'array',
          items: { 
            type: 'string',
            enum: ['pending', 'assigned', 'in_progress', 'in_review', 'completed', 'blocked']
          }
        }
      }
    }
  },
  {
    name: 'register_worker',
    description: 'Register a new worker agent in the department',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string' },
        role: { 
          type: 'string',
          enum: ['frontend_worker', 'backend_worker', 'devops_worker', 'qa_worker']
        },
        skills: { type: 'array', items: { type: 'string' } },
        specialties: { type: 'array', items: { type: 'string' } },
        experience_level: { 
          type: 'string',
          enum: ['junior', 'mid', 'senior'],
          default: 'mid'
        },
        max_concurrent_tasks: { type: 'number', default: 3 },
      },
      required: ['name', 'role']
    }
  },
  {
    name: 'submit_department_report',
    description: 'Submit progress report to CTO',
    inputSchema: {
      type: 'object',
      properties: {
        period_start: { type: 'string', format: 'date-time' },
        period_end: { type: 'string', format: 'date-time' },
        summary: { type: 'string' },
        accomplishments: { type: 'array', items: { type: 'string' } },
        challenges: { type: 'array', items: { type: 'string' } },
        issues: { type: 'array', items: { type: 'string' } },
        recommendations: { type: 'array', items: { type: 'string' } },
      },
      required: ['period_start', 'period_end', 'summary']
    }
  },
  {
    name: 'request_architecture_review',
    description: 'Request CTO review for architecture decisions',
    inputSchema: {
      type: 'object',
      properties: {
        project_id: { type: 'string' },
        proposal_title: { type: 'string' },
        proposal_description: { type: 'string' },
        technical_details: { type: 'string' },
        alternatives_considered: { type: 'array', items: { type: 'string' } },
        recommendation: { type: 'string' },
      },
      required: ['project_id', 'proposal_title', 'proposal_description']
    }
  },
  {
    name: 'escalate_issue',
    description: 'Escalate an issue to CTO',
    inputSchema: {
      type: 'object',
      properties: {
        issue_type: { 
          type: 'string',
          enum: ['resource', 'technical', 'conflict', 'deadline', 'other']
        },
        description: { type: 'string' },
        impact: { type: 'string' },
        suggested_resolution: { type: 'string' },
        task_id: { type: 'string' },
      },
      required: ['issue_type', 'description', 'impact']
    }
  },
  {
    name: 'reassign_task',
    description: 'Reassign a task to a different worker',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        new_worker_id: { type: 'string' },
        reason: { type: 'string' },
      },
      required: ['task_id', 'new_worker_id']
    }
  },
  {
    name: 'get_worker_workload',
    description: 'Get current workload of all workers in department',
    inputSchema: {
      type: 'object',
      properties: {
        worker_id: { type: 'string' },
      }
    }
  }
];
