/**
 * Worker Tools Definition
 * Task execution and code development tools
 */

import { Tool } from '@modelcontextprotocol/sdk/types.js';

export const WORKER_TOOLS: Tool[] = [
  {
    name: 'accept_task',
    description: 'Accept an assigned task and begin work',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        estimated_completion: { type: 'string', format: 'date-time' },
        initial_plan: { type: 'string' },
      },
      required: ['task_id']
    }
  },
  {
    name: 'write_code',
    description: 'Write or modify code files',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        files: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              path: { type: 'string' },
              content: { type: 'string' },
              action: { 
                type: 'string',
                enum: ['create', 'modify', 'delete']
              },
              language: { type: 'string' },
            },
            required: ['path', 'action']
          }
        },
        commit_message: { type: 'string' },
      },
      required: ['task_id', 'files']
    }
  },
  {
    name: 'run_tests',
    description: 'Run tests for the current task',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        test_type: { 
          type: 'string',
          enum: ['unit', 'integration', 'e2e', 'all'],
          default: 'all'
        },
        files_to_test: { type: 'array', items: { type: 'string' } },
      },
      required: ['task_id']
    }
  },
  {
    name: 'update_task_progress',
    description: 'Update progress on the current task',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        progress_percentage: { 
          type: 'number', 
          minimum: 0, 
          maximum: 100 
        },
        status: { 
          type: 'string',
          enum: ['in_progress', 'in_review', 'blocked']
        },
        message: { type: 'string' },
        blockers: { type: 'array', items: { type: 'string' } },
      },
      required: ['task_id', 'progress_percentage']
    }
  },
  {
    name: 'submit_for_review',
    description: 'Submit completed work for manager review',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        summary: { type: 'string' },
        files_changed: { type: 'array', items: { type: 'string' } },
        testing_done: { type: 'string' },
        notes_for_reviewer: { type: 'string' },
      },
      required: ['task_id', 'summary', 'files_changed']
    }
  },
  {
    name: 'request_help',
    description: 'Request help from manager or other workers',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        help_type: { 
          type: 'string',
          enum: ['technical', 'clarification', 'review', 'resource']
        },
        description: { type: 'string' },
        urgency: { 
          type: 'string',
          enum: ['low', 'medium', 'high', 'critical'],
          default: 'medium'
        },
      },
      required: ['task_id', 'help_type', 'description']
    }
  },
  {
    name: 'research_solution',
    description: 'Research solutions or best practices',
    inputSchema: {
      type: 'object',
      properties: {
        topic: { type: 'string' },
        context: { type: 'string' },
        constraints: { type: 'array', items: { type: 'string' } },
      },
      required: ['topic']
    }
  },
  {
    name: 'document_code',
    description: 'Add documentation to code',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        files: { type: 'array', items: { type: 'string' } },
        documentation_type: { 
          type: 'string',
          enum: ['inline', 'readme', 'api_docs', 'all']
        },
      },
      required: ['task_id', 'files']
    }
  },
  {
    name: 'get_task_details',
    description: 'Get detailed information about a task',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        include_history: { type: 'boolean', default: true },
      },
      required: ['task_id']
    }
  },
  {
    name: 'list_available_tasks',
    description: 'List tasks available for pickup in the department',
    inputSchema: {
      type: 'object',
      properties: {
        priority_filter: { 
          type: 'array',
          items: { 
            type: 'string',
            enum: ['critical', 'high', 'medium', 'low']
          }
        },
        task_type_filter: {
          type: 'array',
          items: { 
            type: 'string',
            enum: ['feature', 'bugfix', 'refactor', 'documentation', 'testing']
          }
        }
      }
    }
  }
];
