/**
 * CTO Tools Definition
 * Strategic planning and organization management tools
 */

import { Tool } from '@modelcontextprotocol/sdk/types.js';

export const CTO_TOOLS: Tool[] = [
  {
    name: 'create_project',
    description: 'Create a new project with initial structure and department assignments',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Project name' },
        description: { type: 'string', description: 'Project description' },
        departments_involved: { 
          type: 'array', 
          items: { type: 'string' },
          description: 'Departments to involve (frontend, backend, devops, qa)'
        },
        technical_requirements: { type: 'string' },
        target_completion: { type: 'string', format: 'date-time' },
      },
      required: ['name', 'description', 'departments_involved']
    }
  },
  {
    name: 'assign_department_task',
    description: 'Assign a high-level task to a department head',
    inputSchema: {
      type: 'object',
      properties: {
        project_id: { type: 'string' },
        department: { type: 'string' },
        title: { type: 'string' },
        description: { type: 'string' },
        priority: { 
          type: 'string', 
          enum: ['critical', 'high', 'medium', 'low'],
          default: 'medium'
        },
        deadline: { type: 'string', format: 'date-time' },
      },
      required: ['project_id', 'department', 'title', 'description']
    }
  },
  {
    name: 'review_architecture',
    description: 'Review and approve architecture decisions from departments',
    inputSchema: {
      type: 'object',
      properties: {
        project_id: { type: 'string' },
        architecture_proposal: { type: 'string' },
        decision: { 
          type: 'string', 
          enum: ['approve', 'request_changes', 'reject']
        },
        feedback: { type: 'string' },
      },
      required: ['project_id', 'architecture_proposal', 'decision']
    }
  },
  {
    name: 'get_organization_status',
    description: 'Get comprehensive status of all departments and projects',
    inputSchema: {
      type: 'object',
      properties: {
        include_metrics: { type: 'boolean', default: true },
        include_active_tasks: { type: 'boolean', default: true },
      }
    }
  },
  {
    name: 'generate_executive_report',
    description: 'Generate executive report for the organization',
    inputSchema: {
      type: 'object',
      properties: {
        period_start: { type: 'string', format: 'date-time' },
        period_end: { type: 'string', format: 'date-time' },
        include_details: { type: 'boolean', default: false },
      },
      required: ['period_start', 'period_end']
    }
  },
  {
    name: 'coordinate_departments',
    description: 'Coordinate between departments for cross-functional tasks',
    inputSchema: {
      type: 'object',
      properties: {
        project_id: { type: 'string' },
        coordinating_departments: { 
          type: 'array', 
          items: { type: 'string' } 
        },
        coordination_type: { 
          type: 'string',
          enum: ['api_contract', 'integration', 'shared_component', 'deployment']
        },
        requirements: { type: 'string' },
      },
      required: ['project_id', 'coordinating_departments', 'coordination_type']
    }
  },
  {
    name: 'register_department_head',
    description: 'Register a new department head agent',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string' },
        department: { type: 'string' },
        role: { 
          type: 'string',
          enum: ['frontend_head', 'backend_head', 'devops_head', 'qa_head']
        },
        skills: { type: 'array', items: { type: 'string' } },
        specialties: { type: 'array', items: { type: 'string' } },
        experience_level: { 
          type: 'string', 
          enum: ['junior', 'mid', 'senior'],
          default: 'senior'
        },
      },
      required: ['name', 'department', 'role']
    }
  },
  {
    name: 'get_agent_hierarchy',
    description: 'Get the complete agent hierarchy tree',
    inputSchema: {
      type: 'object',
      properties: {
        include_inactive: { type: 'boolean', default: false },
      }
    }
  },
  {
    name: 'broadcast_message',
    description: 'Broadcast a message to all agents or specific departments',
    inputSchema: {
      type: 'object',
      properties: {
        message: { type: 'string' },
        target: { 
          type: 'string',
          enum: ['all', 'managers', 'workers'],
          default: 'all'
        },
        departments: { 
          type: 'array', 
          items: { type: 'string' } 
        },
        priority: { 
          type: 'string',
          enum: ['low', 'medium', 'high', 'critical'],
          default: 'medium'
        },
      },
      required: ['message']
    }
  }
];
