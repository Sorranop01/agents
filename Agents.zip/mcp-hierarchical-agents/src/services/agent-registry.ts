/**
 * Agent Registry Service
 * Manages agent registration, lookup, and hierarchy
 */

import { v4 as uuidv4 } from 'uuid';
import {
  Agent,
  AgentRole,
  AgentLevel,
  AgentStatus,
  AgentMetadata,
  RegisterAgentRequest,
  RegisterAgentResponse,
  DEPARTMENT_MAP,
  ROLE_LEVEL_MAP,
  DEFAULT_AGENT_METADATA,
} from '../schemas/agent-registry.js';

export class AgentRegistryService {
  private agents: Map<string, Agent> = new Map();
  private agentsByRole: Map<AgentRole, string[]> = new Map();
  private agentsByDepartment: Map<string, string[]> = new Map();

  /**
   * Register a new agent
   */
  registerAgent(request: RegisterAgentRequest): RegisterAgentResponse {
    const id = uuidv4();
    const now = new Date().toISOString();
    
    const metadata: AgentMetadata = {
      ...DEFAULT_AGENT_METADATA,
      ...request.metadata,
    };

    const agent: Agent = {
      id,
      name: request.name,
      role: request.role,
      level: ROLE_LEVEL_MAP[request.role],
      department: DEPARTMENT_MAP[request.role],
      parent_id: request.parent_id || null,
      child_ids: [],
      status: AgentStatus.IDLE,
      metadata,
      created_at: now,
      updated_at: now,
      last_heartbeat: now,
    };

    // Store agent
    this.agents.set(id, agent);

    // Update role index
    const roleAgents = this.agentsByRole.get(request.role) || [];
    roleAgents.push(id);
    this.agentsByRole.set(request.role, roleAgents);

    // Update department index
    const deptAgents = this.agentsByDepartment.get(agent.department) || [];
    deptAgents.push(id);
    this.agentsByDepartment.set(agent.department, deptAgents);

    // Update parent's child_ids
    if (request.parent_id) {
      const parent = this.agents.get(request.parent_id);
      if (parent) {
        parent.child_ids.push(id);
        this.agents.set(request.parent_id, parent);
      }
    }

    // Determine tools and resources
    const assignedTools = this.getToolsForRole(request.role);
    const accessibleResources = this.getResourcesForRole(request.role);

    return {
      agent,
      assigned_tools: assignedTools,
      accessible_resources: accessibleResources,
    };
  }

  /**
   * Get agent by ID
   */
  getAgent(id: string): Agent | undefined {
    return this.agents.get(id);
  }

  /**
   * Get all agents
   */
  getAllAgents(): Agent[] {
    return Array.from(this.agents.values());
  }

  /**
   * Get agents by role
   */
  getAgentsByRole(role: AgentRole): Agent[] {
    const agentIds = this.agentsByRole.get(role) || [];
    return agentIds.map(id => this.agents.get(id)!).filter(Boolean);
  }

  /**
   * Get agents by department
   */
  getAgentsByDepartment(department: string): Agent[] {
    const agentIds = this.agentsByDepartment.get(department) || [];
    return agentIds.map(id => this.agents.get(id)!).filter(Boolean);
  }

  /**
   * Get child agents
   */
  getChildAgents(parentId: string): Agent[] {
    const parent = this.agents.get(parentId);
    if (!parent) return [];
    return parent.child_ids.map(id => this.agents.get(id)!).filter(Boolean);
  }

  /**
   * Get agent hierarchy tree
   */
  getHierarchyTree(rootId?: string): any {
    const buildTree = (agentId: string): any => {
      const agent = this.agents.get(agentId);
      if (!agent) return null;

      return {
        ...agent,
        children: agent.child_ids.map(childId => buildTree(childId)).filter(Boolean),
      };
    };

    if (rootId) {
      return buildTree(rootId);
    }

    // Find root agents (CTO or agents without parent)
    const rootAgents = Array.from(this.agents.values())
      .filter(a => a.parent_id === null);
    
    return rootAgents.map(a => buildTree(a.id));
  }

  /**
   * Update agent status
   */
  updateAgentStatus(id: string, status: AgentStatus): Agent | undefined {
    const agent = this.agents.get(id);
    if (!agent) return undefined;

    agent.status = status;
    agent.updated_at = new Date().toISOString();
    agent.last_heartbeat = new Date().toISOString();

    this.agents.set(id, agent);
    return agent;
  }

  /**
   * Update agent heartbeat
   */
  updateHeartbeat(id: string): void {
    const agent = this.agents.get(id);
    if (agent) {
      agent.last_heartbeat = new Date().toISOString();
      this.agents.set(id, agent);
    }
  }

  /**
   * Remove agent
   */
  removeAgent(id: string): boolean {
    const agent = this.agents.get(id);
    if (!agent) return false;

    // Remove from parent's child_ids
    if (agent.parent_id) {
      const parent = this.agents.get(agent.parent_id);
      if (parent) {
        parent.child_ids = parent.child_ids.filter(cid => cid !== id);
        this.agents.set(agent.parent_id, parent);
      }
    }

    // Remove from role index
    const roleAgents = this.agentsByRole.get(agent.role) || [];
    this.agentsByRole.set(agent.role, roleAgents.filter(aid => aid !== id));

    // Remove from department index
    const deptAgents = this.agentsByDepartment.get(agent.department) || [];
    this.agentsByDepartment.set(agent.department, deptAgents.filter(aid => aid !== id));

    // Remove agent
    this.agents.delete(id);
    return true;
  }

  /**
   * Get tools for role
   */
  private getToolsForRole(role: AgentRole): string[] {
    const toolMap: Record<AgentRole, string[]> = {
      [AgentRole.CTO]: [
        'create_project',
        'assign_department_task',
        'review_architecture',
        'get_organization_status',
        'generate_executive_report',
        'coordinate_departments',
        'register_department_head',
        'get_agent_hierarchy',
        'broadcast_message',
      ],
      [AgentRole.FRONTEND_HEAD]: [
        'delegate_task',
        'create_subtask',
        'review_worker_code',
        'get_department_status',
        'register_worker',
        'submit_department_report',
        'request_architecture_review',
        'escalate_issue',
        'reassign_task',
        'get_worker_workload',
      ],
      [AgentRole.BACKEND_HEAD]: [
        'delegate_task',
        'create_subtask',
        'review_worker_code',
        'get_department_status',
        'register_worker',
        'submit_department_report',
        'request_architecture_review',
        'escalate_issue',
        'reassign_task',
        'get_worker_workload',
      ],
      [AgentRole.DEVOPS_HEAD]: [
        'delegate_task',
        'create_subtask',
        'review_worker_code',
        'get_department_status',
        'register_worker',
        'submit_department_report',
        'request_architecture_review',
        'escalate_issue',
        'reassign_task',
        'get_worker_workload',
      ],
      [AgentRole.QA_HEAD]: [
        'delegate_task',
        'create_subtask',
        'review_worker_code',
        'get_department_status',
        'register_worker',
        'submit_department_report',
        'request_architecture_review',
        'escalate_issue',
        'reassign_task',
        'get_worker_workload',
      ],
      [AgentRole.FRONTEND_WORKER]: [
        'accept_task',
        'write_code',
        'run_tests',
        'update_task_progress',
        'submit_for_review',
        'request_help',
        'research_solution',
        'document_code',
        'get_task_details',
        'list_available_tasks',
      ],
      [AgentRole.BACKEND_WORKER]: [
        'accept_task',
        'write_code',
        'run_tests',
        'update_task_progress',
        'submit_for_review',
        'request_help',
        'research_solution',
        'document_code',
        'get_task_details',
        'list_available_tasks',
      ],
      [AgentRole.DEVOPS_WORKER]: [
        'accept_task',
        'write_code',
        'run_tests',
        'update_task_progress',
        'submit_for_review',
        'request_help',
        'research_solution',
        'document_code',
        'get_task_details',
        'list_available_tasks',
      ],
      [AgentRole.QA_WORKER]: [
        'accept_task',
        'write_code',
        'run_tests',
        'update_task_progress',
        'submit_for_review',
        'request_help',
        'research_solution',
        'document_code',
        'get_task_details',
        'list_available_tasks',
      ],
    };

    return toolMap[role] || [];
  }

  /**
   * Get resources for role
   */
  private getResourcesForRole(role: AgentRole): string[] {
    const level = ROLE_LEVEL_MAP[role];
    
    const baseResources = [
      'repo://{project_id}/{branch}',
      'tasks://{project_id}/board',
      'docs://{project_id}/{path}',
    ];

    if (level <= AgentLevel.MANAGEMENT) {
      baseResources.push('agents://registry');
      baseResources.push('reports://{type}/{id}');
    }

    if (role === AgentRole.CTO || role === AgentRole.DEVOPS_HEAD || role === AgentRole.DEVOPS_WORKER) {
      baseResources.push('logs://system/{date}');
    }

    return baseResources;
  }
}

// Singleton instance
export const agentRegistry = new AgentRegistryService();
