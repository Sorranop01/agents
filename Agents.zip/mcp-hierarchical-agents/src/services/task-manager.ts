/**
 * Task Manager Service
 * Manages tasks, projects, and assignments
 */

import { v4 as uuidv4 } from 'uuid';
import {
  Task,
  Project,
  TaskStatus,
  TaskPriority,
  TaskType,
  CreateTaskRequest,
  TaskUpdateRequest,
  DEFAULT_TASK_REQUIREMENTS,
} from '../schemas/task-structure.js';

export class TaskManagerService {
  private tasks: Map<string, Task> = new Map();
  private projects: Map<string, Project> = new Map();
  private tasksByProject: Map<string, string[]> = new Map();
  private tasksByAssignee: Map<string, string[]> = new Map();

  /**
   * Create a new project
   */
  createProject(
    name: string,
    description: string,
    createdBy: string,
    departmentsInvolved: string[],
    options?: {
      repository_url?: string;
      target_completion?: string;
    }
  ): Project {
    const id = uuidv4();
    const now = new Date().toISOString();

    const project: Project = {
      id,
      name,
      description,
      created_by: createdBy,
      departments_involved: departmentsInvolved,
      root_task_ids: [],
      status: 'planning',
      repository_url: options?.repository_url,
      default_branch: 'main',
      created_at: now,
      updated_at: now,
      target_completion: options?.target_completion,
    };

    this.projects.set(id, project);
    return project;
  }

  /**
   * Get project by ID
   */
  getProject(id: string): Project | undefined {
    return this.projects.get(id);
  }

  /**
   * Get all projects
   */
  getAllProjects(): Project[] {
    return Array.from(this.projects.values());
  }

  /**
   * Create a new task
   */
  createTask(request: CreateTaskRequest, createdBy: string): Task {
    const id = uuidv4();
    const now = new Date().toISOString();

    const task: Task = {
      id,
      project_id: request.project_id,
      parent_task_id: request.parent_task_id,
      subtask_ids: [],
      created_by: createdBy,
      assigned_to: request.assigned_to,
      title: request.title,
      type: request.type,
      priority: request.priority,
      status: request.assigned_to ? TaskStatus.ASSIGNED : TaskStatus.PENDING,
      requirements: {
        ...DEFAULT_TASK_REQUIREMENTS,
        ...request.requirements,
      },
      code_changes: [],
      created_at: now,
      updated_at: now,
      deadline: request.deadline,
      progress_percentage: 0,
      notes: [],
    };

    // Store task
    this.tasks.set(id, task);

    // Update project task index
    const projectTasks = this.tasksByProject.get(request.project_id) || [];
    projectTasks.push(id);
    this.tasksByProject.set(request.project_id, projectTasks);

    // Update parent task if exists
    if (request.parent_task_id) {
      const parentTask = this.tasks.get(request.parent_task_id);
      if (parentTask) {
        parentTask.subtask_ids.push(id);
        this.tasks.set(request.parent_task_id, parentTask);
      }
    } else {
      // Add to project root tasks
      const project = this.projects.get(request.project_id);
      if (project) {
        project.root_task_ids.push(id);
        this.projects.set(request.project_id, project);
      }
    }

    // Update assignee index
    if (request.assigned_to) {
      const assigneeTasks = this.tasksByAssignee.get(request.assigned_to) || [];
      assigneeTasks.push(id);
      this.tasksByAssignee.set(request.assigned_to, assigneeTasks);
    }

    return task;
  }

  /**
   * Get task by ID
   */
  getTask(id: string): Task | undefined {
    return this.tasks.get(id);
  }

  /**
   * Get all tasks
   */
  getAllTasks(): Task[] {
    return Array.from(this.tasks.values());
  }

  /**
   * Get tasks by project
   */
  getTasksByProject(projectId: string): Task[] {
    const taskIds = this.tasksByProject.get(projectId) || [];
    return taskIds.map(id => this.tasks.get(id)!).filter(Boolean);
  }

  /**
   * Get tasks by assignee
   */
  getTasksByAssignee(assigneeId: string): Task[] {
    const taskIds = this.tasksByAssignee.get(assigneeId) || [];
    return taskIds.map(id => this.tasks.get(id)!).filter(Boolean);
  }

  /**
   * Get tasks by status
   */
  getTasksByStatus(status: TaskStatus): Task[] {
    return Array.from(this.tasks.values()).filter(t => t.status === status);
  }

  /**
   * Get available tasks (not assigned)
   */
  getAvailableTasks(department?: string): Task[] {
    return Array.from(this.tasks.values()).filter(t => 
      t.status === TaskStatus.PENDING &&
      (!department || this.isTaskInDepartment(t, department))
    );
  }

  /**
   * Update task
   */
  updateTask(taskId: string, update: TaskUpdateRequest): Task | undefined {
    const task = this.tasks.get(taskId);
    if (!task) return undefined;

    if (update.progress_percentage !== undefined) {
      task.progress_percentage = update.progress_percentage;
    }

    if (update.status) {
      task.status = update.status;
      
      if (update.status === TaskStatus.IN_PROGRESS && !task.started_at) {
        task.started_at = new Date().toISOString();
      }
      
      if (update.status === TaskStatus.COMPLETED && !task.completed_at) {
        task.completed_at = new Date().toISOString();
      }
    }

    if (update.notes) {
      task.notes.push(...update.notes);
    }

    if (update.blockers) {
      task.blockers = update.blockers;
      if (update.blockers.length > 0) {
        task.status = TaskStatus.BLOCKED;
      }
    }

    task.updated_at = new Date().toISOString();
    this.tasks.set(taskId, task);

    return task;
  }

  /**
   * Assign task to agent
   */
  assignTask(taskId: string, agentId: string, delegatedBy?: string): Task | undefined {
    const task = this.tasks.get(taskId);
    if (!task) return undefined;

    // Remove from old assignee index
    if (task.assigned_to) {
      const oldAssigneeTasks = this.tasksByAssignee.get(task.assigned_to) || [];
      this.tasksByAssignee.set(
        task.assigned_to,
        oldAssigneeTasks.filter(tid => tid !== taskId)
      );
    }

    // Update task
    task.assigned_to = agentId;
    task.delegated_by = delegatedBy;
    task.status = TaskStatus.ASSIGNED;
    task.updated_at = new Date().toISOString();

    // Add to new assignee index
    const newAssigneeTasks = this.tasksByAssignee.get(agentId) || [];
    newAssigneeTasks.push(taskId);
    this.tasksByAssignee.set(agentId, newAssigneeTasks);

    this.tasks.set(taskId, task);
    return task;
  }

  /**
   * Add code changes to task
   */
  addCodeChanges(taskId: string, codeChanges: Task['code_changes']): Task | undefined {
    const task = this.tasks.get(taskId);
    if (!task) return undefined;

    task.code_changes.push(...codeChanges);
    task.updated_at = new Date().toISOString();
    this.tasks.set(taskId, task);

    return task;
  }

  /**
   * Get task tree (with subtasks)
   */
  getTaskTree(taskId: string): any {
    const task = this.tasks.get(taskId);
    if (!task) return null;

    return {
      ...task,
      subtasks: task.subtask_ids.map(subId => this.getTaskTree(subId)).filter(Boolean),
    };
  }

  /**
   * Get project status summary
   */
  getProjectStatus(projectId: string): {
    total: number;
    pending: number;
    in_progress: number;
    completed: number;
    blocked: number;
  } {
    const tasks = this.getTasksByProject(projectId);
    
    return {
      total: tasks.length,
      pending: tasks.filter(t => t.status === TaskStatus.PENDING).length,
      in_progress: tasks.filter(t => t.status === TaskStatus.IN_PROGRESS).length,
      completed: tasks.filter(t => t.status === TaskStatus.COMPLETED).length,
      blocked: tasks.filter(t => t.status === TaskStatus.BLOCKED).length,
    };
  }

  /**
   * Delete task
   */
  deleteTask(taskId: string): boolean {
    const task = this.tasks.get(taskId);
    if (!task) return false;

    // Remove from project index
    const projectTasks = this.tasksByProject.get(task.project_id) || [];
    this.tasksByProject.set(
      task.project_id,
      projectTasks.filter(tid => tid !== taskId)
    );

    // Remove from assignee index
    if (task.assigned_to) {
      const assigneeTasks = this.tasksByAssignee.get(task.assigned_to) || [];
      this.tasksByAssignee.set(
        task.assigned_to,
        assigneeTasks.filter(tid => tid !== taskId)
      );
    }

    // Remove from parent
    if (task.parent_task_id) {
      const parent = this.tasks.get(task.parent_task_id);
      if (parent) {
        parent.subtask_ids = parent.subtask_ids.filter(sid => sid !== taskId);
        this.tasks.set(task.parent_task_id, parent);
      }
    }

    // Delete subtasks recursively
    for (const subId of task.subtask_ids) {
      this.deleteTask(subId);
    }

    this.tasks.delete(taskId);
    return true;
  }

  /**
   * Check if task is in department
   */
  private isTaskInDepartment(task: Task, department: string): boolean {
    const project = this.projects.get(task.project_id);
    if (!project) return false;
    return project.departments_involved.includes(department);
  }
}

// Singleton instance
export const taskManager = new TaskManagerService();
