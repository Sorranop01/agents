/**
 * Message Broker Service
 * Handles communication between agents
 */

import { v4 as uuidv4 } from 'uuid';
import {
  BaseMessage,
  MessageType,
  TaskAssignedMessage,
  TaskUpdatedMessage,
  CodeSubmittedMessage,
  CodeReviewedMessage,
  HeartbeatMessage,
  ErrorMessage,
  Message,
} from '../schemas/messages.js';

type MessageHandler = (message: Message) => void;

export class MessageBrokerService {
  private messageHistory: Message[] = [];
  private handlers: Map<MessageType, MessageHandler[]> = new Map();
  private pendingResponses: Map<string, (message: Message) => void> = new Map();

  /**
   * Send a message
   */
  sendMessage<T extends Message>(
    type: MessageType,
    senderId: string,
    recipientId: string,
    payload: Omit<T, 'id' | 'type' | 'sender_id' | 'recipient_id' | 'timestamp'>,
    correlationId?: string
  ): T {
    const message = {
      id: uuidv4(),
      type,
      sender_id: senderId,
      recipient_id: recipientId,
      timestamp: new Date().toISOString(),
      correlation_id: correlationId,
      ...payload,
    } as T;

    // Store message
    this.messageHistory.push(message);

    // Notify handlers
    this.notifyHandlers(type, message);

    // Check for pending response
    if (correlationId) {
      const resolver = this.pendingResponses.get(correlationId);
      if (resolver) {
        resolver(message);
        this.pendingResponses.delete(correlationId);
      }
    }

    return message;
  }

  /**
   * Send message and wait for response
   */
  async sendMessageAndWait<T extends Message>(
    type: MessageType,
    senderId: string,
    recipientId: string,
    payload: Omit<T, 'id' | 'type' | 'sender_id' | 'recipient_id' | 'timestamp'>,
    timeoutMs: number = 30000
  ): Promise<Message> {
    const correlationId = uuidv4();
    
    this.sendMessage(type, senderId, recipientId, payload, correlationId);

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pendingResponses.delete(correlationId);
        reject(new Error(`Message timeout after ${timeoutMs}ms`));
      }, timeoutMs);

      this.pendingResponses.set(correlationId, (response: Message) => {
        clearTimeout(timeout);
        resolve(response);
      });
    });
  }

  /**
   * Subscribe to message type
   */
  subscribe(type: MessageType, handler: MessageHandler): () => void {
    const handlers = this.handlers.get(type) || [];
    handlers.push(handler);
    this.handlers.set(type, handlers);

    // Return unsubscribe function
    return () => {
      const currentHandlers = this.handlers.get(type) || [];
      this.handlers.set(
        type,
        currentHandlers.filter(h => h !== handler)
      );
    };
  }

  /**
   * Broadcast message to multiple recipients
   */
  broadcast<T extends Message>(
    type: MessageType,
    senderId: string,
    recipientIds: string[],
    payload: Omit<T, 'id' | 'type' | 'sender_id' | 'recipient_id' | 'timestamp'>
  ): T[] {
    return recipientIds.map(recipientId =>
      this.sendMessage(type, senderId, recipientId, payload)
    );
  }

  /**
   * Get message history
   */
  getMessageHistory(
    filters?: {
      senderId?: string;
      recipientId?: string;
      type?: MessageType;
      since?: string;
    }
  ): Message[] {
    let messages = [...this.messageHistory];

    if (filters?.senderId) {
      messages = messages.filter(m => m.sender_id === filters.senderId);
    }

    if (filters?.recipientId) {
      messages = messages.filter(m => m.recipient_id === filters.recipientId);
    }

    if (filters?.type) {
      messages = messages.filter(m => m.type === filters.type);
    }

    if (filters?.since) {
      messages = messages.filter(m => m.timestamp >= filters.since!);
    }

    return messages;
  }

  /**
   * Get messages for agent
   */
  getMessagesForAgent(agentId: string): Message[] {
    return this.messageHistory.filter(
      m => m.recipient_id === agentId || m.sender_id === agentId
    );
  }

  /**
   * Get unread messages for agent
   */
  getUnreadMessages(agentId: string, lastReadTimestamp: string): Message[] {
    return this.messageHistory.filter(
      m => m.recipient_id === agentId && m.timestamp > lastReadTimestamp
    );
  }

  /**
   * Create task assigned message
   */
  createTaskAssignedMessage(
    senderId: string,
    recipientId: string,
    taskId: string,
    taskDetails: TaskAssignedMessage['task_details'],
    instructions?: string
  ): TaskAssignedMessage {
    return this.sendMessage(
      MessageType.TASK_ASSIGNED,
      senderId,
      recipientId,
      { task_id: taskId, task_details: taskDetails, instructions }
    );
  }

  /**
   * Create task updated message
   */
  createTaskUpdatedMessage(
    senderId: string,
    recipientId: string,
    taskId: string,
    updateType: TaskUpdatedMessage['update_type'],
    data: TaskUpdatedMessage['data']
  ): TaskUpdatedMessage {
    return this.sendMessage(
      MessageType.TASK_UPDATED,
      senderId,
      recipientId,
      { task_id: taskId, update_type: updateType, data }
    );
  }

  /**
   * Create code submitted message
   */
  createCodeSubmittedMessage(
    senderId: string,
    recipientId: string,
    taskId: string,
    files: string[],
    summary: string,
    testingStatus: string
  ): CodeSubmittedMessage {
    return this.sendMessage(
      MessageType.CODE_SUBMITTED,
      senderId,
      recipientId,
      { task_id: taskId, files, summary, testing_status: testingStatus }
    );
  }

  /**
   * Create code reviewed message
   */
  createCodeReviewedMessage(
    senderId: string,
    recipientId: string,
    taskId: string,
    decision: CodeReviewedMessage['decision'],
    findings: CodeReviewedMessage['findings'],
    feedback: string
  ): CodeReviewedMessage {
    return this.sendMessage(
      MessageType.CODE_REVIEWED,
      senderId,
      recipientId,
      { task_id: taskId, reviewer_id: senderId, decision, findings, feedback }
    );
  }

  /**
   * Create heartbeat message
   */
  createHeartbeatMessage(
    agentId: string,
    status: string,
    loadPercentage: number,
    currentTaskId?: string
  ): HeartbeatMessage {
    return this.sendMessage(
      MessageType.HEARTBEAT,
      agentId,
      'system',
      { agent_id: agentId, status, current_task_id: currentTaskId, load_percentage: loadPercentage }
    );
  }

  /**
   * Create error message
   */
  createErrorMessage(
    senderId: string,
    recipientId: string,
    errorCode: string,
    errorMessage: string,
    context?: Record<string, any>
  ): ErrorMessage {
    return this.sendMessage(
      MessageType.ERROR,
      senderId,
      recipientId,
      { error_code: errorCode, error_message: errorMessage, context }
    );
  }

  /**
   * Notify handlers
   */
  private notifyHandlers(type: MessageType, message: Message): void {
    const handlers = this.handlers.get(type) || [];
    handlers.forEach(handler => {
      try {
        handler(message);
      } catch (error) {
        console.error(`Error in message handler for ${type}:`, error);
      }
    });
  }

  /**
   * Clear message history
   */
  clearHistory(): void {
    this.messageHistory = [];
  }
}

// Singleton instance
export const messageBroker = new MessageBrokerService();
