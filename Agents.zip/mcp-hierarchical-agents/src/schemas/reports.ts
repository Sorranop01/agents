/**
 * Report Schemas
 * Defines all types and interfaces for reporting
 */

export enum ReportType {
  PROGRESS = 'progress',
  COMPLETION = 'completion',
  ERROR = 'error',
  CODE_REVIEW = 'code_review',
  ARCHITECTURE = 'architecture',
  PERFORMANCE = 'performance',
}

export interface CodeReviewFinding {
  severity: 'critical' | 'major' | 'minor' | 'info';
  file_path: string;
  line_number?: number;
  message: string;
  suggestion?: string;
}

export interface CodeReviewReport {
  id: string;
  task_id: string;
  reviewer_id: string;
  files_reviewed: string[];
  findings: CodeReviewFinding[];
  approval_status: 'approved' | 'changes_requested' | 'rejected';
  overall_feedback: string;
  created_at: string;
}

export interface ProgressReport {
  id: string;
  task_id: string;
  agent_id: string;
  report_type: ReportType;
  period_start: string;
  period_end: string;
  
  summary: string;
  accomplishments: string[];
  challenges: string[];
  
  tasks_completed: number;
  tasks_in_progress: number;
  tasks_blocked: number;
  code_lines_added: number;
  code_lines_removed: number;
  files_modified: number;
  
  next_steps: string[];
  estimated_completion?: string;
  
  blockers?: {
    description: string;
    blocking_since: string;
    resolution_needed_from?: string;
  }[];
  
  created_at: string;
}

export interface DepartmentReport {
  id: string;
  department: string;
  head_id: string;
  period_start: string;
  period_end: string;
  
  summary: string;
  
  worker_reports: ProgressReport[];
  
  total_tasks: number;
  completed_tasks: number;
  avg_completion_time_hours: number;
  
  issues: string[];
  recommendations: string[];
  
  created_at: string;
}

export interface ExecutiveReport {
  id: string;
  period_start: string;
  period_end: string;
  
  organization_summary: string;
  
  department_reports: DepartmentReport[];
  
  key_metrics: {
    total_projects: number;
    active_projects: number;
    completed_projects: number;
    total_agents: number;
    active_agents: number;
    avg_department_load: number;
    code_quality_score: number;
    on_time_delivery_rate: number;
  };
  
  strategic_recommendations: string[];
  risks: string[];
  opportunities: string[];
  
  created_at: string;
}

export interface CreateReportRequest {
  report_type: ReportType;
  task_id?: string;
  period_start?: string;
  period_end?: string;
  summary?: string;
  details?: Record<string, any>;
}
