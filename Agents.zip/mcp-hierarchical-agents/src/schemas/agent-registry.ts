/**
 * Agent Registry Schemas
 * Defines all types and interfaces for agent management
 */

export enum AgentRole {
  CTO = 'cto',
  FRONTEND_HEAD = 'frontend_head',
  BACKEND_HEAD = 'backend_head',
  DEVOPS_HEAD = 'devops_head',
  QA_HEAD = 'qa_head',
  FRONTEND_WORKER = 'frontend_worker',
  BACKEND_WORKER = 'backend_worker',
  DEVOPS_WORKER = 'devops_worker',
  QA_WORKER = 'qa_worker',
}

export enum AgentLevel {
  EXECUTIVE = 0,
  MANAGEMENT = 1,
  WORKER = 2,
}

export enum AgentStatus {
  IDLE = 'idle',
  BUSY = 'busy',
  OFFLINE = 'offline',
  ERROR = 'error',
}

export interface AgentMetadata {
  skills: string[];
  specialties: string[];
  experience_level: 'junior' | 'mid' | 'senior';
  max_concurrent_tasks: number;
  preferred_languages: string[];
  frameworks: string[];
}

export interface Agent {
  id: string;
  name: string;
  role: AgentRole;
  level: AgentLevel;
  department: string;
  parent_id: string | null;
  child_ids: string[];
  status: AgentStatus;
  metadata: AgentMetadata;
  created_at: string;
  updated_at: string;
  last_heartbeat: string;
}

export interface RegisterAgentRequest {
  name: string;
  role: AgentRole;
  department: string;
  parent_id: string;
  metadata: Partial<AgentMetadata>;
}

export interface RegisterAgentResponse {
  agent: Agent;
  assigned_tools: string[];
  accessible_resources: string[];
}

export const DEPARTMENT_MAP: Record<AgentRole, string> = {
  [AgentRole.CTO]: 'executive',
  [AgentRole.FRONTEND_HEAD]: 'frontend',
  [AgentRole.BACKEND_HEAD]: 'backend',
  [AgentRole.DEVOPS_HEAD]: 'devops',
  [AgentRole.QA_HEAD]: 'qa',
  [AgentRole.FRONTEND_WORKER]: 'frontend',
  [AgentRole.BACKEND_WORKER]: 'backend',
  [AgentRole.DEVOPS_WORKER]: 'devops',
  [AgentRole.QA_WORKER]: 'qa',
};

export const ROLE_LEVEL_MAP: Record<AgentRole, AgentLevel> = {
  [AgentRole.CTO]: AgentLevel.EXECUTIVE,
  [AgentRole.FRONTEND_HEAD]: AgentLevel.MANAGEMENT,
  [AgentRole.BACKEND_HEAD]: AgentLevel.MANAGEMENT,
  [AgentRole.DEVOPS_HEAD]: AgentLevel.MANAGEMENT,
  [AgentRole.QA_HEAD]: AgentLevel.MANAGEMENT,
  [AgentRole.FRONTEND_WORKER]: AgentLevel.WORKER,
  [AgentRole.BACKEND_WORKER]: AgentLevel.WORKER,
  [AgentRole.DEVOPS_WORKER]: AgentLevel.WORKER,
  [AgentRole.QA_WORKER]: AgentLevel.WORKER,
};

export const DEFAULT_AGENT_METADATA: AgentMetadata = {
  skills: [],
  specialties: [],
  experience_level: 'mid',
  max_concurrent_tasks: 3,
  preferred_languages: [],
  frameworks: [],
};
