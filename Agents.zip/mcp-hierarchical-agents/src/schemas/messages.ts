/**
 * Message Protocol Schemas
 * Defines all message types for agent communication
 */

export enum MessageType {
  TASK_CREATED = 'task_created',
  TASK_ASSIGNED = 'task_assigned',
  TASK_ACCEPTED = 'task_accepted',
  TASK_UPDATED = 'task_updated',
  TASK_COMPLETED = 'task_completed',
  TASK_BLOCKED = 'task_blocked',
  
  DELEGATE_REQUEST = 'delegate_request',
  DELEGATE_ACCEPTED = 'delegate_accepted',
  DELEGATE_REJECTED = 'delegate_rejected',
  
  CODE_SUBMITTED = 'code_submitted',
  CODE_REVIEWED = 'code_reviewed',
  REVIEW_FEEDBACK = 'review_feedback',
  
  PROGRESS_REPORT = 'progress_report',
  DEPARTMENT_REPORT = 'department_report',
  EXECUTIVE_REPORT = 'executive_report',
  
  HEARTBEAT = 'heartbeat',
  AGENT_REGISTERED = 'agent_registered',
  AGENT_STATUS_CHANGED = 'agent_status_changed',
  ERROR = 'error',
}

export interface BaseMessage {
  id: string;
  type: MessageType;
  sender_id: string;
  recipient_id: string;
  timestamp: string;
  correlation_id?: string;
}

export interface TaskAssignedMessage extends BaseMessage {
  type: MessageType.TASK_ASSIGNED;
  task_id: string;
  task_details: {
    title: string;
    description: string;
    priority: string;
    deadline?: string;
  };
  instructions?: string;
}

export interface TaskUpdatedMessage extends BaseMessage {
  type: MessageType.TASK_UPDATED;
  task_id: string;
  update_type: 'progress' | 'status' | 'blocker' | 'completion';
  data: {
    progress_percentage?: number;
    status?: string;
    message?: string;
    blockers?: string[];
  };
}

export interface CodeSubmittedMessage extends BaseMessage {
  type: MessageType.CODE_SUBMITTED;
  task_id: string;
  files: string[];
  summary: string;
  testing_status: string;
}

export interface CodeReviewedMessage extends BaseMessage {
  type: MessageType.CODE_REVIEWED;
  task_id: string;
  reviewer_id: string;
  decision: 'approved' | 'changes_requested' | 'rejected';
  findings: {
    severity: string;
    file_path: string;
    message: string;
  }[];
  feedback: string;
}

export interface HeartbeatMessage extends BaseMessage {
  type: MessageType.HEARTBEAT;
  agent_id: string;
  status: string;
  current_task_id?: string;
  load_percentage: number;
  memory_usage?: number;
}

export interface ErrorMessage extends BaseMessage {
  type: MessageType.ERROR;
  error_code: string;
  error_message: string;
  context?: Record<string, any>;
}

export type Message = 
  | TaskAssignedMessage 
  | TaskUpdatedMessage 
  | CodeSubmittedMessage 
  | CodeReviewedMessage 
  | HeartbeatMessage 
  | ErrorMessage
  | BaseMessage;
