/**
 * Task Structure Schemas
 * Defines all types and interfaces for task and project management
 */

export enum TaskPriority {
  CRITICAL = 'critical',
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low',
}

export enum TaskStatus {
  PENDING = 'pending',
  ASSIGNED = 'assigned',
  IN_PROGRESS = 'in_progress',
  IN_REVIEW = 'in_review',
  COMPLETED = 'completed',
  BLOCKED = 'blocked',
  CANCELLED = 'cancelled',
}

export enum TaskType {
  FEATURE = 'feature',
  BUGFIX = 'bugfix',
  REFACTOR = 'refactor',
  DOCUMENTATION = 'documentation',
  TESTING = 'testing',
  DEPLOYMENT = 'deployment',
  RESEARCH = 'research',
}

export interface CodeChange {
  file_path: string;
  change_type: 'create' | 'modify' | 'delete';
  content?: string;
  diff?: string;
  language: string;
}

export interface TaskRequirements {
  description: string;
  acceptance_criteria: string[];
  technical_requirements?: string[];
  dependencies?: string[];
  estimated_effort_hours?: number;
}

export interface Task {
  id: string;
  project_id: string;
  parent_task_id?: string;
  subtask_ids: string[];
  
  created_by: string;
  assigned_to?: string;
  delegated_by?: string;
  
  title: string;
  type: TaskType;
  priority: TaskPriority;
  status: TaskStatus;
  requirements: TaskRequirements;
  
  branch_name?: string;
  code_changes: CodeChange[];
  
  created_at: string;
  updated_at: string;
  started_at?: string;
  completed_at?: string;
  deadline?: string;
  
  progress_percentage: number;
  notes: string[];
  blockers?: string[];
}

export interface Project {
  id: string;
  name: string;
  description: string;
  created_by: string;
  
  departments_involved: string[];
  root_task_ids: string[];
  
  status: 'planning' | 'active' | 'completed' | 'archived';
  
  repository_url?: string;
  default_branch: string;
  
  created_at: string;
  updated_at: string;
  target_completion?: string;
}

export interface CreateTaskRequest {
  project_id: string;
  parent_task_id?: string;
  title: string;
  type: TaskType;
  priority: TaskPriority;
  requirements: TaskRequirements;
  assigned_to?: string;
  deadline?: string;
}

export interface DelegateTaskRequest {
  task_id: string;
  delegate_to: string;
  instructions?: string;
}

export interface TaskUpdateRequest {
  task_id: string;
  progress_percentage?: number;
  status?: TaskStatus;
  notes?: string;
  blockers?: string[];
}

export const DEFAULT_TASK_REQUIREMENTS: TaskRequirements = {
  description: '',
  acceptance_criteria: [],
  technical_requirements: [],
  dependencies: [],
  estimated_effort_hours: 0,
};
