/**
 * CTO Tool Handlers
 * Implements all CTO-level tool functionality
 */

import { agentRegistry } from '../services/agent-registry.js';
import { taskManager } from '../services/task-manager.js';
import { messageBroker } from '../services/message-broker.js';
import { AgentRole, AgentLevel, AgentStatus } from '../schemas/agent-registry.js';
import { TaskPriority, TaskType, TaskStatus } from '../schemas/task-structure.js';
import { MessageType } from '../schemas/messages.js';

export class CTOHandlers {
  /**
   * Create a new project
   */
  static async handleCreateProject(args: any) {
    const { name, description, departments_involved, technical_requirements, target_completion } = args;

    const ctoId = process.env.AGENT_ID || 'cto-001';

    const project = taskManager.createProject(
      name,
      description,
      ctoId,
      departments_involved,
      { target_completion }
    );

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Project "${name}" created successfully`,
            project: {
              id: project.id,
              name: project.name,
              description: project.description,
              departments_involved: project.departments_involved,
              status: project.status,
              created_at: project.created_at,
            },
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Assign task to department head
   */
  static async handleAssignDepartmentTask(args: any) {
    const { project_id, department, title, description, priority = 'medium', deadline } = args;

    const ctoId = process.env.AGENT_ID || 'cto-001';

    // Find department head
    const deptHeadRole = this.getDepartmentHeadRole(department);
    const deptHeads = agentRegistry.getAgentsByRole(deptHeadRole);

    if (deptHeads.length === 0) {
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              success: false,
              error: `No department head found for ${department} department`,
            }, null, 2),
          },
        ],
        isError: true,
      };
    }

    const deptHead = deptHeads[0];

    // Create task
    const task = taskManager.createTask(
      {
        project_id,
        title,
        type: TaskType.FEATURE,
        priority: priority as TaskPriority,
        requirements: {
          description,
          acceptance_criteria: [],
        },
        assigned_to: deptHead.id,
        deadline,
      },
      ctoId
    );

    // Send message to department head
    messageBroker.createTaskAssignedMessage(
      ctoId,
      deptHead.id,
      task.id,
      {
        title: task.title,
        description: task.requirements.description,
        priority: task.priority,
        deadline: task.deadline,
      }
    );

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Task assigned to ${department} department head`,
            task: {
              id: task.id,
              title: task.title,
              assigned_to: {
                id: deptHead.id,
                name: deptHead.name,
                role: deptHead.role,
              },
              priority: task.priority,
              status: task.status,
            },
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Review architecture proposal
   */
  static async handleReviewArchitecture(args: any) {
    const { project_id, architecture_proposal, decision, feedback } = args;

    const ctoId = process.env.AGENT_ID || 'cto-001';

    // In a real implementation, this would update the project with the decision
    const result = {
      project_id,
      decision,
      reviewed_by: ctoId,
      reviewed_at: new Date().toISOString(),
      feedback,
    };

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Architecture proposal ${decision}d`,
            result,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Get organization status
   */
  static async handleGetOrganizationStatus(args: any) {
    const { include_metrics = true, include_active_tasks = true } = args;

    const allAgents = agentRegistry.getAllAgents();
    const allProjects = taskManager.getAllProjects();
    const allTasks = taskManager.getAllTasks();

    const status = {
      agents: {
        total: allAgents.length,
        by_level: {
          executive: allAgents.filter(a => a.level === AgentLevel.EXECUTIVE).length,
          management: allAgents.filter(a => a.level === AgentLevel.MANAGEMENT).length,
          worker: allAgents.filter(a => a.level === AgentLevel.WORKER).length,
        },
        by_status: {
          idle: allAgents.filter(a => a.status === AgentStatus.IDLE).length,
          busy: allAgents.filter(a => a.status === AgentStatus.BUSY).length,
          offline: allAgents.filter(a => a.status === AgentStatus.OFFLINE).length,
        },
      },
      projects: {
        total: allProjects.length,
        by_status: {
          planning: allProjects.filter(p => p.status === 'planning').length,
          active: allProjects.filter(p => p.status === 'active').length,
          completed: allProjects.filter(p => p.status === 'completed').length,
        },
      },
      tasks: {
        total: allTasks.length,
        by_status: {
          pending: allTasks.filter(t => t.status === TaskStatus.PENDING).length,
          assigned: allTasks.filter(t => t.status === TaskStatus.ASSIGNED).length,
          in_progress: allTasks.filter(t => t.status === TaskStatus.IN_PROGRESS).length,
          in_review: allTasks.filter(t => t.status === TaskStatus.IN_REVIEW).length,
          completed: allTasks.filter(t => t.status === TaskStatus.COMPLETED).length,
          blocked: allTasks.filter(t => t.status === TaskStatus.BLOCKED).length,
        },
      },
    };

    if (include_active_tasks) {
      (status as any).active_tasks = allTasks
        .filter(t => t.status === TaskStatus.IN_PROGRESS || t.status === TaskStatus.IN_REVIEW)
        .map(t => ({
          id: t.id,
          title: t.title,
          status: t.status,
          assigned_to: t.assigned_to,
          progress: t.progress_percentage,
        }));
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(status, null, 2),
        },
      ],
    };
  }

  /**
   * Generate executive report
   */
  static async handleGenerateExecutiveReport(args: any) {
    const { period_start, period_end, include_details = false } = args;

    const ctoId = process.env.AGENT_ID || 'cto-001';

    const allProjects = taskManager.getAllProjects();
    const allAgents = agentRegistry.getAllAgents();
    const allTasks = taskManager.getAllTasks();

    const report = {
      id: `exec-report-${Date.now()}`,
      period_start,
      period_end,
      generated_by: ctoId,
      generated_at: new Date().toISOString(),
      organization_summary: `Executive report for period ${period_start} to ${period_end}`,
      key_metrics: {
        total_projects: allProjects.length,
        active_projects: allProjects.filter(p => p.status === 'active').length,
        completed_projects: allProjects.filter(p => p.status === 'completed').length,
        total_agents: allAgents.length,
        active_agents: allAgents.filter(a => a.status === AgentStatus.BUSY).length,
        avg_department_load: this.calculateAvgLoad(allAgents),
        code_quality_score: 85, // Placeholder
        on_time_delivery_rate: 78, // Placeholder
      },
      department_summaries: this.getDepartmentSummaries(),
      strategic_recommendations: [
        'Continue focus on code quality improvements',
        'Consider expanding backend team based on workload',
        'Implement automated testing across all departments',
      ],
      risks: [
        'Potential delay in Project Alpha due to resource constraints',
      ],
      opportunities: [
        'New technology stack could improve performance by 30%',
      ],
    };

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(report, null, 2),
        },
      ],
    };
  }

  /**
   * Coordinate departments
   */
  static async handleCoordinateDepartments(args: any) {
    const { project_id, coordinating_departments, coordination_type, requirements } = args;

    const ctoId = process.env.AGENT_ID || 'cto-001';

    // Find department heads
    const deptHeads = coordinating_departments.map((dept: string) => {
      const role = this.getDepartmentHeadRole(dept);
      const heads = agentRegistry.getAgentsByRole(role);
      return heads[0];
    }).filter(Boolean);

    // Send coordination message to all involved department heads
    for (const head of deptHeads) {
      messageBroker.sendMessage(
        MessageType.TASK_ASSIGNED,
        ctoId,
        head.id,
        {
          coordination_request: {
            project_id,
            coordination_type,
            requirements,
            coordinating_departments,
          },
        }
      );
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Coordination request sent to ${coordinating_departments.length} departments`,
            coordination: {
              project_id,
              coordination_type,
              departments: coordinating_departments,
              department_heads: deptHeads.map((h: any) => ({ id: h.id, name: h.name })),
            },
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Register department head
   */
  static async handleRegisterDepartmentHead(args: any) {
    const { name, department, role, skills = [], specialties = [], experience_level = 'senior' } = args;

    const ctoId = process.env.AGENT_ID || 'cto-001';

    const response = agentRegistry.registerAgent({
      name,
      role: role as AgentRole,
      department,
      parent_id: ctoId,
      metadata: {
        skills,
        specialties,
        experience_level,
      },
    });

    // Notify about new agent
    messageBroker.sendMessage(
      MessageType.AGENT_REGISTERED,
      ctoId,
      'system',
      { agent: response.agent }
    );

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Department head "${name}" registered successfully`,
            agent: response.agent,
            assigned_tools: response.assigned_tools,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Get agent hierarchy
   */
  static async handleGetAgentHierarchy(args: any) {
    const { include_inactive = false } = args;

    const hierarchy = agentRegistry.getHierarchyTree();

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            hierarchy,
            total_agents: agentRegistry.getAllAgents().length,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Broadcast message
   */
  static async handleBroadcastMessage(args: any) {
    const { message, target = 'all', departments = [], priority = 'medium' } = args;

    const ctoId = process.env.AGENT_ID || 'cto-001';

    let recipients: string[] = [];

    if (target === 'all') {
      recipients = agentRegistry.getAllAgents().map(a => a.id);
    } else if (target === 'managers') {
      recipients = agentRegistry.getAllAgents()
        .filter(a => a.level === AgentLevel.MANAGEMENT)
        .map(a => a.id);
    } else if (target === 'workers') {
      recipients = agentRegistry.getAllAgents()
        .filter(a => a.level === AgentLevel.WORKER)
        .map(a => a.id);
    }

    if (departments.length > 0) {
      recipients = recipients.filter(id => {
        const agent = agentRegistry.getAgent(id);
        return agent && departments.includes(agent.department);
      });
    }

    // Send broadcast
    for (const recipientId of recipients) {
      messageBroker.sendMessage(
        MessageType.TASK_ASSIGNED,
        ctoId,
        recipientId,
        { broadcast: { message, priority, from: 'CTO' } }
      );
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Broadcast sent to ${recipients.length} agents`,
            recipients_count: recipients.length,
            target,
            departments,
            priority,
          }, null, 2),
        },
      ],
    };
  }

  // Helper methods

  private static getDepartmentHeadRole(department: string): AgentRole {
    const roleMap: Record<string, AgentRole> = {
      frontend: AgentRole.FRONTEND_HEAD,
      backend: AgentRole.BACKEND_HEAD,
      devops: AgentRole.DEVOPS_HEAD,
      qa: AgentRole.QA_HEAD,
    };
    return roleMap[department] || AgentRole.FRONTEND_HEAD;
  }

  private static calculateAvgLoad(agents: any[]): number {
    if (agents.length === 0) return 0;
    const busyAgents = agents.filter(a => a.status === AgentStatus.BUSY).length;
    return Math.round((busyAgents / agents.length) * 100);
  }

  private static getDepartmentSummaries(): any[] {
    const departments = ['frontend', 'backend', 'devops', 'qa'];
    
    return departments.map(dept => {
      const agents = agentRegistry.getAgentsByDepartment(dept);
      const tasks = taskManager.getAllTasks().filter(t => {
        const project = taskManager.getProject(t.project_id);
        return project?.departments_involved.includes(dept);
      });

      return {
        department: dept,
        agent_count: agents.length,
        active_workers: agents.filter(a => a.status === AgentStatus.BUSY).length,
        total_tasks: tasks.length,
        completed_tasks: tasks.filter(t => t.status === TaskStatus.COMPLETED).length,
        in_progress_tasks: tasks.filter(t => t.status === TaskStatus.IN_PROGRESS).length,
      };
    });
  }
}
