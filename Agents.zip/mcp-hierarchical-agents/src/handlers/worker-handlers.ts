/**
 * Worker Tool Handlers
 * Implements all Worker-level tool functionality
 */

import { agentRegistry } from '../services/agent-registry.js';
import { taskManager } from '../services/task-manager.js';
import { messageBroker } from '../services/message-broker.js';
import { AgentStatus } from '../schemas/agent-registry.js';
import { TaskStatus } from '../schemas/task-structure.js';
import { MessageType } from '../schemas/messages.js';

export class WorkerHandlers {
  /**
   * Accept task
   */
  static async handleAcceptTask(args: any) {
    const { task_id, estimated_completion, initial_plan } = args;

    const workerId = process.env.AGENT_ID || 'worker-001';

    const task = taskManager.getTask(task_id);
    if (!task) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not found' }, null, 2) }],
        isError: true,
      };
    }

    if (task.assigned_to !== workerId) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not assigned to you' }, null, 2) }],
        isError: true,
      };
    }

    // Update task
    taskManager.updateTask(task_id, {
      status: TaskStatus.IN_PROGRESS,
      progress_percentage: 0,
    });

    // Update worker status
    agentRegistry.updateAgentStatus(workerId, AgentStatus.BUSY);

    // Notify manager
    const worker = agentRegistry.getAgent(workerId);
    if (worker?.parent_id) {
      messageBroker.createTaskUpdatedMessage(
        workerId,
        worker.parent_id,
        task_id,
        'status',
        {
          status: TaskStatus.IN_PROGRESS,
          message: `Task accepted by ${worker.name}. ${initial_plan || ''}`,
        }
      );
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: 'Task accepted and work started',
            task: {
              id: task_id,
              title: task.title,
              status: TaskStatus.IN_PROGRESS,
              estimated_completion,
            },
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Write code
   */
  static async handleWriteCode(args: any) {
    const { task_id, files, commit_message } = args;

    const workerId = process.env.AGENT_ID || 'worker-001';

    const task = taskManager.getTask(task_id);
    if (!task) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not found' }, null, 2) }],
        isError: true,
      };
    }

    // Add code changes to task
    const codeChanges = files.map((file: any) => ({
      file_path: file.path,
      change_type: file.action,
      content: file.content,
      language: file.language || this.detectLanguage(file.path),
    }));

    taskManager.addCodeChanges(task_id, codeChanges);

    // Update progress
    taskManager.updateTask(task_id, {
      progress_percentage: Math.min(task.progress_percentage + 20, 90),
      notes: [`Code changes: ${files.map((f: any) => f.path).join(', ')}`],
    });

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Code written to ${files.length} file(s)`,
            files: files.map((f: any) => ({
              path: f.path,
              action: f.action,
              language: f.language || this.detectLanguage(f.path),
            })),
            commit_message,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Run tests
   */
  static async handleRunTests(args: any) {
    const { task_id, test_type = 'all', files_to_test } = args;

    const workerId = process.env.AGENT_ID || 'worker-001';

    const task = taskManager.getTask(task_id);
    if (!task) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not found' }, null, 2) }],
        isError: true,
      };
    }

    // Simulate test execution
    const testResults = {
      test_type,
      total_tests: Math.floor(Math.random() * 50) + 10,
      passed: 0,
      failed: 0,
      skipped: 0,
      coverage: Math.floor(Math.random() * 30) + 70, // 70-100%
    };

    testResults.passed = Math.floor(testResults.total_tests * 0.9);
    testResults.failed = testResults.total_tests - testResults.passed;

    const allPassed = testResults.failed === 0;

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: allPassed,
            message: allPassed ? 'All tests passed!' : `${testResults.failed} test(s) failed`,
            results: testResults,
          }, null, 2),
        },
      ],
      isError: !allPassed,
    };
  }

  /**
   * Update task progress
   */
  static async handleUpdateTaskProgress(args: any) {
    const { task_id, progress_percentage, status, message, blockers } = args;

    const workerId = process.env.AGENT_ID || 'worker-001';

    const task = taskManager.getTask(task_id);
    if (!task) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not found' }, null, 2) }],
        isError: true,
      };
    }

    // Update task
    const update: any = { progress_percentage };
    if (status) update.status = status;
    if (message) update.notes = [message];
    if (blockers) update.blockers = blockers;

    const updatedTask = taskManager.updateTask(task_id, update);

    // Notify manager
    const worker = agentRegistry.getAgent(workerId);
    if (worker?.parent_id) {
      messageBroker.createTaskUpdatedMessage(
        workerId,
        worker.parent_id,
        task_id,
        blockers ? 'blocker' : 'progress',
        {
          progress_percentage,
          status,
          message,
          blockers,
        }
      );
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: 'Task progress updated',
            task: {
              id: task_id,
              title: task.title,
              progress_percentage,
              status: updatedTask?.status,
            },
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Submit for review
   */
  static async handleSubmitForReview(args: any) {
    const { task_id, summary, files_changed, testing_done, notes_for_reviewer } = args;

    const workerId = process.env.AGENT_ID || 'worker-001';

    const task = taskManager.getTask(task_id);
    if (!task) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not found' }, null, 2) }],
        isError: true,
      };
    }

    // Update task status
    taskManager.updateTask(task_id, {
      status: TaskStatus.IN_REVIEW,
      progress_percentage: 100,
    });

    // Notify manager
    const worker = agentRegistry.getAgent(workerId);
    if (worker?.parent_id) {
      messageBroker.createCodeSubmittedMessage(
        workerId,
        worker.parent_id,
        task_id,
        files_changed,
        summary,
        testing_done || 'Tests not specified'
      );
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: 'Task submitted for review',
            submission: {
              task_id,
              summary,
              files_changed,
              testing_done,
              notes_for_reviewer,
              submitted_at: new Date().toISOString(),
            },
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Request help
   */
  static async handleRequestHelp(args: any) {
    const { task_id, help_type, description, urgency = 'medium' } = args;

    const workerId = process.env.AGENT_ID || 'worker-001';

    const worker = agentRegistry.getAgent(workerId);
    if (!worker?.parent_id) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Manager not found' }, null, 2) }],
        isError: true,
      };
    }

    // Send help request to manager
    messageBroker.sendMessage(
      MessageType.TASK_UPDATED,
      workerId,
      worker.parent_id,
      {
        help_request: {
          task_id,
          help_type,
          description,
          urgency,
          requested_at: new Date().toISOString(),
        },
      }
    );

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Help request sent to manager (${urgency} priority)`,
            request: {
              task_id,
              help_type,
              description,
              urgency,
            },
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Research solution
   */
  static async handleResearchSolution(args: any) {
    const { topic, context, constraints = [] } = args;

    // Simulate research
    const research = {
      topic,
      findings: [
        `Best practice for ${topic}: Use established patterns`,
        `Recommended approach: Incremental implementation`,
        `Common pitfalls to avoid: Over-engineering`,
      ],
      resources: [
        'https://docs.example.com/best-practices',
        'https://github.com/example/patterns',
      ],
      recommendations: [
        `Start with a simple implementation of ${topic}`,
        `Add complexity only when needed`,
        `Write tests early in the process`,
      ],
      constraints_considered: constraints,
    };

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            research,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Document code
   */
  static async handleDocumentCode(args: any) {
    const { task_id, files, documentation_type = 'all' } = args;

    const workerId = process.env.AGENT_ID || 'worker-001';

    const task = taskManager.getTask(task_id);
    if (!task) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not found' }, null, 2) }],
        isError: true,
      };
    }

    // Simulate documentation generation
    const documentation = files.map((file: string) => ({
      file,
      documentation_added: {
        inline_comments: documentation_type === 'all' || documentation_type === 'inline',
        function_docs: documentation_type === 'all' || documentation_type === 'api_docs',
        readme_updated: documentation_type === 'all' || documentation_type === 'readme',
      },
    }));

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Documentation added to ${files.length} file(s)`,
            documentation,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Get task details
   */
  static async handleGetTaskDetails(args: any) {
    const { task_id, include_history = true } = args;

    const workerId = process.env.AGENT_ID || 'worker-001';

    const task = taskManager.getTask(task_id);
    if (!task) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not found' }, null, 2) }],
        isError: true,
      };
    }

    const project = taskManager.getProject(task.project_id);

    let history = [];
    if (include_history) {
      history = messageBroker.getMessageHistory({
        senderId: workerId,
      }).filter(m => 
        (m as any).task_id === task_id || 
        m.type === MessageType.TASK_ASSIGNED
      );
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            task: {
              id: task.id,
              title: task.title,
              description: task.requirements.description,
              type: task.type,
              priority: task.priority,
              status: task.status,
              progress: task.progress_percentage,
              deadline: task.deadline,
              acceptance_criteria: task.requirements.acceptance_criteria,
              code_changes: task.code_changes.map(c => ({
                file: c.file_path,
                type: c.change_type,
              })),
            },
            project: project ? {
              id: project.id,
              name: project.name,
            } : null,
            history: include_history ? history : undefined,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * List available tasks
   */
  static async handleListAvailableTasks(args: any) {
    const { priority_filter, task_type_filter } = args;

    const workerId = process.env.AGENT_ID || 'worker-001';
    const worker = agentRegistry.getAgent(workerId);

    if (!worker) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Worker not found' }, null, 2) }],
        isError: true,
      };
    }

    let availableTasks = taskManager.getAvailableTasks(worker.department);

    if (priority_filter) {
      availableTasks = availableTasks.filter(t => priority_filter.includes(t.priority));
    }

    if (task_type_filter) {
      availableTasks = availableTasks.filter(t => task_type_filter.includes(t.type));
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            department: worker.department,
            available_tasks_count: availableTasks.length,
            tasks: availableTasks.map(t => ({
              id: t.id,
              title: t.title,
              type: t.type,
              priority: t.priority,
              estimated_hours: t.requirements.estimated_effort_hours,
            })),
          }, null, 2),
        },
      ],
    };
  }

  // Helper methods

  private static detectLanguage(filePath: string): string {
    const ext = filePath.split('.').pop()?.toLowerCase();
    const languageMap: Record<string, string> = {
      ts: 'typescript',
      tsx: 'typescript',
      js: 'javascript',
      jsx: 'javascript',
      py: 'python',
      java: 'java',
      go: 'go',
      rs: 'rust',
      cpp: 'cpp',
      c: 'c',
      h: 'c',
      cs: 'csharp',
      rb: 'ruby',
      php: 'php',
      swift: 'swift',
      kt: 'kotlin',
      scala: 'scala',
      html: 'html',
      css: 'css',
      scss: 'scss',
      json: 'json',
      yaml: 'yaml',
      yml: 'yaml',
      md: 'markdown',
      sql: 'sql',
      sh: 'bash',
    };
    return languageMap[ext || ''] || 'unknown';
  }
}
