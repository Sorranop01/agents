/**
 * Manager Tool Handlers
 * Implements all Manager-level tool functionality
 */

import { agentRegistry } from '../services/agent-registry.js';
import { taskManager } from '../services/task-manager.js';
import { messageBroker } from '../services/message-broker.js';
import { AgentRole, AgentStatus } from '../schemas/agent-registry.js';
import { TaskPriority, TaskType, TaskStatus } from '../schemas/task-structure.js';
import { MessageType } from '../schemas/messages.js';

export class ManagerHandlers {
  /**
   * Delegate task to worker
   */
  static async handleDelegateTask(args: any) {
    const { parent_task_id, worker_id, title, description, task_type = 'feature', priority = 'medium', estimated_hours, technical_specs } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';

    // Verify worker exists and is in same department
    const worker = agentRegistry.getAgent(worker_id);
    const manager = agentRegistry.getAgent(managerId);

    if (!worker) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Worker not found' }, null, 2) }],
        isError: true,
      };
    }

    if (!manager) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Manager not found' }, null, 2) }],
        isError: true,
      };
    }

    if (worker.department !== manager.department) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Worker is not in your department' }, null, 2) }],
        isError: true,
      };
    }

    // Get parent task
    const parentTask = taskManager.getTask(parent_task_id);
    if (!parentTask) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Parent task not found' }, null, 2) }],
        isError: true,
      };
    }

    // Create subtask
    const task = taskManager.createTask(
      {
        project_id: parentTask.project_id,
        parent_task_id,
        title,
        type: task_type as TaskType,
        priority: priority as TaskPriority,
        requirements: {
          description,
          acceptance_criteria: [],
          technical_requirements: technical_specs ? [technical_specs] : [],
          estimated_effort_hours: estimated_hours,
        },
        assigned_to: worker_id,
      },
      managerId
    );

    // Update worker status
    agentRegistry.updateAgentStatus(worker_id, AgentStatus.BUSY);

    // Send message to worker
    messageBroker.createTaskAssignedMessage(
      managerId,
      worker_id,
      task.id,
      {
        title: task.title,
        description: task.requirements.description,
        priority: task.priority,
      },
      technical_specs
    );

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Task delegated to worker "${worker.name}"`,
            task: {
              id: task.id,
              title: task.title,
              assigned_to: {
                id: worker.id,
                name: worker.name,
              },
              priority: task.priority,
              parent_task_id,
            },
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Create subtasks
   */
  static async handleCreateSubtask(args: any) {
    const { parent_task_id, subtasks } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';

    const parentTask = taskManager.getTask(parent_task_id);
    if (!parentTask) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Parent task not found' }, null, 2) }],
        isError: true,
      };
    }

    const createdSubtasks = [];

    for (const subtask of subtasks) {
      const task = taskManager.createTask(
        {
          project_id: parentTask.project_id,
          parent_task_id,
          title: subtask.title,
          type: TaskType.FEATURE,
          priority: TaskPriority.MEDIUM,
          requirements: {
            description: subtask.description,
            acceptance_criteria: [],
            estimated_effort_hours: subtask.estimated_hours,
          },
          assigned_to: subtask.assigned_to,
        },
        managerId
      );

      createdSubtasks.push({
        id: task.id,
        title: task.title,
        assigned_to: subtask.assigned_to,
      });

      // Notify worker if assigned
      if (subtask.assigned_to) {
        messageBroker.createTaskAssignedMessage(
          managerId,
          subtask.assigned_to,
          task.id,
          {
            title: task.title,
            description: task.requirements.description,
            priority: task.priority,
          }
        );
      }
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `${createdSubtasks.length} subtasks created`,
            subtasks: createdSubtasks,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Review worker code
   */
  static async handleReviewWorkerCode(args: any) {
    const { task_id, worker_id, files, review_criteria = ['code_quality'] } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';

    const task = taskManager.getTask(task_id);
    if (!task) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not found' }, null, 2) }],
        isError: true,
      };
    }

    // Simulate code review
    const findings = [];
    let approvalStatus: 'approved' | 'changes_requested' | 'rejected' = 'approved';

    // Check for common issues (simulated)
    for (const file of files) {
      if (file.endsWith('.ts') || file.endsWith('.js')) {
        // Simulate finding
        if (Math.random() > 0.7) {
          findings.push({
            severity: 'minor',
            file_path: file,
            line_number: Math.floor(Math.random() * 100) + 1,
            message: 'Consider adding type annotations for better code clarity',
            suggestion: 'Add explicit types to function parameters',
          });
          approvalStatus = 'changes_requested';
        }
      }
    }

    // Create review report
    const reviewReport = {
      id: `review-${Date.now()}`,
      task_id,
      reviewer_id: managerId,
      files_reviewed: files,
      findings,
      approval_status: approvalStatus,
      overall_feedback: findings.length === 0 
        ? 'Code looks good! Approved for merge.' 
        : `Found ${findings.length} issue(s). Please address before merging.`,
      created_at: new Date().toISOString(),
    };

    // Send review message to worker
    messageBroker.createCodeReviewedMessage(
      managerId,
      worker_id,
      task_id,
      approvalStatus,
      findings,
      reviewReport.overall_feedback
    );

    // Update task status
    if (approvalStatus === 'approved') {
      taskManager.updateTask(task_id, { status: TaskStatus.COMPLETED });
      agentRegistry.updateAgentStatus(worker_id, AgentStatus.IDLE);
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            review: reviewReport,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Get department status
   */
  static async handleGetDepartmentStatus(args: any) {
    const { include_worker_details = true, include_task_details = true, status_filter } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';
    const manager = agentRegistry.getAgent(managerId);

    if (!manager) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Manager not found' }, null, 2) }],
        isError: true,
      };
    }

    const department = manager.department;
    const workers = agentRegistry.getAgentsByDepartment(department)
      .filter(a => a.level === 2); // Workers only

    const deptTasks = taskManager.getAllTasks().filter(t => {
      const project = taskManager.getProject(t.project_id);
      return project?.departments_involved.includes(department);
    });

    if (status_filter) {
      // Filter tasks by status
    }

    const status = {
      department,
      manager: {
        id: manager.id,
        name: manager.name,
      },
      workers: include_worker_details ? workers.map(w => ({
        id: w.id,
        name: w.name,
        status: w.status,
        current_tasks: taskManager.getTasksByAssignee(w.id)
          .filter(t => t.status === TaskStatus.IN_PROGRESS)
          .map(t => ({ id: t.id, title: t.title, progress: t.progress_percentage })),
      })) : workers.length,
      tasks: include_task_details ? {
        total: deptTasks.length,
        by_status: {
          pending: deptTasks.filter(t => t.status === TaskStatus.PENDING).length,
          assigned: deptTasks.filter(t => t.status === TaskStatus.ASSIGNED).length,
          in_progress: deptTasks.filter(t => t.status === TaskStatus.IN_PROGRESS).length,
          in_review: deptTasks.filter(t => t.status === TaskStatus.IN_REVIEW).length,
          completed: deptTasks.filter(t => t.status === TaskStatus.COMPLETED).length,
          blocked: deptTasks.filter(t => t.status === TaskStatus.BLOCKED).length,
        },
        active: deptTasks
          .filter(t => t.status === TaskStatus.IN_PROGRESS)
          .map(t => ({
            id: t.id,
            title: t.title,
            assigned_to: t.assigned_to,
            progress: t.progress_percentage,
          })),
      } : { total: deptTasks.length },
    };

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(status, null, 2),
        },
      ],
    };
  }

  /**
   * Register worker
   */
  static async handleRegisterWorker(args: any) {
    const { name, role, skills = [], specialties = [], experience_level = 'mid', max_concurrent_tasks = 3 } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';
    const manager = agentRegistry.getAgent(managerId);

    if (!manager) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Manager not found' }, null, 2) }],
        isError: true,
      };
    }

    const response = agentRegistry.registerAgent({
      name,
      role: role as AgentRole,
      department: manager.department,
      parent_id: managerId,
      metadata: {
        skills,
        specialties,
        experience_level,
        max_concurrent_tasks,
      },
    });

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Worker "${name}" registered in ${manager.department} department`,
            agent: response.agent,
            assigned_tools: response.assigned_tools,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Submit department report
   */
  static async handleSubmitDepartmentReport(args: any) {
    const { period_start, period_end, summary, accomplishments = [], challenges = [], issues = [], recommendations = [] } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';
    const manager = agentRegistry.getAgent(managerId);

    if (!manager) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Manager not found' }, null, 2) }],
        isError: true,
      };
    }

    const department = manager.department;
    const workers = agentRegistry.getAgentsByDepartment(department)
      .filter(a => a.level === 2);

    const deptTasks = taskManager.getAllTasks().filter(t => {
      const project = taskManager.getProject(t.project_id);
      return project?.departments_involved.includes(department);
    });

    const report = {
      id: `dept-report-${Date.now()}`,
      department,
      head_id: managerId,
      period_start,
      period_end,
      summary,
      accomplishments,
      challenges,
      issues,
      recommendations,
      metrics: {
        total_workers: workers.length,
        active_workers: workers.filter(w => w.status === AgentStatus.BUSY).length,
        total_tasks: deptTasks.length,
        completed_tasks: deptTasks.filter(t => t.status === TaskStatus.COMPLETED).length,
      },
      submitted_at: new Date().toISOString(),
    };

    // Send report to CTO
    const cto = agentRegistry.getAgentsByRole(AgentRole.CTO)[0];
    if (cto) {
      messageBroker.sendMessage(
        MessageType.DEPARTMENT_REPORT,
        managerId,
        cto.id,
        { report }
      );
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: 'Department report submitted to CTO',
            report,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Request architecture review
   */
  static async handleRequestArchitectureReview(args: any) {
    const { project_id, proposal_title, proposal_description, technical_details, alternatives_considered = [], recommendation } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';

    const cto = agentRegistry.getAgentsByRole(AgentRole.CTO)[0];
    if (!cto) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'CTO not found' }, null, 2) }],
        isError: true,
      };
    }

    const proposal = {
      project_id,
      proposal_title,
      proposal_description,
      technical_details,
      alternatives_considered,
      recommendation,
      requested_by: managerId,
      requested_at: new Date().toISOString(),
    };

    // Send to CTO
    messageBroker.sendMessage(
      MessageType.TASK_ASSIGNED,
      managerId,
      cto.id,
      { architecture_review_request: proposal }
    );

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: 'Architecture review requested from CTO',
            proposal,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Escalate issue
   */
  static async handleEscalateIssue(args: any) {
    const { issue_type, description, impact, suggested_resolution, task_id } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';

    const cto = agentRegistry.getAgentsByRole(AgentRole.CTO)[0];
    if (!cto) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'CTO not found' }, null, 2) }],
        isError: true,
      };
    }

    const issue = {
      issue_type,
      description,
      impact,
      suggested_resolution,
      task_id,
      escalated_by: managerId,
      escalated_at: new Date().toISOString(),
    };

    // Send to CTO
    messageBroker.createErrorMessage(
      managerId,
      cto.id,
      `ESCALATION_${issue_type.toUpperCase()}`,
      description,
      issue
    );

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: 'Issue escalated to CTO',
            issue,
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Reassign task
   */
  static async handleReassignTask(args: any) {
    const { task_id, new_worker_id, reason } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';

    const task = taskManager.getTask(task_id);
    if (!task) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Task not found' }, null, 2) }],
        isError: true,
      };
    }

    const oldWorkerId = task.assigned_to;

    // Reassign task
    taskManager.assignTask(task_id, new_worker_id, managerId);

    // Update worker statuses
    if (oldWorkerId) {
      agentRegistry.updateAgentStatus(oldWorkerId, AgentStatus.IDLE);
    }
    agentRegistry.updateAgentStatus(new_worker_id, AgentStatus.BUSY);

    // Notify new worker
    messageBroker.createTaskAssignedMessage(
      managerId,
      new_worker_id,
      task_id,
      {
        title: task.title,
        description: `Reassigned task: ${reason || 'No reason provided'}`,
        priority: task.priority,
      }
    );

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: 'Task reassigned successfully',
            task: {
              id: task_id,
              title: task.title,
              previously_assigned_to: oldWorkerId,
              now_assigned_to: new_worker_id,
              reason,
            },
          }, null, 2),
        },
      ],
    };
  }

  /**
   * Get worker workload
   */
  static async handleGetWorkerWorkload(args: any) {
    const { worker_id } = args;

    const managerId = process.env.AGENT_ID || 'manager-001';
    const manager = agentRegistry.getAgent(managerId);

    if (!manager) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'Manager not found' }, null, 2) }],
        isError: true,
      };
    }

    let workers: any[] = [];

    if (worker_id) {
      const worker = agentRegistry.getAgent(worker_id);
      if (worker) workers.push(worker);
    } else {
      workers = agentRegistry.getAgentsByDepartment(manager.department)
        .filter(a => a.level === 2);
    }

    const workloads = workers.map(w => {
      const tasks = taskManager.getTasksByAssignee(w.id);
      return {
        worker: {
          id: w.id,
          name: w.name,
          status: w.status,
          max_concurrent_tasks: w.metadata.max_concurrent_tasks,
        },
        workload: {
          total_tasks: tasks.length,
          in_progress: tasks.filter(t => t.status === TaskStatus.IN_PROGRESS).length,
          in_review: tasks.filter(t => t.status === TaskStatus.IN_REVIEW).length,
          completed: tasks.filter(t => t.status === TaskStatus.COMPLETED).length,
          current_load_percentage: Math.round(
            (tasks.filter(t => t.status === TaskStatus.IN_PROGRESS).length / 
             w.metadata.max_concurrent_tasks) * 100
          ),
        },
        active_tasks: tasks
          .filter(t => t.status === TaskStatus.IN_PROGRESS)
          .map(t => ({
            id: t.id,
            title: t.title,
            progress: t.progress_percentage,
          })),
      };
    });

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            department: manager.department,
            workloads,
          }, null, 2),
        },
      ],
    };
  }
}
