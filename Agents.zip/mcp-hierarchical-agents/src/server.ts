#!/usr/bin/env node
/**
 * MCP Hierarchical Agents Server
 * Main entry point for the MCP server
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  ErrorCode,
  McpError,
} from '@modelcontextprotocol/sdk/types.js';

import { AgentRole, ROLE_LEVEL_MAP } from './schemas/agent-registry.js';
import { CTO_TOOLS } from './tools/cto-tools.js';
import { MANAGER_TOOLS } from './tools/manager-tools.js';
import { WORKER_TOOLS } from './tools/worker-tools.js';
import { CTOHandlers } from './handlers/cto-handlers.js';
import { ManagerHandlers } from './handlers/manager-handlers.js';
import { WorkerHandlers } from './handlers/worker-handlers.js';
import { agentRegistry } from './services/agent-registry.js';
import { messageBroker } from './services/message-broker.js';

/**
 * Get agent role from environment
 */
function getAgentRole(): AgentRole {
  const role = process.env.AGENT_ROLE || 'cto';
  return Object.values(AgentRole).includes(role as AgentRole) 
    ? (role as AgentRole) 
    : AgentRole.CTO;
}

/**
 * Get tools for current agent role
 */
function getToolsForRole(role: AgentRole) {
  const level = ROLE_LEVEL_MAP[role];
  
  switch (level) {
    case 0: // CTO
      return CTO_TOOLS;
    case 1: // Manager
      return MANAGER_TOOLS;
    case 2: // Worker
      return WORKER_TOOLS;
    default:
      return [];
  }
}

/**
 * Get tool handler map for current role
 */
function getToolHandlers(role: AgentRole): Record<string, (args: any) => Promise<any>> {
  const level = ROLE_LEVEL_MAP[role];
  
  switch (level) {
    case 0: // CTO
      return {
        create_project: CTOHandlers.handleCreateProject,
        assign_department_task: CTOHandlers.handleAssignDepartmentTask,
        review_architecture: CTOHandlers.handleReviewArchitecture,
        get_organization_status: CTOHandlers.handleGetOrganizationStatus,
        generate_executive_report: CTOHandlers.handleGenerateExecutiveReport,
        coordinate_departments: CTOHandlers.handleCoordinateDepartments,
        register_department_head: CTOHandlers.handleRegisterDepartmentHead,
        get_agent_hierarchy: CTOHandlers.handleGetAgentHierarchy,
        broadcast_message: CTOHandlers.handleBroadcastMessage,
      };
    case 1: // Manager
      return {
        delegate_task: ManagerHandlers.handleDelegateTask,
        create_subtask: ManagerHandlers.handleCreateSubtask,
        review_worker_code: ManagerHandlers.handleReviewWorkerCode,
        get_department_status: ManagerHandlers.handleGetDepartmentStatus,
        register_worker: ManagerHandlers.handleRegisterWorker,
        submit_department_report: ManagerHandlers.handleSubmitDepartmentReport,
        request_architecture_review: ManagerHandlers.handleRequestArchitectureReview,
        escalate_issue: ManagerHandlers.handleEscalateIssue,
        reassign_task: ManagerHandlers.handleReassignTask,
        get_worker_workload: ManagerHandlers.handleGetWorkerWorkload,
      };
    case 2: // Worker
      return {
        accept_task: WorkerHandlers.handleAcceptTask,
        write_code: WorkerHandlers.handleWriteCode,
        run_tests: WorkerHandlers.handleRunTests,
        update_task_progress: WorkerHandlers.handleUpdateTaskProgress,
        submit_for_review: WorkerHandlers.handleSubmitForReview,
        request_help: WorkerHandlers.handleRequestHelp,
        research_solution: WorkerHandlers.handleResearchSolution,
        document_code: WorkerHandlers.handleDocumentCode,
        get_task_details: WorkerHandlers.handleGetTaskDetails,
        list_available_tasks: WorkerHandlers.handleListAvailableTasks,
      };
    default:
      return {};
  }
}

/**
 * Create and configure MCP Server
 */
async function main() {
  const agentRole = getAgentRole();
  const agentId = process.env.AGENT_ID || `${agentRole}-${Date.now()}`;
  const agentName = process.env.AGENT_NAME || `${agentRole} Agent`;
  
  console.error(`Starting MCP Hierarchical Agents Server...`);
  console.error(`Role: ${agentRole}`);
  console.error(`Agent ID: ${agentId}`);
  console.error(`Agent Name: ${agentName}`);

  // Register this agent if not already registered
  const existingAgent = agentRegistry.getAgent(agentId);
  if (!existingAgent) {
    const parentId = process.env.PARENT_AGENT_ID;
    agentRegistry.registerAgent({
      name: agentName,
      role: agentRole,
      department: agentRole.includes('frontend') ? 'frontend' : 
                   agentRole.includes('backend') ? 'backend' :
                   agentRole.includes('devops') ? 'devops' :
                   agentRole.includes('qa') ? 'qa' : 'executive',
      parent_id: parentId || '',
      metadata: {
        skills: [],
        specialties: [],
      },
    });
    console.error(`Agent registered: ${agentId}`);
  }

  // Get tools and handlers for this role
  const tools = getToolsForRole(agentRole);
  const toolHandlers = getToolHandlers(agentRole);

  // Create MCP Server
  const server = new Server(
    {
      name: 'mcp-hierarchical-agents',
      version: '1.0.0',
    },
    {
      capabilities: {
        tools: {},
        resources: {},
      },
    }
  );

  // List Tools Handler
  server.setRequestHandler(ListToolsRequestSchema, async () => {
    return {
      tools,
    };
  });

  // Call Tool Handler
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;

    console.error(`Tool called: ${name}`);

    const handler = toolHandlers[name];
    if (!handler) {
      throw new McpError(
        ErrorCode.MethodNotFound,
        `Tool not found: ${name}`
      );
    }

    try {
      const result = await handler(args || {});
      return result;
    } catch (error) {
      console.error(`Error executing tool ${name}:`, error);
      throw new McpError(
        ErrorCode.InternalError,
        `Error executing tool ${name}: ${error instanceof Error ? error.message : String(error)}`
      );
    }
  });

  // List Resources Handler
  server.setRequestHandler(ListResourcesRequestSchema, async () => {
    const resources = [
      {
        uri: 'agents://registry',
        name: 'Agent Registry',
        mimeType: 'application/json',
        description: 'Registry of all agents in the organization',
      },
      {
        uri: 'tasks://all',
        name: 'All Tasks',
        mimeType: 'application/json',
        description: 'List of all tasks in the system',
      },
      {
        uri: 'projects://all',
        name: 'All Projects',
        mimeType: 'application/json',
        description: 'List of all projects',
      },
    ];

    return { resources };
  });

  // Read Resource Handler
  server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
    const { uri } = request.params;

    if (uri === 'agents://registry') {
      const agents = agentRegistry.getAllAgents();
      return {
        contents: [
          {
            uri,
            mimeType: 'application/json',
            text: JSON.stringify(agents, null, 2),
          },
        ],
      };
    }

    if (uri === 'tasks://all') {
      const { taskManager } = await import('./services/task-manager.js');
      const tasks = taskManager.getAllTasks();
      return {
        contents: [
          {
            uri,
            mimeType: 'application/json',
            text: JSON.stringify(tasks, null, 2),
          },
        ],
      };
    }

    if (uri === 'projects://all') {
      const { taskManager } = await import('./services/task-manager.js');
      const projects = taskManager.getAllProjects();
      return {
        contents: [
          {
            uri,
            mimeType: 'application/json',
            text: JSON.stringify(projects, null, 2),
          },
        ],
      };
    }

    throw new McpError(
      ErrorCode.InvalidRequest,
      `Resource not found: ${uri}`
    );
  });

  // Start heartbeat
  startHeartbeat(agentId);

  // Create stdio transport
  const transport = new StdioServerTransport();

  // Connect server to transport
  await server.connect(transport);

  console.error('MCP Hierarchical Agents Server running on stdio');
}

/**
 * Start heartbeat for this agent
 */
function startHeartbeat(agentId: string) {
  setInterval(() => {
    agentRegistry.updateHeartbeat(agentId);
    
    // Send heartbeat message
    const agent = agentRegistry.getAgent(agentId);
    if (agent) {
      messageBroker.createHeartbeatMessage(
        agentId,
        agent.status,
        agent.status === 'busy' ? 80 : 20
      );
    }
  }, 30000); // Every 30 seconds
}

// Run main
main().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});
