# Memory & Knowledge Management System
## ระบบความจำและความรู้สำหรับ MCP Hierarchical Agents

---

## 1. ภาพรวมระบบ (System Overview)

### 1.1 วัตถุประสงค์

ออกแบบระบบความจำและความรู้ที่ช่วยให้ AI Agents สามารถ:
- จดจำประสบการณ์และบทเรียนจากงานที่ผ่านมา
- สะสมความรู้เฉพาะทางและ best practices
- แบ่งปันความรู้ระหว่าง Agents ในระบบ
- เรียนรู้และปรับปรุงประสิทธิภาพตนเอง

### 1.2 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MEMORY & KNOWLEDGE SYSTEM                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    Agent Memory Layer                                │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   Working    │  │   Short-term │  │   Long-term  │              │   │
│  │  │   Memory     │  │   Memory     │  │   Memory     │              │   │
│  │  │  (Context)   │  │  (Session)   │  │  (Persistent)│              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                   Knowledge Management Layer                         │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   Semantic   │  │   Episodic   │  │  Procedural  │              │   │
│  │  │  Knowledge   │  │  Memory      │  │  Knowledge   │              │   │
│  │  │  (Facts)     │  │  (Events)    │  │  (Skills)    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    Shared Knowledge Base                             │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │  Knowledge   │  │   Agent      │  │   Best       │              │   │
│  │  │   Graph      │  │   Profiles   │  │  Practices   │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Memory Hierarchy

### 2.1 Three-Layer Memory Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      MEMORY HIERARCHY                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  L1: WORKING MEMORY (Active Context)                                 │   │
│  │  ═══════════════════════════════════                                 │   │
│  │  • Capacity: ~4-7 items (Miller's Law)                               │   │
│  │  • Duration: Active task duration                                    │   │
│  │  • Content: Current task, variables, immediate context               │   │
│  │  • Access: Instant (< 10ms)                                          │   │
│  │                                                                      │   │
│  │  Structure:                                                          │   │
│  │  {                                                                   │   │
│  │    "current_task": "Implement login API",                            │   │
│  │    "variables": { "user_id": "123", "token": "abc..." },             │   │
│  │    "context_stack": ["auth-flow", "user-session"],                   │   │
│  │    "focus": "password-validation"                                    │   │
│  │  }                                                                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  L2: SHORT-TERM MEMORY (Session Context)                             │   │
│  │  ═══════════════════════════════════════                             │   │
│  │  • Capacity: ~20-30 items                                            │   │
│  │  • Duration: Session lifetime (minutes to hours)                     │   │
│  │  • Content: Recent tasks, decisions, intermediate results            │   │
│  │  • Access: Fast (< 100ms)                                            │   │
│  │                                                                      │   │
│  │  Structure:                                                          │   │
│  │  {                                                                   │   │
│  │    "session_id": "sess-2024-001",                                    │   │
│  │    "recent_tasks": ["task-1", "task-2", "task-3"],                   │   │
│  │    "decisions": [{"id": "dec-1", "context": "...", "outcome": "..."}],│   │
│  │    "intermediate_results": { ... },                                  │   │
│  │    "conversation_history": [...]                                     │   │
│  │  }                                                                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  L3: LONG-TERM MEMORY (Persistent Knowledge)                         │   │
│  │  ═══════════════════════════════════════════                         │   │
│  │  • Capacity: Virtually unlimited                                     │   │
│  │  • Duration: Permanent (with updates)                                │   │
│  │  • Content: Learned patterns, best practices, domain knowledge       │   │
│  │  • Access: Moderate (< 500ms with indexing)                          │   │
│  │                                                                      │   │
│  │  Structure:                                                          │   │
│  │  {                                                                   │   │
│  │    "learned_patterns": [...],                                        │   │
│  │    "best_practices": {...},                                          │   │
│  │    "domain_knowledge": {...},                                        │   │
│  │    "performance_history": [...],                                     │   │
│  │    "successful_solutions": [...]                                     │   │
│  │  }                                                                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Memory Management Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MEMORY MANAGEMENT FLOW                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   Input → Working Memory → Processing → Short-term → Consolidation → Long  │
│                                                                              │
│   ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐  │
│   │  Input  │───▶│ Working │───▶│ Process │───▶│  Short  │───▶│  Long   │  │
│   │         │    │ Memory  │    │         │    │  Term   │    │  Term   │  │
│   └─────────┘    └─────────┘    └─────────┘    └─────────┘    └─────────┘  │
│                       │                            │               │        │
│                       │                            │               │        │
│                       ▼                            ▼               ▼        │
│                  ┌─────────┐                 ┌─────────┐     ┌─────────┐   │
│                  │ Discard │                 │  Cache  │     │  Index  │   │
│                  │ (Low    │                 │  (LRU)  │     │  (Search│   │
│                  │ priority)│                │         │     │  ready) │   │
│                  └─────────┘                 └─────────┘     └─────────┘   │
│                                                                              │
│   Consolidation Rules:                                                       │
│   • High importance → Immediate to Long-term                                 │
│   • Repeated access → Promote to Long-term                                   │
│   • Pattern detected → Extract to Knowledge Base                             │
│   • Unused > 24h → Archive or Discard                                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Knowledge Representation

### 3.1 Three Types of Knowledge

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                   KNOWLEDGE REPRESENTATION                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  SEMANTIC KNOWLEDGE (Facts & Concepts)                               │   │
│  │  ═════════════════════════════════════                               │   │
│  │                                                                      │   │
│  │  Knowledge Graph Structure:                                          │   │
│  │                                                                      │   │
│  │       ┌──────────┐         ┌──────────┐                              │   │
│  │       │  React   │────────▶│ Component│                              │   │
│  │       │  (lib)   │         │ (concept)│                              │   │
│  │       └────┬─────┘         └────┬─────┘                              │   │
│  │            │                    │                                    │   │
│  │            ▼                    ▼                                    │   │
│  │       ┌──────────┐         ┌──────────┐                              │   │
│  │       │ useState │         │  Props   │                              │   │
│  │       │ (hook)   │         │ (concept)│                              │   │
│  │       └──────────┘         └──────────┘                              │   │
│  │                                                                      │   │
│  │  Storage: Graph Database (Neo4j-style)                               │   │
│  │  Query: Graph traversal, semantic search                             │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  EPISODIC MEMORY (Events & Experiences)                              │   │
│  │  ══════════════════════════════════════                              │   │
│  │                                                                      │   │
│  │  Event Structure:                                                    │   │
│  │  {                                                                   │   │
│  │    "event_id": "evt-2024-001",                                       │   │
│  │    "timestamp": "2024-01-15T10:30:00Z",                              │   │
│  │    "agent_id": "react-agent-001",                                    │   │
│  │    "task": "Implement authentication",                               │   │
│  │    "context": {                                                      │   │
│  │      "project": "inventory-system",                                  │   │
│  │      "complexity": "high",                                           │   │
│  │      "dependencies": ["database", "api"]                             │   │
│  │    },                                                                │   │
│  │    "actions": [...],                                                 │   │
│  │    "outcome": "success",                                             │   │
│  │    "lessons_learned": ["Use JWT", "Hash passwords"]                  │   │
│  │  }                                                                   │   │
│  │                                                                      │   │
│  │  Storage: Time-series database with vector embeddings                │   │
│  │  Query: Temporal search, similarity matching                         │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  PROCEDURAL KNOWLEDGE (Skills & Procedures)                          │   │
│  │  ══════════════════════════════════════════                          │   │
│  │                                                                      │   │
│  │  Skill Structure:                                                    │   │
│  │  {                                                                   │   │
│  │    "skill_id": "skill-auth-001",                                     │   │
│  │    "name": "Implement JWT Authentication",                           │   │
│  │    "domain": "backend",                                              │   │
│  │    "difficulty": "intermediate",                                     │   │
│  │    "steps": [                                                        │   │
│  │      { "order": 1, "action": "Install JWT library", ... },           │   │
│  │      { "order": 2, "action": "Create auth middleware", ... },        │   │
│  │      { "order": 3, "action": "Implement token refresh", ... }        │   │
│  │    ],                                                                │   │
│  │    "preconditions": ["Node.js", "Express"],                          │   │
│  │    "success_criteria": ["Token valid", "Refresh works"],             │   │
│  │    "common_pitfalls": ["Don't store in localStorage"]                │   │
│  │  }                                                                   │   │
│  │                                                                      │   │
│  │  Storage: Structured database with version control                   │   │
│  │  Query: Skill matching, prerequisite checking                        │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Knowledge Graph Schema

```typescript
// Knowledge Graph Node Types
interface KnowledgeNode {
  id: string;
  type: 'concept' | 'entity' | 'skill' | 'pattern' | 'best_practice';
  label: string;
  properties: {
    description: string;
    domain: string[];
    difficulty?: 'beginner' | 'intermediate' | 'advanced';
    tags: string[];
    created_at: Date;
    updated_at: Date;
    usage_count: number;
    success_rate: number;
  };
  embedding: number[]; // Vector for semantic search
}

// Knowledge Graph Edge Types
interface KnowledgeEdge {
  id: string;
  from: string; // Node ID
  to: string;   // Node ID
  type: 'relates_to' | 'depends_on' | 'is_part_of' | 'leads_to' | 'contradicts';
  properties: {
    strength: number; // 0.0 - 1.0
    context: string;
    evidence: string[];
  };
}

// Agent Knowledge Profile
interface AgentKnowledgeProfile {
  agent_id: string;
  expertise_areas: {
    domain: string;
    level: 'novice' | 'competent' | 'proficient' | 'expert' | 'master';
    verified_tasks: number;
  }[];
  known_patterns: string[]; // Pattern IDs
  successful_solutions: {
    task_type: string;
    count: number;
    avg_quality: number;
  }[];
  learning_goals: string[];
  knowledge_gaps: string[];
}
```

---

## 4. Memory Operations

### 4.1 Core Memory Operations

```typescript
// Memory Manager Interface
interface MemoryManager {
  // Working Memory Operations
  workingMemory: {
    set(key: string, value: any, priority: 'high' | 'medium' | 'low'): void;
    get(key: string): any;
    clear(): void;
    getContext(): WorkingMemoryContext;
  };

  // Short-term Memory Operations
  shortTermMemory: {
    store(event: MemoryEvent): void;
    recall(query: MemoryQuery): MemoryEvent[];
    getRecent(limit: number): MemoryEvent[];
    getSessionHistory(sessionId: string): MemoryEvent[];
  };

  // Long-term Memory Operations
  longTermMemory: {
    consolidate(events: MemoryEvent[]): Promise<void>;
    retrieve(query: KnowledgeQuery): Promise<KnowledgeItem[]>;
    searchSimilar(embedding: number[], threshold: number): Promise<KnowledgeItem[]>;
    updateKnowledge(knowledge: KnowledgeItem): Promise<void>;
  };

  // Knowledge Base Operations
  knowledgeBase: {
    queryGraph(query: GraphQuery): Promise<KnowledgeNode[]>;
    addNode(node: KnowledgeNode): Promise<void>;
    addEdge(edge: KnowledgeEdge): Promise<void>;
    findPath(from: string, to: string): Promise<KnowledgeEdge[]>;
  };
}

// Memory Event Structure
interface MemoryEvent {
  id: string;
  timestamp: Date;
  agent_id: string;
  task_id: string;
  event_type: 'task_start' | 'task_complete' | 'decision' | 'error' | 'learning';
  content: {
    description: string;
    context: Record<string, any>;
    outcome?: string;
    lessons?: string[];
  };
  importance: number; // 0.0 - 1.0
  embedding: number[];
}

// Knowledge Query
interface KnowledgeQuery {
  domain?: string[];
  keywords?: string[];
  difficulty?: string;
  recency?: 'last_day' | 'last_week' | 'last_month' | 'all_time';
  success_rate_min?: number;
  semantic_query?: string; // Natural language query
}
```

### 4.2 Memory Retrieval Strategies

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MEMORY RETRIEVAL STRATEGIES                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  1. EXACT MATCH RETRIEVAL                                          │   │
│  │     • Direct key lookup                                             │   │
│  │     • Fastest (< 1ms)                                               │   │
│  │     • Use case: Known facts, cached results                         │   │
│  │                                                                      │   │
│  │  2. SEMANTIC SEARCH                                                 │   │
│  │     • Vector similarity search                                      │   │
│  │     • Fast (< 100ms)                                                │   │
│  │     • Use case: Related concepts, similar problems                  │   │
│  │                                                                      │   │
│  │  3. GRAPH TRAVERSAL                                                 │   │
│  │     • Navigate knowledge graph                                      │   │
│  │     • Moderate (< 500ms)                                            │   │
│  │     • Use case: Finding relationships, dependencies                 │   │
│  │                                                                      │   │
│  │  4. TEMPORAL SEARCH                                                 │   │
│  │     • Time-based filtering                                          │   │
│  │     • Fast (< 50ms)                                                 │   │
│  │     • Use case: Recent events, historical context                   │   │
│  │                                                                      │   │
│  │  5. HYBRID RETRIEVAL (Recommended)                                  │   │
│  │     • Combine multiple strategies                                   │   │
│  │     • Moderate (< 200ms)                                            │   │
│  │     • Use case: Complex queries requiring multiple dimensions       │   │
│  │                                                                      │   │
│  │     Algorithm:                                                      │   │
│  │     1. Semantic search → Get candidates                             │   │
│  │     2. Filter by temporal constraints                               │   │
│  │     3. Graph traversal for relationships                            │   │
│  │     4. Rank by relevance score                                      │   │
│  │     5. Return top-k results                                         │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Learning & Adaptation

### 5.1 Learning Mechanisms

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    LEARNING MECHANISMS                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  1. EXPERIENCE-BASED LEARNING                                       │   │
│  │                                                                      │   │
│  │     From Success:                                                    │   │
│  │     • Extract successful patterns                                    │   │
│  │     • Store as best practices                                        │   │
│  │     • Increase confidence in approach                                │   │
│  │                                                                      │   │
│  │     From Failure:                                                    │   │
│  │     • Analyze root causes                                            │   │
│  │     • Store pitfalls to avoid                                        │   │
│  │     • Update risk assessment                                         │   │
│  │                                                                      │   │
│  │  2. OBSERVATIONAL LEARNING                                          │   │
│  │                                                                      │   │
│  │     • Watch other agents' solutions                                  │   │
│  │     • Compare with own approach                                      │   │
│  │     • Adopt better techniques                                        │   │
│  │     • Cross-pollinate knowledge                                      │   │
│  │                                                                      │   │
│  │  3. FEEDBACK-BASED LEARNING                                         │   │
│  │                                                                      │   │
│  │     From Reviews:                                                    │   │
│  │     • Code review feedback                                           │   │
│  │     • Performance metrics                                            │   │
│  │     • User satisfaction                                              │   │
│  │                                                                      │   │
│  │     Adaptation:                                                      │   │
│  │     • Adjust coding style                                            │   │
│  │     • Improve documentation                                          │   │
│  │     • Refine approach                                                │   │
│  │                                                                      │   │
│  │  4. ACTIVE LEARNING                                                   │   │
│  │                                                                      │   │
│  │     • Identify knowledge gaps                                        │   │
│  │     • Seek relevant information                                      │   │
│  │     • Experiment with new approaches                                 │   │
│  │     • Validate hypotheses                                            │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  Learning Pipeline:                                                          │
│                                                                              │
│  Experience → Extract Patterns → Validate → Store → Apply → Measure        │
│       ↑                                                            │        │
│       └──────────────────── Feedback Loop ─────────────────────────┘        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Knowledge Sharing Protocol

```typescript
// Knowledge Sharing Interface
interface KnowledgeSharingProtocol {
  // Share knowledge with other agents
  shareKnowledge(
    from: string,      // Agent ID
    to: string[],      // Target agents
    knowledge: SharedKnowledge
  ): Promise<void>;

  // Request knowledge from other agents
  requestKnowledge(
    requester: string,
    query: KnowledgeQuery,
    timeout: number
  ): Promise<SharedKnowledge[]>;

  // Broadcast new discovery
  broadcastDiscovery(
    discoverer: string,
    discovery: NewDiscovery
  ): Promise<void>;

  // Subscribe to knowledge updates
  subscribeToUpdates(
    subscriber: string,
    topics: string[]
  ): Promise<Subscription>;
}

// Shared Knowledge Structure
interface SharedKnowledge {
  id: string;
  type: 'pattern' | 'solution' | 'lesson' | 'resource';
  source: {
    agent_id: string;
    task_id: string;
    timestamp: Date;
  };
  content: {
    title: string;
    description: string;
    domain: string[];
    applicability: string[];
    code_example?: string;
    documentation?: string;
  };
  validation: {
    verified_by: string[];
    success_count: number;
    failure_count: number;
  };
  confidence: number; // 0.0 - 1.0
}
```

---

## 6. Implementation Architecture

### 6.1 Memory Service Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MEMORY SERVICE ARCHITECTURE                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    Memory Service API                                │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │   Store     │  │   Retrieve  │  │   Search    │  │   Update   │ │   │
│  │  │             │  │             │  │             │  │            │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│           ┌────────────────────────┼────────────────────────┐               │
│           │                        │                        │               │
│           ▼                        ▼                        ▼               │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐         │
│  │ Working Memory  │    │  Redis Cache    │    │  Vector Store   │         │
│  │   (In-Memory)   │    │  (Short-term)   │    │  (Long-term)    │         │
│  │                 │    │                 │    │                 │         │
│  │ • Context stack │    │ • Session data  │    │ • Embeddings    │         │
│  │ • Active vars   │    │ • Recent events │    │ • Semantic      │         │
│  │ • Task state    │    │ • Hot data      │    │   search        │         │
│  └─────────────────┘    └─────────────────┘    └─────────────────┘         │
│                                                              │              │
│                                                              ▼              │
│                                                   ┌─────────────────┐       │
│                                                   │  Knowledge Graph  │       │
│                                                   │    (Neo4j-like)   │       │
│                                                   │                   │       │
│                                                   │ • Nodes & Edges   │       │
│                                                   │ • Relationships   │       │
│                                                   │ • Path queries    │       │
│                                                   └─────────────────┘       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 MCP Tools for Memory

```typescript
// Memory-related MCP Tools
const memoryTools = [
  {
    name: "memory_store",
    description: "Store information in agent's memory",
    inputSchema: {
      type: "object",
      properties: {
        key: { type: "string" },
        value: { type: "any" },
        memory_type: { 
          type: "string", 
          enum: ["working", "short_term", "long_term"] 
        },
        importance: { type: "number", minimum: 0, maximum: 1 },
        tags: { type: "array", items: { type: "string" } }
      },
      required: ["key", "value", "memory_type"]
    }
  },
  {
    name: "memory_retrieve",
    description: "Retrieve information from agent's memory",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string" },
        memory_type: { 
          type: "string", 
          enum: ["working", "short_term", "long_term", "all"] 
        },
        limit: { type: "number", default: 10 },
        semantic_search: { type: "boolean", default: true }
      },
      required: ["query"]
    }
  },
  {
    name: "knowledge_query",
    description: "Query the shared knowledge base",
    inputSchema: {
      type: "object",
      properties: {
        domain: { type: "array", items: { type: "string" } },
        keywords: { type: "array", items: { type: "string" } },
        difficulty: { 
          type: "string", 
          enum: ["beginner", "intermediate", "advanced"] 
        },
        semantic_query: { type: "string" }
      }
    }
  },
  {
    name: "knowledge_share",
    description: "Share knowledge with other agents",
    inputSchema: {
      type: "object",
      properties: {
        target_agents: { type: "array", items: { type: "string" } },
        knowledge_type: { 
          type: "string", 
          enum: ["pattern", "solution", "lesson", "resource"] 
        },
        content: { type: "object" },
        confidence: { type: "number", minimum: 0, maximum: 1 }
      },
      required: ["target_agents", "knowledge_type", "content"]
    }
  },
  {
    name: "learn_from_experience",
    description: "Extract lessons from completed task",
    inputSchema: {
      type: "object",
      properties: {
        task_id: { type: "string" },
        outcome: { type: "string", enum: ["success", "failure", "partial"] },
        lessons: { type: "array", items: { type: "string" } },
        patterns_identified: { type: "array", items: { type: "string" } }
      },
      required: ["task_id", "outcome"]
    }
  }
];
```

---

## 7. Integration with Hierarchical Agents

### 7.1 Memory by Agent Level

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MEMORY BY AGENT LEVEL                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  CTO AGENT MEMORY                                                    │   │
│  │  ═══════════════════                                                 │   │
│  │  • Strategic decisions history                                       │   │
│  │  • Project outcomes and lessons                                      │   │
│  │  • Department performance metrics                                    │   │
│  │  • Technology roadmap decisions                                      │   │
│  │  • High-level architectural patterns                                 │   │
│  │  • Stakeholder preferences                                           │   │
│  │                                                                      │   │
│  │  Memory Focus: Long-term, strategic knowledge                        │   │
│  │  Retention: Permanent, high-value decisions                          │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  DEPARTMENT HEAD MEMORY                                              │   │
│  │  ════════════════════════                                            │   │
│  │  • Team performance and capabilities                                 │   │
│  │  • Technical standards and best practices                            │   │
│  │  • Common issues and solutions                                       │   │
│  │  • Cross-team dependencies                                           │   │
│  │  • Resource allocation history                                       │   │
│  │  • Code review patterns                                              │   │
│  │                                                                      │   │
│  │  Memory Focus: Medium-term, tactical knowledge                       │   │
│  │  Retention: Project-level, reusable patterns                         │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  WORKER AGENT MEMORY                                                 │   │
│  │  ═════════════════════                                               │   │
│  │  • Implementation techniques                                         │   │
│  │  • Language/framework specific patterns                              │   │
│  │  • Common bugs and fixes                                             │   │
│  │  • Performance optimization tricks                                   │   │
│  │  • Library and tool usage                                            │   │
│  │  • Personal coding style preferences                                 │   │
│  │                                                                      │   │
│  │  Memory Focus: Short-term, implementation knowledge                  │   │
│  │  Retention: Task-level, technique-specific                           │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  SHARED KNOWLEDGE BASE (All Levels)                                          │
│  • Common coding standards                                                 │
│  • Security best practices                                                 │
│  • Architecture patterns                                                   │
│  • Domain knowledge                                                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Configuration Example

```json
{
  "memory_system": {
    "working_memory": {
      "max_items": 7,
      "ttl_seconds": 3600,
      "cleanup_interval": 300
    },
    "short_term_memory": {
      "max_events": 100,
      "ttl_hours": 24,
      "compression_threshold": 50
    },
    "long_term_memory": {
      "storage_type": "vector_db",
      "embedding_model": "text-embedding-3-large",
      "embedding_dimensions": 3072,
      "similarity_threshold": 0.75,
      "index_type": "hnsw"
    },
    "knowledge_graph": {
      "database": "neo4j",
      "connection": {
        "uri": "bolt://localhost:7687",
        "user": "neo4j",
        "password": "${NEO4J_PASSWORD}"
      },
      "indexes": ["domain", "difficulty", "tags"]
    },
    "learning": {
      "auto_consolidate": true,
      "consolidation_interval": "1h",
      "min_confidence_for_sharing": 0.7,
      "feedback_window_days": 30
    }
  }
}
```

---

## 9. Summary

ระบบ Memory & Knowledge Management นี้ช่วยให้ MCP Hierarchical Agents:

1. **จดจำประสบการณ์** - เก็บบทเรียนจากงานที่ผ่านมา
2. **สะสมความรู้** - สร้าง knowledge base ที่เติบโตต่อเนื่อง
3. **แบ่งปันความรู้** - ถ่ายทอดความรู้ระหว่าง Agents
4. **เรียนรู้และพัฒนา** - ปรับปรุงประสิทธิภาพจาก feedback
5. **ค้นหาได้อย่างมีประสิทธิภาพ** - ใช้ semantic search และ graph traversal

**Key Features:**
- ✅ Three-layer memory hierarchy (Working, Short-term, Long-term)
- ✅ Three-type knowledge representation (Semantic, Episodic, Procedural)
- ✅ Knowledge Graph สำหรับความสัมพันธ์เชิงความหมาย
- ✅ Multiple retrieval strategies (Exact, Semantic, Graph, Temporal, Hybrid)
- ✅ Learning mechanisms (Experience-based, Observational, Feedback-based, Active)
- ✅ Knowledge sharing protocol สำหรับการแบ่งปันความรู้
