# Enhanced Communication Protocol
## ระบบสื่อสารขั้นสูงสำหรับ Multi-Agent Systems

---

## 1. ภาพรวมระบบ (System Overview)

### 1.1 วัตถุประสงค์

ออกแบบระบบสื่อสารที่ Agents สามารถ:
- สื่อสารได้หลายรูปแบบ (1-to-1, 1-to-many, many-to-many)
- แบ่งปันบริบทได้อย่างมีประสิทธิภาพ
- ส่งข้อความแบบ priority-based
- รักษาความปลอดภัยในการสื่อสาร
- สื่อสารแบบ synchronous และ asynchronous

### 1.2 Communication Patterns

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    COMMUNICATION PATTERNS                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 1: POINT-TO-POINT (1-to-1)                                          │
│  ══════════════════════════════════                                          │
│                                                                              │
│       ┌─────┐              Message              ┌─────┐                     │
│       │  A  │ ────────────────────────────────▶ │  B  │                     │
│       └─────┘                                   └─────┘                     │
│                                                                              │
│  Use case: Direct instructions, private feedback, 1-on-1 coordination       │
│  Guarantee: Delivery confirmation, ordering                                  │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 2: BROADCAST (1-to-Many)                                            │
│  ════════════════════════════════                                            │
│                                                                              │
│       ┌─────┐                                                               │
│       │  A  │ ──────▶ ┌─────┐                                               │
│       │(CTO)│ ──────▶ │  B  │                                               │
│       └─────┘ ──────▶ │(DH) │                                               │
│              ──────▶  └─────┘                                               │
│              ──────▶  ┌─────┐                                               │
│              ──────▶  │  C  │                                               │
│              ──────▶  │(DH) │                                               │
│                       └─────┘                                               │
│                                                                              │
│  Use case: Announcements, policy updates, emergency alerts                  │
│  Guarantee: At-least-once delivery, no ordering guarantee                   │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 3: MULTICAST (1-to-Group)                                           │
│  ═════════════════════════════════                                           │
│                                                                              │
│       ┌─────┐                                                               │
│       │  A  │ ──────▶ ┌─────┐                                               │
│       │(CTO)│ ──────▶ │  B  │ ◀── Frontend Department                       │
│       └─────┘ ──────▶ │  C  │                                               │
│                       └─────┘                                               │
│                                                                              │
│  Use case: Department-specific communications, role-based messaging         │
│  Guarantee: Delivery to group members only                                   │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 4: PUBLISH-SUBSCRIBE (Many-to-Many)                                 │
│  ═══════════════════════════════════════════                                 │
│                                                                              │
│       ┌─────┐         ┌─────────────┐         ┌─────┐                       │
│       │  A  │────┐    │             │    ┌────│  D  │                       │
│       └─────┘    │    │   Message   │    │    └─────┘                       │
│                  ├───▶ │   Broker    │───▶│                                 │
│       ┌─────┐    │    │   (Topic)   │    │    ┌─────┐                       │
│       │  B  │────┘    │             │    └────│  E  │                       │
│       └─────┘         └─────────────┘         └─────┘                       │
│                                                                              │
│  Subscribers choose which topics to receive                                  │
│                                                                              │
│  Topics:                                                                     │
│  • "code.commits" - New code commits                                         │
│  • "tasks.new" - New tasks created                                           │
│  • "alerts.critical" - Critical system alerts                                │
│  • "knowledge.updates" - Knowledge base updates                              │
│                                                                              │
│  Use case: Event-driven architecture, decoupled communication               │
│  Guarantee: At-least-once delivery, topic-based filtering                   │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 5: REQUEST-REPLY (Synchronous)                                      │
│  ══════════════════════════════════════                                      │
│                                                                              │
│       ┌─────┐              Request              ┌─────┐                     │
│       │  A  │ ────────────────────────────────▶ │  B  │                     │
│       │     │ ◀──────────────────────────────── │     │                     │
│       └─────┘              Reply                └─────┘                     │
│                                                                              │
│  Use case: Queries, approvals, immediate responses needed                   │
│  Guarantee: Synchronous, timeout handling                                    │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 6: PIPELINE (Chained Processing)                                    │
│  ════════════════════════════════════════                                    │
│                                                                              │
│       ┌─────┐      ┌─────┐      ┌─────┐      ┌─────┐                       │
│       │  A  │───▶  │  B  │───▶  │  C  │───▶  │  D  │                       │
│       │Input│      │Parse│      │Process│    │Output│                       │
│       └─────┘      └─────┘      └─────┘      └─────┘                       │
│                                                                              │
│  Use case: Multi-stage processing, workflow pipelines                       │
│  Guarantee: Ordered processing, error propagation                           │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Message Structure

### 2.1 Standard Message Format

```typescript
// Standard Message Structure
interface AgentMessage {
  // Message Identity
  message_id: string;           // UUID v4
  correlation_id?: string;      // For request-reply pairing
  
  // Routing Information
  from: {
    agent_id: string;
    agent_type: string;
    department?: string;
    level: number;              // Hierarchy level
  };
  to: {
    type: 'agent' | 'group' | 'broadcast' | 'topic';
    target: string | string[];  // Agent ID(s), group name, or topic
  };
  
  // Message Content
  message_type: 
    | 'command'        // Direct instruction
    | 'query'          // Question/request info
    | 'response'       // Reply to query
    | 'event'          // Notification of something happened
    | 'update'         // Status update
    | 'delegation'     // Task delegation
    | 'submission'     // Task submission
    | 'approval'       // Approval/authorization
    | 'alert'          // Warning or error
    | 'heartbeat';     // Health check
  
  payload: {
    // Type-specific content
    [key: string]: any;
  };
  
  // Context
  context: {
    task_id?: string;
    project_id?: string;
    session_id?: string;
    conversation_id?: string;
    parent_message_id?: string;
    timestamp: Date;
    timezone: string;
  };
  
  // Priority & QoS
  priority: 'critical' | 'high' | 'normal' | 'low';
  qos: {
    delivery guarantee: 'at-most-once' | 'at-least-once' | 'exactly-once';
    ordering: 'unordered' | 'ordered';
    ttl_seconds: number;
  };
  
  // Security
  security: {
    encrypted: boolean;
    signature?: string;
    clearance_level?: string;
  };
  
  // Metadata
  metadata: {
    version: string;
    compression?: string;
    size_bytes: number;
    tags: string[];
  };
}

// Example Messages

// 1. Task Delegation
const delegationMessage: AgentMessage = {
  message_id: "msg-001",
  from: {
    agent_id: "cto-agent",
    agent_type: "cto",
    level: 1
  },
  to: {
    type: "agent",
    target: "frontend-head"
  },
  message_type: "delegation",
  payload: {
    task: {
      id: "task-001",
      title: "Implement user authentication UI",
      description: "Create login and registration forms",
      requirements: ["React", "Form validation", "Responsive design"],
      acceptance_criteria: ["Unit tests > 80%", "Accessibility compliant"],
      priority: "high",
      deadline: "2024-01-20T00:00:00Z"
    },
    authority: {
      can_delegate: true,
      max_delegation_depth: 1,
      approval_required: true
    }
  },
  context: {
    task_id: "task-001",
    project_id: "inventory-system",
    timestamp: new Date(),
    timezone: "UTC"
  },
  priority: "high",
  qos: {
    delivery_guarantee: "at-least-once",
    ordering: "ordered",
    ttl_seconds: 86400
  },
  security: {
    encrypted: true,
    clearance_level: "standard"
  },
  metadata: {
    version: "1.0",
    size_bytes: 2048,
    tags: ["delegation", "frontend", "auth"]
  }
};

// 2. Task Submission
const submissionMessage: AgentMessage = {
  message_id: "msg-002",
  correlation_id: "msg-001",  // Links to delegation
  from: {
    agent_id: "react-agent-001",
    agent_type: "worker",
    department: "frontend",
    level: 3
  },
  to: {
    type: "agent",
    target: "frontend-head"
  },
  message_type: "submission",
  payload: {
    task_id: "task-001",
    status: "completed",
    deliverables: [
      {
        type: "code",
        files: ["LoginForm.tsx", "RegisterForm.tsx", "auth-utils.ts"],
        location: "git://repo/src/components/auth/"
      },
      {
        type: "tests",
        files: ["LoginForm.test.tsx"],
        coverage: 85,
        location: "git://repo/src/components/auth/__tests__/"
      },
      {
        type: "documentation",
        content: "README.md with usage examples"
      }
    ],
    metrics: {
      time_spent_minutes: 480,
      lines_of_code: 350,
      test_count: 15,
      bug_fixes: 2
    },
    self_assessment: {
      quality_score: 9,
      confidence: 0.92,
      known_issues: []
    }
  },
  context: {
    task_id: "task-001",
    project_id: "inventory-system",
    timestamp: new Date(),
    timezone: "UTC"
  },
  priority: "high",
  qos: {
    delivery_guarantee: "at-least-once",
    ordering: "ordered",
    ttl_seconds: 604800
  },
  security: {
    encrypted: true
  },
  metadata: {
    version: "1.0",
    size_bytes: 4096,
    tags: ["submission", "frontend", "auth", "completed"]
  }
};
```

---

## 3. Context Sharing

### 3.1 Context Propagation

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    CONTEXT PROPAGATION                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  CONTEXT HIERARCHY                                                           │
│  ═════════════════                                                           │
│                                                                              │
│  Level 1: Global Context (Shared by all agents)                              │
│  ├── Organization goals                                                      │
│  ├── Coding standards                                                        │
│  ├── Security policies                                                       │
│  └── Shared knowledge base                                                   │
│                                                                              │
│  Level 2: Project Context (Shared by project members)                        │
│  ├── Project requirements                                                    │
│  ├── Architecture decisions                                                  │
│  ├── Tech stack                                                              │
│  └── Timeline and milestones                                                 │
│                                                                              │
│  Level 3: Task Context (Shared by task participants)                         │
│  ├── Task description                                                        │
│  ├── Acceptance criteria                                                     │
│  ├── Dependencies                                                            │
│  └── Related tasks                                                           │
│                                                                              │
│  Level 4: Conversation Context (Specific to message thread)                  │
│  ├── Previous messages                                                       │
│  ├── Decisions made                                                          │
│  └── Action items                                                            │
│                                                                              │
│  Context Propagation Flow:                                                   │
│                                                                              │
│  ┌─────────────┐                                                             │
│  │   Global    │◀─────────────────────────────────────────┐                 │
│  │   Context   │                                          │                 │
│  └──────┬──────┘                                          │                 │
│         │ Inherits                                        │                 │
│         ▼                                                 │                 │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐   │                 │
│  │  Project A  │    │  Project B  │    │  Project C  │   │                 │
│  │   Context   │    │   Context   │    │   Context   │   │                 │
│  └──────┬──────┘    └─────────────┘    └─────────────┘   │                 │
│         │ Inherits                                         │                 │
│         ▼                                                  │                 │
│  ┌─────────────┐    ┌─────────────┐                       │                 │
│  │   Task 1    │    │   Task 2    │                       │                 │
│  │   Context   │    │   Context   │                       │                 │
│  └──────┬──────┘    └─────────────┘                       │                 │
│         │ Inherits                                          │                 │
│         ▼                                                   │                 │
│  ┌─────────────┐                                            │                 │
│  │ Conversation│                                            │                 │
│  │   Context   │                                            │                 │
│  └─────────────┘                                            │                 │
│                                                             │                 │
│  Updates flow upward ───────────────────────────────────────┘                 │
│  (e.g., new best practice → update Global Context)                            │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Context Snapshot

```typescript
// Context Snapshot for Message Passing
interface ContextSnapshot {
  snapshot_id: string;
  timestamp: Date;
  
  // Hierarchical context layers
  layers: {
    global: GlobalContext;
    project?: ProjectContext;
    task?: TaskContext;
    conversation?: ConversationContext;
  };
  
  // Relevant entities
  entities: {
    agents: AgentReference[];
    tasks: TaskReference[];
    resources: ResourceReference[];
  };
  
  // Recent events that may be relevant
  recent_events: EventReference[];
  
  // Computed insights
  insights: {
    related_knowledge: string[];
    similar_tasks: string[];
    relevant_agents: string[];
    potential_issues: string[];
  };
}

// Context Sharing Protocol
interface ContextSharingProtocol {
  // Push context to another agent
  pushContext(
    target: string,
    context: ContextSnapshot,
    options: {
      include_history: boolean;
      include_insights: boolean;
      compression: 'none' | 'light' | 'heavy';
    }
  ): Promise<void>;
  
  // Pull context from another agent
  pullContext(
    source: string,
    query: ContextQuery
  ): Promise<ContextSnapshot>;
  
  // Subscribe to context updates
  subscribeToContext(
    topic: string,
    callback: (update: ContextUpdate) => void
  ): Subscription;
  
  // Merge received context with local context
  mergeContext(
    received: ContextSnapshot,
    strategy: 'overwrite' | 'merge' | 'append'
  ): Promise<void>;
}
```

---

## 4. Priority & Queue Management

### 4.1 Message Priority System

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MESSAGE PRIORITY SYSTEM                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PRIORITY LEVELS                                                             │
│  ═══════════════                                                             │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  CRITICAL (P0) - Process immediately, interrupt if needed            │   │
│  │  • System failures                                                   │   │
│  │  • Security breaches                                                 │   │
│  │  • Data corruption                                                   │   │
│  │  • SLA violations                                                    │   │
│  │  SLA: < 100ms processing                                             │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  HIGH (P1) - Process ASAP, before normal tasks                       │   │
│  │  • Task deadlines approaching                                        │   │
│  │  • Blocking dependencies                                             │   │
│  │  • Escalations                                                       │   │
│  │  • Important approvals                                               │   │
│  │  SLA: < 1 second processing                                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  NORMAL (P2) - Standard processing                                   │   │
│  │  • Regular task assignments                                          │   │
│  │  • Status updates                                                    │   │
│  │  • Routine queries                                                   │   │
│  │  SLA: < 5 seconds processing                                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  LOW (P3) - Process when idle                                        │   │
│  │  • Analytics and reporting                                           │   │
│  │  • Non-urgent notifications                                          │   │
│  │  • Background sync                                                   │   │
│  │  SLA: < 1 minute processing                                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  QUEUE MANAGEMENT                                                            │
│  ═════════════════                                                           │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                      │   │
│  │   Incoming Messages                                                  │   │
│  │        │                                                             │   │
│  │        ▼                                                             │   │
│  │   ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐         │   │
│  │   │CRITICAL │    │  HIGH   │    │ NORMAL  │    │   LOW   │         │   │
│  │   │  Queue  │    │  Queue  │    │  Queue  │    │  Queue  │         │   │
│  │   │  (P0)   │    │  (P1)   │    │  (P2)   │    │  (P3)   │         │   │
│  │   └────┬────┘    └────┬────┘    └────┬────┘    └────┬────┘         │   │
│  │        │              │              │              │               │   │
│  │        └──────────────┴──────────────┴──────────────┘               │   │
│  │                       │                                             │   │
│  │                       ▼                                             │   │
│  │              ┌─────────────────┐                                    │   │
│  │              │  Priority       │                                    │   │
│  │              │  Scheduler      │                                    │   │
│  │              │                 │                                    │   │
│  │              │  Rules:         │                                    │   │
│  │              │  • P0: Always   │                                    │   │
│  │              │    first        │                                    │   │
│  │              │  • P1: If no P0 │                                    │   │
│  │              │  • P2: If no    │                                    │   │
│  │              │    P0 or P1     │                                    │   │
│  │              │  • P3: Only when│                                    │   │
│  │              │    idle         │                                    │   │
│  │              └────────┬────────┘                                    │   │
│  │                       │                                             │   │
│  │                       ▼                                             │   │
│  │              ┌─────────────────┐                                    │   │
│  │              │  Agent Worker   │                                    │   │
│  │              │  Pool           │                                    │   │
│  │              └─────────────────┘                                    │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  FAIRNESS MECHANISM                                                          │
│  ═══════════════════                                                         │
│  • Starvation prevention: Lower priority messages eventually processed      │
│  • Aging: Increase priority of waiting messages over time                   │
│  • Quotas: Reserve capacity for each priority level                         │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Security & Authentication

### 5.1 Security Protocol

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SECURITY PROTOCOL                                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  AUTHENTICATION                                                              │
│  ═══════════════                                                             │
│                                                                              │
│  1. AGENT IDENTITY                                                           │
│     • Each agent has unique certificate                                      │
│     • Certificate signed by central authority (CTO)                          │
│     • Includes: agent_id, type, department, level, permissions               │
│                                                                              │
│  2. MESSAGE SIGNING                                                          │
│     • All messages digitally signed                                          │
│     • Signature verified by recipient                                        │
│     • Prevents spoofing and tampering                                        │
│                                                                              │
│  3. ENCRYPTION                                                               │
│     • End-to-end encryption for sensitive messages                           │
│     • TLS for transport security                                             │
│     • Key rotation every 24 hours                                            │
│                                                                              │
│  AUTHORIZATION                                                               │
│  ═══════════════                                                             │
│                                                                              │
│  Permission Matrix:                                                          │
│                                                                              │
│  Agent Type    │ Can Message To              │ Special Permissions          │
│  ──────────────┼─────────────────────────────┼─────────────────────────     │
│  CTO           │ Anyone                      │ Override, Emergency, All     │
│  Department    │ CTO, Same Dept, Workers     │ Delegate, Review, Approve    │
│  Worker        │ Manager, Same Dept Workers  │ Execute, Report              │
│                                                                              │
│  Clearance Levels:                                                           │
│  • Public - Anyone can access                                                │
│  • Internal - Agents only                                                    │
│  • Confidential - Department only                                            │
│  • Restricted - Specific agents only                                         │
│                                                                              │
│  SECURITY CHECKS                                                             │
│  ════════════════                                                            │
│                                                                              │
│  Every message undergoes:                                                    │
│  1. Signature verification                                                   │
│  2. Permission check                                                         │
│  3. Rate limiting                                                            │
│  4. Content validation                                                       │
│  5. Audit logging                                                            │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. MCP Tools for Communication

```typescript
// Communication-related MCP Tools
const communicationTools = [
  {
    name: "comm_send_message",
    description: "Send a message to another agent or group",
    inputSchema: {
      type: "object",
      properties: {
        to: {
          type: "object",
          properties: {
            type: { 
              type: "string", 
              enum: ["agent", "group", "broadcast", "topic"] 
            },
            target: { 
              oneOf: [
                { type: "string" },
                { type: "array", items: { type: "string" } }
              ]
            }
          }
        },
        message_type: {
          type: "string",
          enum: ["command", "query", "response", "event", "update", 
                 "delegation", "submission", "approval", "alert", "heartbeat"]
        },
        payload: { type: "object" },
        priority: { 
          type: "string", 
          enum: ["critical", "high", "normal", "low"],
          default: "normal"
        },
        context: { type: "object" },
        require_reply: { type: "boolean", default: false },
        timeout_ms: { type: "number", default: 30000 }
      },
      required: ["to", "message_type", "payload"]
    }
  },
  {
    name: "comm_broadcast",
    description: "Broadcast message to multiple agents",
    inputSchema: {
      type: "object",
      properties: {
        message_type: { type: "string" },
        payload: { type: "object" },
        exclude: { type: "array", items: { type: "string" } },
        priority: { type: "string" }
      },
      required: ["message_type", "payload"]
    }
  },
  {
    name: "comm_subscribe",
    description: "Subscribe to a topic for updates",
    inputSchema: {
      type: "object",
      properties: {
        topic: { type: "string" },
        filter: { type: "object" },
        callback: { type: "string" } // Callback handler name
      },
      required: ["topic"]
    }
  },
  {
    name: "comm_get_conversation_history",
    description: "Get message history for a conversation",
    inputSchema: {
      type: "object",
      properties: {
        conversation_id: { type: "string" },
        since: { type: "string", format: "date-time" },
        limit: { type: "number", default: 50 },
        include_context: { type: "boolean", default: true }
      },
      required: ["conversation_id"]
    }
  },
  {
    name: "comm_share_context",
    description: "Share context with another agent",
    inputSchema: {
      type: "object",
      properties: {
        target: { type: "string" },
        context_layers: { 
          type: "array", 
          items: { 
            type: "string",
            enum: ["global", "project", "task", "conversation"]
          }
        },
        include_insights: { type: "boolean", default: true }
      },
      required: ["target"]
    }
  }
];
```

---

## 7. Summary

ระบบ Enhanced Communication Protocol นี้ช่วยให้ MCP Hierarchical Agents:

1. **สื่อสารได้หลายรูปแบบ** - Point-to-point, Broadcast, Multicast, Pub-Sub, Pipeline
2. **แบ่งปันบริบทได้อย่างมีประสิทธิภาพ** - Hierarchical context propagation
3. **จัดการ priority ได้** - 4 priority levels พร้อม queue management
4. **รักษาความปลอดภัย** - Authentication, authorization, encryption
5. **รองรับ synchronous และ asynchronous** - Request-reply และ event-driven

**Key Features:**
- ✅ 6 Communication Patterns
- ✅ Standardized Message Format
- ✅ Hierarchical Context Sharing
- ✅ Priority-based Queue Management
- ✅ Security & Authentication
- ✅ MCP Tools สำหรับการสื่อสาร
