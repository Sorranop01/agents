# Swarm Agents System
## ระบบ Agents ทำงานร่วมกันแบบฝูง (Swarm Intelligence)

---

## 1. ภาพรวมระบบ (System Overview)

### 1.1 วัตถุประสงค์

ออกแบบระบบที่ AI Agents สามารถ:
- ประสานงานกันแบบกระจายอำนาจ (decentralized coordination)
- ปรับตัวตามสถานการณ์แบบเรียลไทม์
- แบ่งปันภาระงานอย่างมีประสิทธิภาพ
- ฟื้นตัวเมื่อมี Agents ล้มเหลว (self-healing)
- สร้างพฤติกรรมที่เกิดจากการร่วมมือกัน (emergent behavior)

### 1.2 Swarm Intelligence Principles

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SWARM INTELLIGENCE PRINCIPLES                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  1. DECENTRALIZATION                                                         │
│     • ไม่มี leader ที่ควบคุมทั้งหมด                                         │
│     • แต่ละ Agent ตัดสินใจอิสระตาม local information                       │
│     • Global behavior เกิดจาก local interactions                            │
│                                                                              │
│  2. SELF-ORGANIZATION                                                        │
│     • Swarm จัดโครงสร้างตนเองโดยอัตโนมัติ                                   │
│     • ไม่ต้องมีการควบคุมจากภายนอก                                          │
│     • ปรับตัวตามสถานการณ์                                                  │
│                                                                              │
│  3. PARALLELISM                                                              │
│     • หลาย Agents ทำงานพร้อมกัน                                             │
│     • แบ่งงานและประมวลผลแบบขนาน                                            │
│     • เพิ่ม throughput และลดเวลาทำงาน                                      │
│                                                                              │
│  4. EMERGENT BEHAVIOR                                                        │
│     • พฤติกรรมระดับกลุ่มที่ซับซ้อนกว่าพฤติกรรมของแต่ละตัว                 │
│     • เกิดจากการ interact ระหว่าง Agents                                    │
│     • ไม่สามารถคาดเดาได้จากการดูแต่ละ Agent อย่างเดียว                     │
│                                                                              │
│  5. ADAPTABILITY                                                             │
│     • ปรับตัวตามสภาพแวดล้อมที่เปลี่ยนแปลง                                 │
│     • เรียนรู้จากประสบการณ์                                                 │
│     • ฟื้นตัวจากความล้มเหลว                                                 │
│                                                                              │
│  6. STIGMERGY (Indirect Coordination)                                        │
│     • Agents สื่อสารผ่านการแก้ไขสภาพแวดล้อม                                │
│     • เหมือนมดที่ทิ้ง pheromone trail                                       │
│     • สร้าง shared context โดยไม่ต้องสื่อสารโดยตรง                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Swarm Architecture

### 2.1 Swarm Topology Patterns

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SWARM TOPOLOGY PATTERNS                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 1: FULLY CONNECTED (Complete Graph)                                 │
│  ═══════════════════════════════════════════                                 │
│                                                                              │
│         ┌───┐                                                                │
│        /  A  \                                                               │
│       /   │   \                                                              │
│      /    │    \                                                             │
│   ┌─B─────┼─────D─┐                                                          │
│    \      │      /                                                           │
│     \     │     /                                                            │
│      \    │    /                                                             │
│       \   C   /                                                              │
│        \  │  /                                                               │
│         \ │ /                                                                │
│          \│/                                                                 │
│                                                                              │
│  Pros: Fastest communication, maximum redundancy                             │
│  Cons: High overhead (O(n²) connections), doesn't scale                      │
│  Use case: Small swarms (< 10 agents), critical decisions                    │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 2: RING TOPOLOGY                                                    │
│  ═══════════════════════                                                     │
│                                                                              │
│            ┌───┐                                                             │
│       ┌────┤ A ├────┐                                                        │
│       │    └───┘    │                                                        │
│       │             │                                                        │
│     ┌─┴─┐         ┌─┴─┐                                                      │
│     │ B │         │ E │                                                      │
│     └─┬─┘         └─┬─┘                                                      │
│       │             │                                                        │
│       │    ┌───┐    │                                                        │
│       └────┤ C ├────┘                                                        │
│            └─┬─┘                                                             │
│              │                                                               │
│            ┌─┴─┐                                                             │
│            │ D │                                                             │
│            └───┘                                                             │
│                                                                              │
│  Pros: Simple, fault-tolerant (one break doesn't disconnect)                 │
│  Cons: Slow broadcast (O(n) hops), no shortcuts                              │
│  Use case: Token-passing protocols, sequential processing                    │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 3: MESH TOPOLOGY (Recommended)                                      │
│  ═══════════════════════════════════════                                     │
│                                                                              │
│            ┌───┐                                                             │
│       ┌────┤ A ├────┐                                                        │
│       │    └───┘    │                                                        │
│       │      │      │                                                        │
│       │      │      │                                                        │
│     ┌─┴─┐  ┌─┴─┐  ┌─┴─┐                                                      │
│     │ B ├──┤ C ├──┤ D │                                                      │
│     └─┬─┘  └─┬─┘  └─┬─┘                                                      │
│       │      │      │                                                        │
│       │    ┌─┴─┐    │                                                        │
│       └────┤ E ├────┘                                                        │
│            └───┘                                                             │
│                                                                              │
│  Pros: Balance of connectivity and efficiency                                │
│  Cons: Requires intelligent routing                                          │
│  Use case: General-purpose swarms, medium scale (10-100 agents)              │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 4: HIERARCHICAL SWARM (Our Approach)                                │
│  ════════════════════════════════════════════                                │
│                                                                              │
│              ┌─────────┐                                                     │
│              │  CTO    │                                                     │
│              │ (Leader)│                                                     │
│              └────┬────┘                                                     │
│                   │                                                          │
│         ┌─────────┼─────────┐                                                │
│         │         │         │                                                │
│         ▼         ▼         ▼                                                │
│       ┌───┐    ┌───┐    ┌───┐                                               │
│       │DH1│    │DH2│    │DH3│                                               │
│       │(L)│    │(L)│    │(L)│                                               │
│       └┬─┬┘    └┬─┬┘    └┬─┬┘                                               │
│        │ │      │ │      │ │                                                 │
│        │ │      │ │      │ │                                                 │
│       ┌┴─┴┐    ┌┴─┴┐    ┌┴─┴┐                                               │
│       │W W│    │W W│    │W W│                                               │
│       │o o│    │o o│    │o o│                                               │
│       │r r│    │r r│    │r r│                                               │
│       │k k│    │k k│    │k k│                                               │
│       │e e│    │e e│    │e e│                                               │
│       │r r│    │r r│    │r r│                                               │
│       └───┘    └───┘    └───┘                                               │
│                                                                              │
│  Pros: Scalable, clear responsibility, fits our hierarchical model           │
│  Cons: Potential bottleneck at leaders                                       │
│  Use case: Large-scale development projects, our MCP system                  │
│                                                                              │
│  Note: Workers within same department form sub-swarm                         │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Swarm Architecture Components

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SWARM ARCHITECTURE                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    Swarm Coordination Layer                          │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   Task       │  │   Resource   │  │   Load       │              │   │
│  │  │   Allocator  │  │   Manager    │  │   Balancer   │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│           ┌────────────────────────┼────────────────────────┐               │
│           │                        │                        │               │
│           ▼                        ▼                        ▼               │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐         │
│  │  Agent Pool     │    │  Communication  │    │  State Manager  │         │
│  │                 │    │     Layer       │    │                 │         │
│  │ • Worker Agents │    │                 │    │ • Shared State  │         │
│  │ • Active tasks  │    │ • Message Bus   │    │ • Agent Status  │         │
│  │ • Capabilities  │    │ • Event Stream  │    │ • Task States   │         │
│  └─────────────────┘    └─────────────────┘    └─────────────────┘         │
│           │                      │                      │                   │
│           └──────────────────────┼──────────────────────┘                   │
│                                  │                                          │
│                                  ▼                                          │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    Stigmergy Layer (Shared Environment)              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   Task       │  │   Code       │  │   Knowledge  │              │   │
│  │  │   Board      │  │   Repository │  │   Base       │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Task Allocation

### 3.1 Task Allocation Algorithms

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    TASK ALLOCATION ALGORITHMS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ALGORITHM 1: CONTRACT NET PROTOCOL                                          │
│  ═══════════════════════════════════                                         │
│                                                                              │
│  Phase 1: Task Announcement                                                  │
│  ┌─────────┐         Announce Task         ┌─────────┐                      │
│  │ Manager │──────────────────────────────▶│ Agents  │                      │
│  └─────────┘                               └─────────┘                      │
│                                                                              │
│  Phase 2: Bidding                                                            │
│  ┌─────────┐         Submit Bid            ┌─────────┐                      │
│  │ Manager │◀──────────────────────────────│ Agents  │                      │
│  └─────────┘    (cost, capability, time)   └─────────┘                      │
│                                                                              │
│  Phase 3: Award                                                              │
│  ┌─────────┐         Award Contract        ┌─────────┐                      │
│  │ Manager │──────────────────────────────▶│ Winner  │                      │
│  └─────────┘                               └─────────┘                      │
│                                                                              │
│  Pros: Optimal assignment, considers agent capabilities                      │
│  Cons: Communication overhead, bidding delay                                 │
│  Use case: Complex tasks requiring specific expertise                        │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ALGORITHM 2: MARKET-BASED ALLOCATION                                        │
│  ═════════════════════════════════════                                       │
│                                                                              │
│  Concept: Agents "buy" tasks using virtual currency                          │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Task Market                                                         │   │
│  │                                                                      │   │
│  │  Task A (Difficulty: 5) ──────▶ Price: 50 credits                   │   │
│  │  Task B (Difficulty: 3) ──────▶ Price: 30 credits                   │   │
│  │  Task C (Difficulty: 8) ──────▶ Price: 80 credits                   │   │
│  │                                                                      │   │
│  │  Agent X (Budget: 100, Capability: Backend)                         │   │
│  │  → Can afford Task A or B, but not C                                │   │
│  │  → Chooses Task A (better ROI)                                      │   │
│  │                                                                      │   │
│  │  Agent Y (Budget: 100, Capability: Frontend)                        │   │
│  │  → Task B matches expertise                                         │   │
│  │  → Buys Task B                                                      │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  Pros: Self-organizing, emergent load balancing                              │
│  Cons: Requires currency management, may need rebalancing                    │
│  Use case: Dynamic workloads, multiple task types                            │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ALGORITHM 3: AUCTION-BASED ALLOCATION (Recommended)                         │
│  ═══════════════════════════════════════════════════                         │
│                                                                              │
│  Types of Auctions:                                                          │
│                                                                              │
│  1. English Auction (Ascending Price)                                        │
│     • Task starts at low "price" (difficulty)                                │
│     • Agents bid down (offer to do for lower reward)                         │
│     • Lowest capable bidder wins                                             │
│                                                                              │
│  2. Dutch Auction (Descending Price)                                         │
│     • Task starts at high "price"                                            │
│     • Price decreases over time                                              │
│     • First agent to accept wins                                             │
│                                                                              │
│  3. Vickrey Auction (Sealed Bid)                                             │
│     • Agents submit sealed bids                                              │
│     • Lowest bidder wins, but gets second-lowest price                       │
│     • Encourages truthful bidding                                            │
│                                                                              │
│  Example Flow:                                                               │
│  ┌─────────┐                                                                 │
│  │ Task:   │ "Implement Authentication API"                                │
│  │ Diff: 7 │                                                                 │
│  └────┬────┘                                                                 │
│       │                                                                      │
│       ▼                                                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  AUCTION START                                                       │   │
│  │                                                                      │   │
│  │  Starting "price": 70 credits                                       │   │
│  │                                                                      │   │
│  │  Agent A (Backend Expert): "I can do it for 60"                     │   │
│  │  Agent B (Backend Expert): "I can do it for 55"                     │   │
│  │  Agent C (Frontend): (no bid - not qualified)                       │   │
│  │                                                                      │   │
│  │  Agent A: "I can do it for 50"                                      │   │
│  │  Agent B: "I can do it for 48"                                      │   │
│  │                                                                      │   │
│  │  [No more bids for 5 seconds]                                       │   │
│  │                                                                      │   │
│  │  WINNER: Agent B at 48 credits                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  Pros: Efficient, considers capability and cost                              │
│  Cons: Time delay for auction completion                                     │
│  Use case: Our hierarchical MCP system                                       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Task Allocation Service

```typescript
// Task Allocation Interface
interface TaskAllocator {
  // Submit task for allocation
  submitTask(task: Task): Promise<TaskAllocation>;
  
  // Get allocation status
  getAllocationStatus(taskId: string): Promise<AllocationStatus>;
  
  // Reallocate task (if agent fails)
  reallocateTask(taskId: string, reason: string): Promise<TaskAllocation>;
  
  // Get agent workload
  getAgentWorkload(agentId: string): Promise<WorkloadMetrics>;
  
  // Balance load across agents
  balanceLoad(): Promise<LoadBalanceResult>;
}

// Task Structure
interface Task {
  id: string;
  type: string;
  description: string;
  requirements: {
    skills: string[];
    min_expertise: number;
    estimated_effort: number; // hours
    priority: 'low' | 'medium' | 'high' | 'critical';
  };
  constraints: {
    deadline?: Date;
    dependencies?: string[];
    max_cost?: number;
  };
  context: Record<string, any>;
}

// Agent Bid
interface AgentBid {
  agent_id: string;
  task_id: string;
  bid_amount: number; // credits or estimated time
  confidence: number; // 0.0 - 1.0
  reasoning: string;
  timestamp: Date;
}

// Task Allocation Result
interface TaskAllocation {
  task_id: string;
  assigned_agent: string;
  allocation_method: 'contract_net' | 'market' | 'auction' | 'direct';
  bid_amount: number;
  expected_completion: Date;
  backup_agents: string[]; // In case primary fails
  timestamp: Date;
}
```

---

## 4. Load Balancing

### 4.1 Dynamic Load Balancing

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DYNAMIC LOAD BALANCING                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  LOAD METRICS                                                                │
│  ════════════                                                                │
│  • Active tasks count                                                        │
│  • Queue depth                                                               │
│  • CPU/Memory usage                                                          │
│  • Response time                                                             │
│  • Error rate                                                                │
│  • Success rate                                                              │
│                                                                              │
│  BALANCING STRATEGIES                                                        │
│  ═════════════════════                                                       │
│                                                                              │
│  1. ROUND-ROBIN (Simple)                                                     │
│     • Distribute tasks evenly across agents                                  │
│     • Doesn't consider agent capabilities                                    │
│     • Good for homogeneous agents                                            │
│                                                                              │
│  2. LEAST-CONNECTIONS                                                        │
│     • Assign to agent with fewest active tasks                               │
│     • Simple but effective                                                   │
│     • May overload fast agents                                               │
│                                                                              │
│  3. WEIGHTED ROUND-ROBIN                                                     │
│     • Assign based on agent capacity                                         │
│     • Higher capacity = more tasks                                           │
│     • Considers agent differences                                            │
│                                                                              │
│  4. CAPABILITY-BASED (Recommended)                                           │
│     • Match task requirements to agent capabilities                          │
│     • Consider expertise, availability, workload                             │
│     • Best for heterogeneous agents                                          │
│                                                                              │
│  Example:                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Task: "Optimize Database Queries"                                   │   │
│  │  Requirements: Database expertise, Performance tuning                │   │
│  │                                                                      │   │
│  │  Agent Pool:                                                         │   │
│  │  ┌──────────┬──────────┬──────────┬──────────┐                      │   │
│  │  │  Agent   │ Expertise│ Workload │  Score   │                      │   │
│  │  ├──────────┼──────────┼──────────┼──────────┤                      │   │
│  │  │ Agent A  │ DB: 95%  │   3/10   │   0.92   │ ◀── Selected        │   │
│  │  │ Agent B  │ DB: 80%  │   5/10   │   0.75   │                      │   │
│  │  │ Agent C  │ FE: 90%  │   2/10   │   0.20   │ (wrong expertise)   │   │
│  │  │ Agent D  │ DB: 70%  │   8/10   │   0.42   │ (overloaded)        │   │
│  │  └──────────┴──────────┴──────────┴──────────┘                      │   │
│  │                                                                      │   │
│  │  Score = (Expertise_Match × 0.6) + (Availability × 0.4)             │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  REBALANCING TRIGGER CONDITIONS                                              │
│  ════════════════════════════════                                            │
│  • Agent workload > threshold (e.g., 80%)                                    │
│  • Task queue > threshold (e.g., 10 tasks)                                   │
│  • Agent failure detected                                                    │
│  • New agent joins                                                           │
│  • Scheduled rebalancing (every 5 minutes)                                   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Fault Tolerance & Self-Healing

### 5.1 Failure Detection

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    FAILURE DETECTION                                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  DETECTION METHODS                                                           │
│  ═════════════════                                                           │
│                                                                              │
│  1. HEARTBEAT (Health Checks)                                                │
│     • Agents send heartbeat every 5 seconds                                  │
│     • Missing 3 heartbeats = suspect failure                                 │
│     • Missing 5 heartbeats = confirmed failure                               │
│                                                                              │
│  2. TASK TIMEOUT                                                             │
│     • Monitor task completion time                                           │
│     • Exceeds expected duration + buffer = potential issue                   │
│     • Exceeds hard timeout = failure                                         │
│                                                                              │
│  3. ERROR RATE MONITORING                                                    │
│     • Track error rate per agent                                             │
│     • Error rate > threshold = degraded performance                          │
│     • Continuous errors = failure                                            │
│                                                                              │
│  4. OUTPUT VALIDATION                                                        │
│     • Validate agent outputs                                                 │
│     • Invalid outputs = potential failure                                    │
│                                                                              │
│  Failure Classification:                                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Level 1: TRANSIENT (Temporary)                                      │   │
│  │  • Network glitch                                                    │   │
│  │  • Temporary resource shortage                                       │   │
│  │  → Action: Retry with exponential backoff                            │   │
│  │                                                                      │   │
│  │  Level 2: DEGRADED (Reduced capacity)                                │   │
│  │  • Slow response times                                               │   │
│  │  • Increased error rate                                              │   │
│  │  → Action: Reduce load, monitor closely                              │   │
│  │                                                                      │   │
│  │  Level 3: FAILED (Complete failure)                                  │   │
│  │  • No heartbeat                                                      │   │
│  │  • Task timeout                                                      │   │
│  │  → Action: Reassign tasks, remove from pool                          │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Self-Healing Mechanisms

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SELF-HEALING MECHANISMS                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  RECOVERY STRATEGIES                                                         │
│  ═══════════════════                                                         │
│                                                                              │
│  1. TASK REASSIGNMENT                                                        │
│                                                                              │
│     Failed Agent Detected                                                    │
│            │                                                                 │
│            ▼                                                                 │
│     ┌─────────────┐                                                          │
│     │ Identify    │                                                          │
│     │ Active Tasks│                                                          │
│     └──────┬──────┘                                                          │
│            │                                                                 │
│            ▼                                                                 │
│     ┌─────────────┐                                                          │
│     │ Find Backup │                                                          │
│     │ Agents      │                                                          │
│     └──────┬──────┘                                                          │
│            │                                                                 │
│            ▼                                                                 │
│     ┌─────────────┐                                                          │
│     │ Reassign    │                                                          │
│     │ Tasks       │                                                          │
│     └──────┬──────┘                                                          │
│            │                                                                 │
│            ▼                                                                 │
│     ┌─────────────┐                                                          │
│     │ Resume from │                                                          │
│     │ Checkpoint  │                                                          │
│     └─────────────┘                                                          │
│                                                                              │
│  2. AGENT RESTART                                                            │
│     • Automatic restart of failed agent                                      │
│     • Reload state from persistent storage                                   │
│     • Rejoin swarm after health check                                        │
│                                                                              │
│  3. SCALING                                                                  │
│     • Spawn new agent instances when load high                               │
│     • Terminate excess agents when load low                                  │
│     • Maintain optimal swarm size                                            │
│                                                                              │
│  4. CIRCUIT BREAKER                                                          │
│     • Stop sending tasks to failing agent                                    │
│     • Periodically test if recovered                                         │
│     • Gradually restore traffic when healthy                                 │
│                                                                              │
│  Self-Healing Flow:                                                          │
│  ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐   │
│  │ Detect  │───▶│ Assess  │───▶│ Decide  │───▶│ Execute │───▶│ Verify  │   │
│  │ Failure │    │ Impact  │    │ Action  │    │ Recovery│    │ Success │   │
│  └─────────┘    └─────────┘    └─────────┘    └─────────┘    └─────────┘   │
│       ▲                                                           │        │
│       └───────────────────────────────────────────────────────────┘        │
│                              (Retry if failed)                             │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Emergent Behavior

### 6.1 Emergent Patterns

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    EMERGENT BEHAVIOR PATTERNS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PATTERN 1: DIVISION OF LABOR                                                │
│  ═══════════════════════════                                                 │
│  • Agents automatically specialize based on task types                       │
│  • No explicit assignment of roles                                           │
│  • Emerges from repeated task allocation                                     │
│                                                                              │
│  Example:                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Initial State: All agents general-purpose                           │   │
│  │                                                                      │   │
│  │  After 100 tasks:                                                    │   │
│  │  • Agent A: 80% frontend tasks → de facto Frontend Specialist        │   │
│  │  • Agent B: 85% backend tasks → de facto Backend Specialist          │   │
│  │  • Agent C: 70% database tasks → de facto Database Specialist        │   │
│  │                                                                      │   │
│  │  Result: Natural specialization without explicit programming         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  PATTERN 2: LOAD BALANCING EMERGENCE                                         │
│  ═══════════════════════════════════                                         │
│  • Agents naturally balance workload                                         │
│  • Overloaded agents reject new tasks                                        │
│  • Underutilized agents accept more tasks                                    │
│  • Global balance emerges from local decisions                               │
│                                                                              │
│  PATTERN 3: KNOWLEDGE DIFFUSION                                              │
│  ═════════════════════════════════                                           │
│  • Successful solutions spread through swarm                                 │
│  • Agents observe and learn from others                                      │
│  • Best practices propagate organically                                      │
│                                                                              │
│  PATTERN 4: COLLECTIVE INTELLIGENCE                                          │
│  ══════════════════════════════════                                          │
│  • Group decisions better than individual decisions                          │
│  • Diversity of perspectives leads to better solutions                       │
│  • Wisdom of the crowd effect                                                │
│                                                                              │
│  Example: Code Review Swarm                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Individual Agent A: Finds 3 bugs                                    │   │
│  │  Individual Agent B: Finds 2 bugs                                    │   │
│  │  Individual Agent C: Finds 4 bugs                                    │   │
│  │                                                                      │   │
│  │  Swarm Review (collaborative):                                       │   │
│  │  • Agent A finds bug #1                                              │   │
│  │  • Agent B builds on #1, finds related bug #2                        │   │
│  │  • Agent C identifies pattern, finds 5 more related bugs             │   │
│  │  • Discussion reveals architectural issue causing all bugs           │   │
│  │                                                                      │   │
│  │  Total: 8 bugs + 1 architectural fix (emergent insight)              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 7. Stigmergy (Indirect Coordination)

### 7.1 Stigmergy Mechanisms

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    STIGMERGY MECHANISMS                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  CONCEPT: Agents coordinate by modifying shared environment                 │
│  ═══════════════════════════════════════════════════════════                 │
│                                                                              │
│  Like ants leaving pheromone trails:                                         │
│  • Ant finds food → leaves pheromone trail                                   │
│  • Other ants follow trail → reinforce it                                    │
│  • Trail evaporates over time → outdated info removed                        │
│                                                                              │
│  IN SOFTWARE SWARMS:                                                         │
│  ═══════════════════                                                         │
│                                                                              │
│  1. CODE REPOSITORY AS STIGMERGY                                             │
│     • Agent commits code → leaves "trail"                                    │
│     • Other agents see changes → build on it                                 │
│     • Commit history shows evolution                                         │
│                                                                              │
│  2. TASK BOARD AS STIGMERGY                                                  │
│     • Agent picks up task → marks "in progress"                              │
│     • Other agents see → don't duplicate work                                │
│     • Agent completes → marks "done"                                         │
│     • Status changes trigger other actions                                   │
│                                                                              │
│  3. KNOWLEDGE BASE AS STIGMERGY                                              │
│     • Agent learns pattern → adds to knowledge base                          │
│     • Other agents query → benefit from learning                             │
│     • Knowledge accumulates over time                                        │
│                                                                              │
│  4. SHARED CONTEXT AS STIGMERGY                                              │
│     • Agent updates shared context                                           │
│     • Other agents read → adjust behavior                                    │
│     • Context evolves with swarm activity                                    │
│                                                                              │
│  Stigmergy Example: Bug Fixing                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                      │   │
│  │  Step 1: Agent A discovers bug                                       │   │
│  │  → Creates bug report in shared task board                           │   │
│  │  → Tags with relevant components                                     │   │
│  │                                                                      │   │
│  │  Step 2: Agent B sees bug report                                     │   │
│  │  → Recognizes similar issue from past                                │   │
│  │  → Adds comment with suggested fix                                   │   │
│  │                                                                      │   │
│  │  Step 3: Agent C (expert in component)                               │   │
│  │  → Sees bug + suggestion                                             │   │
│  │  → Implements fix                                                    │   │
│  │  → Commits code with reference to bug                                │   │
│  │                                                                      │   │
│  │  Step 4: Agent D (QA)                                                │   │
│  │  → Sees commit message                                               │   │
│  │  → Runs tests to verify fix                                          │   │
│  │  → Updates bug status                                                │   │
│  │                                                                      │   │
│  │  Result: No direct coordination needed, all through shared env       │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  STIGMERGY TRAILS                                                            │
│  ══════════════════                                                          │
│                                                                              │
│  Trail Type        │ Medium              │ Decay Rate                        │
│  ──────────────────┼─────────────────────┼─────────────────                  │
│  Code commits      │ Git history         │ Permanent                         │
│  Task status       │ Task board          │ When task completes               │
│  Knowledge         │ Knowledge base      │ When updated                      │
│  Performance data  │ Metrics DB          │ After 30 days                     │
│  Temporary notes   │ Shared context      │ After session ends                │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. MCP Tools for Swarm

```typescript
// Swarm-related MCP Tools
const swarmTools = [
  {
    name: "swarm_spawn_agent",
    description: "Spawn a new agent into the swarm",
    inputSchema: {
      type: "object",
      properties: {
        agent_type: { 
          type: "string", 
          enum: ["frontend", "backend", "devops", "qa", "general"] 
        },
        capabilities: { type: "array", items: { type: "string" } },
        initial_tasks: { type: "array", items: { type: "string" } },
        parent_agent: { type: "string" } // Agent that spawned this one
      },
      required: ["agent_type", "capabilities"]
    }
  },
  {
    name: "swarm_submit_bid",
    description: "Submit a bid for task allocation",
    inputSchema: {
      type: "object",
      properties: {
        task_id: { type: "string" },
        bid_amount: { type: "number" },
        confidence: { type: "number", minimum: 0, maximum: 1 },
        reasoning: { type: "string" },
        estimated_completion: { type: "string", format: "date-time" }
      },
      required: ["task_id", "bid_amount"]
    }
  },
  {
    name: "swarm_get_swarm_status",
    description: "Get current status of the entire swarm",
    inputSchema: {
      type: "object",
      properties: {
        include_agents: { type: "boolean", default: true },
        include_tasks: { type: "boolean", default: true },
        include_metrics: { type: "boolean", default: true }
      }
    }
  },
  {
    name: "swarm_emit_pheromone",
    description: "Leave a stigmergy trail for other agents",
    inputSchema: {
      type: "object",
      properties: {
        trail_type: { 
          type: "string", 
          enum: ["code_commit", "task_update", "knowledge", "alert"] 
        },
        content: { type: "object" },
        priority: { type: "string", enum: ["low", "medium", "high"] },
        ttl_seconds: { type: "number" }
      },
      required: ["trail_type", "content"]
    }
  },
  {
    name: "swarm_detect_pheromone",
    description: "Detect stigmergy trails from other agents",
    inputSchema: {
      type: "object",
      properties: {
        trail_types: { 
          type: "array", 
          items: { type: "string" } 
        },
        since: { type: "string", format: "date-time" },
        relevant_to: { type: "string" } // Task or domain
      }
    }
  },
  {
    name: "swarm_rebalance",
    description: "Trigger load rebalancing across the swarm",
    inputSchema: {
      type: "object",
      properties: {
        reason: { type: "string" },
        aggressive: { type: "boolean", default: false }
      }
    }
  }
];
```

---

## 9. Integration with Hierarchical Agents

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    HIERARCHICAL SWARM INTEGRATION                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  COMBINING HIERARCHY + SWARM                                                 │
│  ═══════════════════════════                                                 │
│                                                                              │
│  Level 1: CTO (Strategic Coordination)                                       │
│  • Defines high-level goals                                                  │
│  • Allocates resources to departments                                        │
│  • Monitors overall swarm health                                             │
│  • Intervenes for critical decisions                                         │
│                                                                              │
│  Level 2: Department Heads (Tactical Swarms)                                 │
│  • Each department = sub-swarm                                               │
│  • Self-organize within department                                           │
│  • Task allocation via auction/market                                        │
│  • Report to CTO                                                             │
│                                                                              │
│  Level 3: Workers (Execution Swarm)                                          │
│  • Form dynamic sub-swarms for tasks                                         │
│  • Collaborate via stigmergy                                                 │
│  • Self-heal when members fail                                               │
│  • Report to Department Head                                                 │
│                                                                              │
│  Architecture:                                                               │
│                                                                              │
│              ┌─────────┐                                                     │
│              │   CTO   │ ◀── Strategic coordination                         │
│              │(Monitor)│                                                     │
│              └────┬────┘                                                     │
│                   │                                                          │
│      ┌────────────┼────────────┐                                             │
│      │            │            │                                             │
│      ▼            ▼            ▼                                             │
│   ┌──────┐    ┌──────┐    ┌──────┐                                          │
│   │Frontend│   │Backend│   │ DevOps │ ◀── Department swarms                 │
│   │ Head  │    │ Head │    │ Head  │                                         │
│   └──┬───┘    └──┬───┘    └──┬───┘                                          │
│      │            │            │                                             │
│   ┌──┴──┐     ┌──┴──┐     ┌──┴──┐                                          │
│   │W W W│     │W W W│     │W W W│ ◀── Worker sub-swarms                     │
│   │o o o│     │o o o│     │o o o│                                           │
│   │r r r│     │r r r│     │r r r│                                           │
│   │k k k│     │k k k│     │k k k│                                           │
│   │e e e│     │e e e│     │e e e│                                           │
│   │r r r│     │r r r│     │r r r│                                           │
│   └──┬──┘     └──┬──┘     └──┬──┘                                           │
│      │            │            │                                             │
│      └────────────┴────────────┘                                             │
│                   │                                                          │
│                   ▼                                                          │
│         ┌─────────────────┐                                                  │
│         │  Shared State   │ ◀── Stigmergy layer                             │
│         │  (Task Board,   │                                                  │
│         │   Code Repo,    │                                                  │
│         │   Knowledge)    │                                                  │
│         └─────────────────┘                                                  │
│                                                                              │
│  Benefits:                                                                   │
│  • Clear accountability (hierarchy)                                          │
│  • Flexibility and adaptability (swarm)                                      │
│  • Scalable to large teams                                                   │
│  • Fault-tolerant                                                            │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 10. Summary

ระบบ Swarm Agents นี้ช่วยให้ MCP Hierarchical Agents:

1. **ประสานงานแบบกระจายอำนาจ** - ไม่ต้องพึ่ง leader ตลอดเวลา
2. **ปรับตัวตามสถานการณ์** - รองรับการเปลี่ยนแปลงแบบเรียลไทม์
3. **แบ่งปันภาระงาน** - ด้วย task allocation algorithms
4. **ฟื้นตัวจากความล้มเหลว** - self-healing mechanisms
5. **สร้างพฤติกรรมเกิดใหม่** - emergent behavior จากการร่วมมือ

**Key Features:**
- ✅ 4 Topology Patterns (Fully Connected, Ring, Mesh, Hierarchical)
- ✅ 3 Task Allocation Algorithms (Contract Net, Market-based, Auction)
- ✅ Dynamic Load Balancing
- ✅ Fault Tolerance & Self-Healing
- ✅ Stigmergy (Indirect Coordination)
- ✅ Emergent Behavior Patterns
