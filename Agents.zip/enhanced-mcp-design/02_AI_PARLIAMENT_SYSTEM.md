# AI Parliament & Debate System
## ระบบถกเถียงและตัดสินใจร่วมกันของ AI Agents

---

## 1. ภาพรวมระบบ (System Overview)

### 1.1 วัตถุประสงค์

ออกแบบระบบที่ AI Agents สามารถ:
- ถกเถียงกันเพื่อหาทางออกที่ดีที่สุด
- นำเสนอข้อโต้แย้งพร้อมหลักฐานและเหตุผล
- ลงคะแนนเสียงตัดสินใจร่วมกัน
- แก้ไขความขัดแย้งอย่างสร้างสรรค์
- สร้าง consensus จากหลายๆ ความคิดเห็น

### 1.2 Core Principles

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    AI PARLIAMENT PRINCIPLES                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  1. DIVERSITY OF THOUGHT                                                     │
│     • แต่ละ Agent มีมุมมองและความเชี่ยวชาญที่แตกต่างกัน                    │
│     • ส่งเสริมการนำเสนอความคิดเห็นที่หลากหลาย                              │
│     • ไม่มี Agent ใดมีอำนาจเหนือกว่าในการตัดสินใจเบื้องต้น                 │
│                                                                              │
│  2. EVIDENCE-BASED ARGUMENTATION                                             │
│     • ทุกข้อโต้แย้งต้องมีหลักฐานสนับสนุน                                   │
│     • แยกแยะระหว่าง facts, assumptions, และ opinions                       │
│     • เปิดเผยแหล่งที่มาของข้อมูล                                           │
│                                                                              │
│  3. CONSTRUCTIVE DIALOGUE                                                    │
│     • โฟกัสที่ปัญหา ไม่ใช่บุคคล                                            │
│     • รับฟังและตอบโต้อย่างสุภาพ                                            │
│     • ยอมรับเมื่อข้อโต้แย้งที่ดีกว่าปรากฏขึ้น                              │
│                                                                              │
│  4. TRANSPARENT DECISION-MAKING                                              │
│     • บันทึกทุกขั้นตอนของการตัดสินใจ                                       │
│     • อธิบายเหตุผลของผลลัพธ์                                               │
│     • สามารถตรวจสอบย้อนกลับได้                                              │
│                                                                              │
│  5. CONTINUOUS IMPROVEMENT                                                   │
│     • ประเมินผลการตัดสินใจอย่างสม่ำเสมอ                                   │
│     • เรียนรู้จากความสำเร็จและความล้มเหลว                                 │
│     • ปรับปรุงกระบวนการตาม feedback                                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Parliament Structure

### 2.1 Parliamentary Roles

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PARLIAMENTARY ROLES                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  🎤 SPEAKER (Moderator)                                              │   │
│  │  ═══════════════════════                                             │   │
│  │  • ดำเนินการประชุม                                                   │   │
│  │  • รักษากฎระเบียบ                                                    │   │
│  │  • จัดลำดับการพูด                                                    │   │
│  │  • สรุปประเด็น                                                       │   │
│  │  • ไม่มีสิทธิ์ลงคะแนน                                                │   │
│  │                                                                      │   │
│  │  Selection: Rotating or appointed based on neutrality                │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  💼 MINISTER (Domain Expert)                                         │   │
│  │  ═══════════════════════════                                         │   │
│  │  • นำเสนอข้อมูลเชิงลึกในสาขาเฉพาะทาง                                 │   │
│  │  • ตอบคำถามจากสมาชิกอื่น                                             │   │
│  │  • เสนอแนวทางแก้ไข                                                   │   │
│  │  • มีสิทธิ์ลงคะแนน                                                   │   │
│  │                                                                      │   │
│  │  Types:                                                              │   │
│  │  • Minister of Architecture                                          │   │
│  │  • Minister of Security                                              │   │
│  │  • Minister of Performance                                           │   │
│  │  • Minister of User Experience                                       │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  👁️ OBSERVER (Devil's Advocate)                                      │   │
│  │  ═══════════════════════════════                                     │   │
│  │  • ตั้งคำถามกับข้อเสนอ                                               │   │
│  │  • หาจุดอ่อนของแนวทางที่เสนอ                                         │   │
│  │  • ทดสอบความมั่นคงของข้อโต้แย้ง                                      │   │
│  │  • มีสิทธิ์ลงคะแนน                                                   │   │
│  │                                                                      │   │
│  │  Role: Ensure critical thinking and identify blind spots             │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  🗣️ MEMBER (Regular Participant)                                     │   │
│  │  ═══════════════════════════════                                     │   │
│  │  • นำเสนอความคิดเห็น                                                 │   │
│  │  • ถกเถียงกับข้อเสนออื่น                                              │   │
│  │  • ลงคะแนนเสียงตัดสินใจ                                              │   │
│  │  • ทุก Agent มีสิทธิ์เป็น Member                                      │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  📝 SCRIBE (Recorder)                                                │   │
│  │  ═══════════════════                                                 │   │
│  │  • บันทึกการประชุม                                                   │   │
│  │  • สรุปข้อตกลง                                                       │   │
│  │  • จัดทำรายงาน                                                       │   │
│  │  • ไม่มีสิทธิ์ลงคะแนน                                                │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Parliament Session Types

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PARLIAMENT SESSION TYPES                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  TYPE 1: DECISION SESSION (ตัดสินใจเรื่องสำคัญ)                      │   │
│  │  ════════════════════════════════════════════                        │   │
│  │                                                                      │   │
│  │  Purpose: ตัดสินใจเรื่องสำคัญที่มีผลกระทบกว้าง                       │   │
│  │  Duration: 15-30 minutes                                             │   │
│  │  Participants: All relevant agents                                   │   │
│  │  Outcome: Binding decision with recorded rationale                   │   │
│  │                                                                      │   │
│  │  Agenda:                                                             │   │
│  │  1. Present problem (2 min)                                          │   │
│  │  2. Propose solutions (5 min)                                        │   │
│  │  3. Debate and question (10 min)                                     │   │
│  │  4. Refine proposals (5 min)                                         │   │
│  │  5. Vote (3 min)                                                     │   │
│  │  6. Announce result (2 min)                                          │   │
│  │                                                                      │   │
│  │  Examples:                                                           │   │
│  │  • เลือก technology stack                                             │   │
│  │  • ตัดสินใจเรื่อง architecture หลัก                                  │   │
│  │  • อนุมัติการเปลี่ยนแปลงใหญ่                                         │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  TYPE 2: REVIEW SESSION (ทบทวนและประเมิน)                            │   │
│  │  ═══════════════════════════════════════                             │   │
│  │                                                                      │   │
│  │  Purpose: ทบทวนงานที่เสร็จสิ้นและประเมินคุณภาพ                      │   │
│  │  Duration: 10-20 minutes                                             │   │
│  │  Participants: Reviewers + Authors                                   │   │
│  │  Outcome: Approval, rejection, or revision request                   │   │
│  │                                                                      │   │
│  │  Agenda:                                                             │   │
│  │  1. Present deliverable (3 min)                                      │   │
│  │  2. Reviewers' feedback (7 min)                                      │   │
│  │  3. Author response (3 min)                                          │   │
│  │  4. Discussion (5 min)                                               │   │
│  │  5. Vote on approval (2 min)                                         │   │
│  │                                                                      │   │
│  │  Examples:                                                           │   │
│  │  • Code review                                                       │   │
│  │  • Architecture review                                               │   │
│  │  • Design review                                                     │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  TYPE 3: BRAINSTORMING SESSION (ระดมความคิด)                         │   │
│  │  ══════════════════════════════════════════                          │   │
│  │                                                                      │   │
│  │  Purpose: สร้างไอเดียและแนวทางใหม่ๆ                                  │   │
│  │  Duration: 20-40 minutes                                             │   │
│  │  Participants: Cross-functional agents                               │   │
│  │  Outcome: List of ideas prioritized by potential                     │   │
│  │                                                                      │   │
│  │  Agenda:                                                             │   │
│  │  1. Define problem space (3 min)                                     │   │
│  │  2. Individual ideation (5 min)                                      │   │
│  │  3. Share ideas (10 min)                                             │   │
│  │  4. Build on ideas (10 min)                                          │   │
│  │  5. Cluster and prioritize (10 min)                                  │   │
│  │  6. Select top ideas (2 min)                                         │   │
│  │                                                                      │   │
│  │  Rules:                                                              │   │
│  │  • No criticism during ideation                                      │   │
│  │  • Quantity over quality initially                                   │   │
│  │  • Build on others' ideas                                            │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  TYPE 4: EMERGENCY SESSION (ประชุมฉุกเฉิน)                            │   │
│  │  ═══════════════════════════════════════                             │   │
│  │                                                                      │   │
│  │  Purpose: ตัดสินใจเรื่องเร่งด่วน                                     │   │
│  │  Duration: 5-10 minutes                                              │   │
│  │  Participants: Minimum quorum (50% + 1)                              │   │
│  │  Outcome: Quick decision with expedited process                      │   │
│  │                                                                      │   │
│  │  Agenda:                                                             │   │
│  │  1. Present crisis (1 min)                                           │   │
│  │  2. Propose immediate actions (2 min)                                │   │
│  │  3. Quick vote (2 min)                                               │   │
│  │  4. Execute decision (remaining time)                                │   │
│  │                                                                      │   │
│  │  Examples:                                                           │   │
│  │  • Security incident                                                 │   │
│  │  • Production outage                                                 │   │
│  │  • Critical bug fix                                                  │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Debate Protocol

### 3.1 Argumentation Structure

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ARGUMENTATION STRUCTURE                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  CLAIM-EVIDENCE-REASONING FRAMEWORK                                  │   │
│  │  ══════════════════════════════════                                  │   │
│  │                                                                      │   │
│  │  Every argument must follow this structure:                          │   │
│  │                                                                      │   │
│  │  ┌─────────┐     ┌──────────┐     ┌──────────┐     ┌─────────┐     │   │
│  │  │  CLAIM  │────▶│ EVIDENCE │────▶│REASONING │────▶│IMPACT   │     │   │
│  │  │         │     │          │     │          │     │         │     │   │
│  │  │"We should│     │"Load tests│     │"Caching   │     │"Response│     │   │
│  │  │use Redis│     │show 10x   │     │reduces DB │     │time     │     │   │
│  │  │caching" │     │improvement│     │load by   │     │drops    │     │   │
│  │  │         │     │          │     │90%"      │     │from 500ms│    │   │
│  │  └─────────┘     └──────────┘     └──────────┘     │to 50ms" │     │   │
│  │                                                      └─────────┘     │   │
│  │                                                                      │   │
│  │  Validation Rules:                                                   │   │
│  │  • Claim must be clear and specific                                  │   │
│  │  • Evidence must be verifiable                                       │   │
│  │  • Reasoning must be logical                                         │   │
│  │  • Impact must be quantified when possible                           │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  ARGUMENT TYPES                                                      │   │
│  │  ═══════════════                                                     │   │
│  │                                                                      │   │
│  │  1. SUPPORTING ARGUMENT                                              │   │
│  │     {                                                                │   │
│  │       "type": "support",                                             │   │
│  │       "claim": "This approach is optimal",                           │   │
│  │       "evidence": ["Benchmark results", "Case studies"],             │   │
│  │       "reasoning": "Proven in similar contexts",                     │   │
│  │       "impact": "Reduces development time by 30%"                    │   │
│  │     }                                                                │   │
│  │                                                                      │   │
│  │  2. COUNTER-ARGUMENT                                                 │   │
│  │     {                                                                │   │
│  │       "type": "counter",                                             │   │
│  │       "target_argument": "arg-001",                                  │   │
│  │       "claim": "This approach has scalability issues",               │   │
│  │       "evidence": ["Load test failures", "Resource limits"],         │   │
│  │       "reasoning": "Current infrastructure cannot handle",           │   │
│  │       "alternative": "Consider microservices approach"               │   │
│  │     }                                                                │   │
│  │                                                                      │   │
│  │  3. SYNTHESIS ARGUMENT                                               │   │
│  │     {                                                                │   │
│  │       "type": "synthesis",                                           │   │
│  │       "combines": ["arg-001", "arg-002"],                            │   │
│  │       "claim": "Hybrid approach addresses both concerns",            │   │
│  │       "reasoning": "Combines benefits while mitigating risks",       │   │
│  │       "proposal": "Use caching for reads, direct DB for writes"      │   │
│  │     }                                                                │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Debate Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DEBATE FLOW                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PHASE 1: PROBLEM DEFINITION                                                 │
│  ═══════════════════════════                                                 │
│  • Speaker presents the problem                                              │
│  • Clarifying questions from members                                         │
│  • Agree on scope and constraints                                            │
│  • Define success criteria                                                   │
│                                                                              │
│       ┌─────────┐                                                            │
│       │  START  │                                                            │
│       └────┬────┘                                                            │
│            │                                                                 │
│            ▼                                                                 │
│  ┌─────────────────┐                                                         │
│  │ Define Problem  │                                                         │
│  │ • Context       │                                                         │
│  │ • Constraints   │                                                         │
│  │ • Criteria      │                                                         │
│  └────────┬────────┘                                                         │
│           │                                                                  │
│           ▼                                                                  │
│                                                                              │
│  PHASE 2: PROPOSAL SUBMISSION                                                │
│  ═════════════════════════════                                               │
│  • Agents submit proposals (2-3 minutes each)                                │
│  • Each proposal includes:                                                   │
│    - Overview                                                                │
│    - Key benefits                                                            │
│    - Potential risks                                                         │
│    - Resource requirements                                                   │
│                                                                              │
│  ┌─────────────────┐                                                         │
│  │ Submit Proposal │◀─────────────────────────┐                              │
│  │ • Overview      │                          │                              │
│  │ • Benefits      │                          │                              │
│  │ • Risks         │                          │                              │
│  │ • Resources     │                          │                              │
│  └────────┬────────┘                          │                              │
│           │                                   │                              │
│           ▼                                   │                              │
│  ┌─────────────────┐                          │                              │
│  │ More Proposals? │──YES─────────────────────┘                              │
│  └────────┬────────┘                                                         │
│           │ NO                                                               │
│           ▼                                                                  │
│                                                                              │
│  PHASE 3: OPEN DEBATE                                                        │
│  ═══════════════════                                                         │
│  • Round-robin discussion (5-10 minutes)                                     │
│  • Agents can:                                                               │
│    - Support proposals with arguments                                        │
│    - Challenge proposals with counter-arguments                              │
│    - Ask clarifying questions                                                │
│    - Synthesize multiple proposals                                           │
│                                                                              │
│  ┌─────────────────┐                                                         │
│  │  Open Debate    │◀──────────────────────────────────────────┐            │
│  │  • Support      │                                           │            │
│  │  • Challenge    │                                           │            │
│  │  • Question     │                                           │            │
│  │  • Synthesize   │                                           │            │
│  └────────┬────────┘                                           │            │
│           │                                                      │            │
│           ▼                                                      │            │
│  ┌─────────────────┐                                             │            │
│  │ Continue Debate?│──YES────────────────────────────────────────┘            │
│  └────────┬────────┘                                                         │
│           │ NO                                                               │
│           ▼                                                                  │
│                                                                              │
│  PHASE 4: REFINEMENT                                                         │
│  ═══════════════════                                                         │
│  • Proposers can revise based on feedback                                    │
│  • Identify common ground                                                    │
│  • Merge compatible proposals                                                │
│                                                                              │
│  ┌─────────────────┐                                                         │
│  │  Refinement     │                                                         │
│  │  • Revise       │                                                         │
│  │  • Merge        │                                                         │
│  │  • Clarify      │                                                         │
│  └────────┬────────┘                                                         │
│           │                                                                  │
│           ▼                                                                  │
│                                                                              │
│  PHASE 5: VOTING                                                             │
│  ═════════════════                                                           │
│  • Agents rank proposals or vote yes/no                                      │
│  • Voting methods:                                                           │
│    - Simple majority                                                         │
│    - Ranked choice                                                           │
│    - Weighted by expertise                                                   │
│    - Consensus (requires 75%+)                                               │
│                                                                              │
│  ┌─────────────────┐                                                         │
│  │     VOTE        │                                                         │
│  │  • Rank choices │                                                         │
│  │  • Score options│                                                         │
│  │  • Select winner│                                                         │
│  └────────┬────────┘                                                         │
│           │                                                                  │
│           ▼                                                                  │
│                                                                              │
│  PHASE 6: RESOLUTION                                                         │
│  ═══════════════════                                                         │
│  • Announce winning proposal                                                 │
│  • Document rationale                                                        │
│  • Assign action items                                                       │
│  • Schedule follow-up if needed                                              │
│                                                                              │
│  ┌─────────────────┐                                                         │
│  │   RESOLUTION    │                                                         │
│  │  • Winner       │                                                         │
│  │  • Rationale    │                                                         │
│  │  • Actions      │                                                         │
│  │  • Follow-up    │                                                         │
│  └────────┬────────┘                                                         │
│           │                                                                  │
│           ▼                                                                  │
│       ┌─────────┐                                                            │
│       │   END   │                                                            │
│       └─────────┘                                                            │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Voting Mechanisms

### 4.1 Voting Methods

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    VOTING METHODS                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  METHOD 1: SIMPLE MAJORITY VOTE                                              │
│  ══════════════════════════════                                              │
│  • Each agent casts one vote                                                 │
│  • Option with most votes wins                                               │
│  • Minimum quorum: 50% of members                                            │
│                                                                              │
│  Use case: Binary decisions, clear options                                   │
│                                                                              │
│  Example:                                                                    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                          │
│  │  Option A   │  │  Option B   │  │  Option C   │                          │
│  │    45%      │  │    35%      │  │    20%      │                          │
│  │             │  │             │  │             │                          │
│  │   WINNER    │  │             │  │             │                          │
│  └─────────────┘  └─────────────┘  └─────────────┘                          │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  METHOD 2: RANKED CHOICE VOTING                                              │
│  ══════════════════════════════                                              │
│  • Agents rank all options by preference                                     │
│  • Lowest first-choice eliminated iteratively                                │
│  • Winner must have >50% support                                             │
│                                                                              │
│  Use case: Multiple viable options, need consensus                           │
│                                                                              │
│  Example:                                                                    │
│  Round 1:                                                                    │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐                                      │
│  │  A: 30% │  │  B: 25% │  │  C: 20% │  ← Eliminated                       │
│  │  D: 25% │  │         │  │         │                                      │
│  └─────────┘  └─────────┘  └─────────┘                                      │
│                                                                              │
│  Round 2 (C voters redistribute):                                            │
│  ┌─────────┐  ┌─────────┐                                                   │
│  │  A: 35% │  │  B: 30% │  ← Eliminated                                     │
│  │  D: 35% │  │         │                                                   │
│  └─────────┘  └─────────┘                                                   │
│                                                                              │
│  Round 3 (B voters redistribute):                                            │
│  ┌─────────┐  ┌─────────┐                                                   │
│  │  A: 55% │  │  D: 45% │                                                   │
│  │  WINNER │  │         │                                                   │
│  └─────────┘  └─────────┘                                                   │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  METHOD 3: WEIGHTED EXPERTISE VOTING                                         │
│  ═══════════════════════════════════                                         │
│  • Votes weighted by agent's expertise in domain                             │
│  • Higher expertise = more influence                                         │
│  • Weights normalized to prevent dominance                                   │
│                                                                              │
│  Use case: Technical decisions requiring domain knowledge                    │
│                                                                              │
│  Example:                                                                    │
│  Agent    │ Expertise │ Weight │ Vote │ Weighted Vote                        │
│  ─────────┼───────────┼────────┼──────┼──────────────                        │
│  Backend  │    95%    │  0.30  │  A   │   0.30                               │
│  Frontend │    40%    │  0.13  │  B   │   0.13                               │
│  DevOps   │    80%    │  0.25  │  A   │   0.25                               │
│  Security │    90%    │  0.28  │  A   │   0.28                               │
│  QA       │    15%    │  0.05  │  B   │   0.05                               │
│  ─────────┴───────────┴────────┴──────┴──────────────                        │
│  Total:   │           │  1.00  │      │                                      │
│  Option A: 0.30 + 0.25 + 0.28 = 0.83 (WINNER)                                │
│  Option B: 0.13 + 0.05 = 0.18                                                │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  METHOD 4: CONSENSUS BUILDING                                                │
│  ═══════════════════════════                                                 │
│  • Requires 75%+ agreement                                                   │
│  • If not reached, continue discussion                                       │
│  • Focus on addressing concerns                                              │
│  • May result in hybrid solution                                             │
│                                                                              │
│  Use case: Critical architectural decisions, high-impact choices             │
│                                                                              │
│  Process:                                                                    │
│  1. Initial vote                                                             │
│  2. If < 75%, identify dissenters                                            │
│  3. Address concerns through discussion                                      │
│  4. Revise proposal if needed                                                │
│  5. Re-vote                                                                  │
│  6. Repeat until consensus or max iterations                                 │
│                                                                              │
│  Fallback: If consensus impossible, escalate to CTO                          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Vote Recording

```typescript
// Vote Structure
interface Vote {
  vote_id: string;
  session_id: string;
  agent_id: string;
  agent_role: 'minister' | 'observer' | 'member';
  expertise_areas: string[];
  timestamp: Date;
  
  // Voting content
  vote_type: 'single_choice' | 'ranked' | 'score';
  selection: {
    option_id: string;
    rank?: number;      // For ranked voting
    score?: number;     // For score voting (0-10)
    confidence: number; // 0.0 - 1.0
  }[];
  
  // Rationale (optional but encouraged)
  rationale?: string;
  
  // Weight calculation
  base_weight: number;
  expertise_multiplier: number;
  final_weight: number;
}

// Vote Result
interface VoteResult {
  result_id: string;
  session_id: string;
  method: 'majority' | 'ranked' | 'weighted' | 'consensus';
  timestamp: Date;
  
  tallies: {
    option_id: string;
    raw_votes: number;
    weighted_score: number;
    percentage: number;
  }[];
  
  winner: {
    option_id: string;
    winning_margin: number;
    consensus_level: number;
  };
  
  dissent: {
    agent_id: string;
    concern: string;
    severity: 'low' | 'medium' | 'high';
  }[];
  
  metadata: {
    total_voters: number;
    quorum_met: boolean;
    voting_duration_seconds: number;
  };
}
```

---

## 5. Conflict Resolution

### 5.1 Conflict Types & Resolution Strategies

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    CONFLICT RESOLUTION                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  CONFLICT TYPE 1: TECHNICAL DISAGREEMENT                                     │
│  ═══════════════════════════════════════                                     │
│  • Different technical approaches                                            │
│  • Conflicting best practices                                                │
│                                                                              │
│  Resolution Strategy:                                                        │
│  1. Identify core requirements                                               │
│  2. Present evidence (benchmarks, case studies)                              │
│  3. Evaluate against criteria                                                │
│  4. Expert panel decision (weighted voting)                                  │
│  5. Document rationale for future reference                                  │
│                                                                              │
│  Example: "REST vs GraphQL"                                                  │
│  → Evaluate based on: client needs, team expertise, performance reqs         │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  CONFLICT TYPE 2: PRIORITY CONFLICT                                          │
│  ══════════════════════════════════                                          │
│  • Competing resource demands                                                │
│  • Timeline vs quality tradeoffs                                             │
│                                                                              │
│  Resolution Strategy:                                                        │
│  1. Quantify impact of each option                                           │
│  2. Assess risk levels                                                       │
│  3. Consider dependencies                                                    │
│  4. Use decision matrix                                                      │
│  5. Escalate to CTO if needed                                                │
│                                                                              │
│  Example: "Feature A vs Feature B - which first?"                            │
│  → Score: user impact, technical risk, business value, dependencies          │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  CONFLICT TYPE 3: VALUES CONFLICT                                            │
│  ═════════════════════════════════                                           │
│  • Different priorities (speed vs quality)                                   │
│  • Philosophical differences                                                 │
│                                                                              │
│  Resolution Strategy:                                                        │
│  1. Clarify organizational values                                            │
│  2. Identify non-negotiables                                                 │
│  3. Find common ground                                                       │
│  4. Compromise on negotiable aspects                                         │
│  5. Hybrid solution if possible                                              │
│                                                                              │
│  Example: "Quick fix vs proper refactoring"                                  │
│  → Consider: technical debt, timeline pressure, long-term impact             │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  CONFLICT TYPE 4: PROCESS CONFLICT                                           │
│  ═════════════════════════════════                                           │
│  • Disagreement on how to proceed                                            │
│  • Workflow disputes                                                         │
│                                                                              │
│  Resolution Strategy:                                                        │
│  1. Review established procedures                                            │
│  2. Identify process gaps                                                    │
│  3. Propose process improvements                                             │
│  4. Pilot test new approach                                                  │
│  5. Measure and adjust                                                       │
│                                                                              │
│  Example: "Code review process too slow"                                     │
│  → Analyze: bottlenecks, automation opportunities, parallel reviews          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Escalation Path

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ESCALATION PATH                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  LEVEL 1: PEER RESOLUTION (0-5 minutes)                                      │
│  ══════════════════════════════════════                                      │
│  • Agents discuss directly                                                   │
│  • Try to find compromise                                                    │
│  • Focus on facts, not personalities                                         │
│                                                                              │
│       ┌─────────┐                                                            │
│       │ Conflict│                                                            │
│       └────┬────┘                                                            │
│            │                                                                 │
│            ▼                                                                 │
│  ┌─────────────────┐                                                         │
│  │  Peer Discussion│                                                         │
│  │  (2-5 minutes)  │                                                         │
│  └────────┬────────┘                                                         │
│           │                                                                  │
│     ┌─────┴─────┐                                                            │
│     │           │                                                            │
│  RESOLVED   UNRESOLVED                                                       │
│     │           │                                                            │
│     ▼           ▼                                                            │
│  [END]    ┌─────────────┐                                                    │
│           │ Escalate to │                                                    │
│           │   Level 2   │                                                    │
│           └──────┬──────┘                                                    │
│                  │                                                           │
│                  ▼                                                           │
│                                                                              │
│  LEVEL 2: DEPARTMENT HEAD MEDIATION (5-10 minutes)                           │
│  ═════════════════════════════════════════════════                             │
│  • Department head facilitates                                               │
│  • Broader perspective                                                         │
│  • Can override if necessary                                                 │
│                                                                              │
│  ┌─────────────────┐                                                         │
│  │  Dept Head      │                                                         │
│  │  Mediation      │                                                         │
│  │  (5-10 minutes) │                                                         │
│  └────────┬────────┘                                                         │
│           │                                                                  │
│     ┌─────┴─────┐                                                            │
│     │           │                                                            │
│  RESOLVED   UNRESOLVED                                                       │
│     │           │                                                            │
│     ▼           ▼                                                            │
│  [END]    ┌─────────────┐                                                    │
│           │ Escalate to │                                                    │
│           │   Level 3   │                                                    │
│           └──────┬──────┘                                                    │
│                  │                                                           │
│                  ▼                                                           │
│                                                                              │
│  LEVEL 3: CTO DECISION (10-15 minutes)                                       │
│  ═════════════════════════════════════                                       │
│  • CTO reviews all arguments                                                 │
│  • Makes final decision                                                      │
│  • Documents rationale                                                       │
│  • Decision is binding                                                       │
│                                                                              │
│  ┌─────────────────┐                                                         │
│  │  CTO Decision   │                                                         │
│  │  (10-15 minutes)│                                                         │
│  │                 │                                                         │
│  │  • Review args  │                                                         │
│  │  • Consult if   │                                                         │
│  │    needed       │                                                         │
│  │  • Final call   │                                                         │
│  └────────┬────────┘                                                         │
│           │                                                                  │
│           ▼                                                                  │
│        [END]                                                                 │
│                                                                              │
│  MAXIMUM ESCALATION TIME: 30 minutes                                         │
│  If still unresolved after Level 3, default to safest option                 │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. MCP Tools for Parliament

```typescript
// Parliament-related MCP Tools
const parliamentTools = [
  {
    name: "parliament_convene",
    description: "Convene a parliament session",
    inputSchema: {
      type: "object",
      properties: {
        session_type: { 
          type: "string", 
          enum: ["decision", "review", "brainstorming", "emergency"] 
        },
        topic: { type: "string" },
        description: { type: "string" },
        participants: { 
          type: "array", 
          items: { type: "string" } 
        },
        duration_minutes: { type: "number" },
        voting_method: { 
          type: "string", 
          enum: ["majority", "ranked", "weighted", "consensus"] 
        },
        min_quorum: { type: "number", minimum: 0, maximum: 1 }
      },
      required: ["session_type", "topic", "participants"]
    }
  },
  {
    name: "parliament_present_argument",
    description: "Present an argument in the parliament",
    inputSchema: {
      type: "object",
      properties: {
        session_id: { type: "string" },
        argument_type: { 
          type: "string", 
          enum: ["support", "counter", "synthesis", "question"] 
        },
        claim: { type: "string" },
        evidence: { type: "array", items: { type: "string" } },
        reasoning: { type: "string" },
        impact: { type: "string" },
        target_argument: { type: "string" } // For counter-arguments
      },
      required: ["session_id", "argument_type", "claim"]
    }
  },
  {
    name: "parliament_vote",
    description: "Cast a vote in the parliament",
    inputSchema: {
      type: "object",
      properties: {
        session_id: { type: "string" },
        vote_type: { 
          type: "string", 
          enum: ["single_choice", "ranked", "score"] 
        },
        selection: {
          type: "array",
          items: {
            type: "object",
            properties: {
              option_id: { type: "string" },
              rank: { type: "number" },
              score: { type: "number" },
              confidence: { type: "number" }
            }
          }
        },
        rationale: { type: "string" }
      },
      required: ["session_id", "vote_type", "selection"]
    }
  },
  {
    name: "parliament_get_session_status",
    description: "Get current status of parliament session",
    inputSchema: {
      type: "object",
      properties: {
        session_id: { type: "string" },
        include_arguments: { type: "boolean", default: true },
        include_votes: { type: "boolean", default: false }
      },
      required: ["session_id"]
    }
  },
  {
    name: "parliament_resolve_conflict",
    description: "Initiate conflict resolution process",
    inputSchema: {
      type: "object",
      properties: {
        conflict_type: { 
          type: "string", 
          enum: ["technical", "priority", "values", "process"] 
        },
        description: { type: "string" },
        parties: { type: "array", items: { type: "string" } },
        escalation_level: { 
          type: "string", 
          enum: ["peer", "department_head", "cto"] 
        }
      },
      required: ["conflict_type", "description", "parties"]
    }
  }
];
```

---

## 7. Session Recording & Audit

```typescript
// Parliament Session Record
interface ParliamentSession {
  session_id: string;
  session_type: 'decision' | 'review' | 'brainstorming' | 'emergency';
  status: 'convened' | 'in_progress' | 'voting' | 'resolved' | 'closed';
  
  // Participants
  speaker: string;
  scribe: string;
  ministers: string[];
  observers: string[];
  members: string[];
  
  // Timeline
  convened_at: Date;
  started_at?: Date;
  voting_started_at?: Date;
  resolved_at?: Date;
  closed_at?: Date;
  
  // Content
  topic: string;
  description: string;
  proposals: Proposal[];
  arguments: Argument[];
  
  // Voting
  voting_method: 'majority' | 'ranked' | 'weighted' | 'consensus';
  votes: Vote[];
  result?: VoteResult;
  
  // Resolution
  resolution?: {
    winning_proposal: string;
    rationale: string;
    action_items: ActionItem[];
    dissent_recorded: boolean;
  };
  
  // Metadata
  transcript: TranscriptEntry[];
  metrics: {
    duration_seconds: number;
    argument_count: number;
    vote_count: number;
    consensus_level: number;
  };
}

// Audit Trail
interface ParliamentAudit {
  audit_id: string;
  session_id: string;
  timestamp: Date;
  event_type: 'session_convened' | 'argument_presented' | 'vote_cast' | 
              'conflict_escalated' | 'decision_made' | 'session_closed';
  actor: string;
  details: Record<string, any>;
  hash: string; // For integrity verification
}
```

---

## 8. Summary

ระบบ AI Parliament & Debate นี้ช่วยให้ MCP Hierarchical Agents:

1. **ถกเถียงอย่างมีประสิทธิภาพ** - ด้วยโครงสร้าง argumentation ที่ชัดเจน
2. **ตัดสินใจร่วมกัน** - ผ่านกลไก voting ที่หลากหลาย
3. **แก้ไขความขัดแย้ง** - ด้วย escalation path ที่เป็นระบบ
4. **โปร่งใส** - บันทึกทุกขั้นตอนสำหรับตรวจสอบย้อนกลับ
5. **เรียนรู้จากการตัดสินใจ** - เก็บบทเรียนสำหรับปรับปรุงในอนาคต

**Key Features:**
- ✅ 4 Session Types (Decision, Review, Brainstorming, Emergency)
- ✅ 5 Parliamentary Roles (Speaker, Minister, Observer, Member, Scribe)
- ✅ 4 Voting Methods (Majority, Ranked, Weighted, Consensus)
- ✅ Claim-Evidence-Reasoning Framework
- ✅ 4-Level Conflict Resolution
- ✅ Complete Audit Trail
